package com.hp.itis.core2.version;

import java.util.Date;

public interface IVersion {
	public Integer major();
	public Integer minor();
	public Integer revision();
	public Integer buildNumber();
	public Date buildDate();
	public String releaseInfo();
	public String getVersionInfo();
}
