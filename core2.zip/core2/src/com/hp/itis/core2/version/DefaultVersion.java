package com.hp.itis.core2.version;

import java.util.Date;

import com.hp.itis.core2.vars.GetterVars;
import com.hp.itis.core2.vars.IGetterVars;
import com.hp.itis.core2.vars.PropertiesVars;

public class DefaultVersion extends PropertiesVars implements IVersion {

	private IGetterVars getter;
	
	public DefaultVersion(String res) {
		super(res);
		getter = new GetterVars(this);
	}

	public String getVersionInfo() {
		StringBuffer sb = new StringBuffer();
		sb.append(major());
		sb.append(".");
		sb.append(minor());
		sb.append(".");
		sb.append(revision());
		sb.append(".");
		sb.append(buildNumber());
		String releaseInfo = releaseInfo();
		if(releaseInfo!=null && releaseInfo.length()>0)
		{
			sb.append(" ");
			sb.append(releaseInfo);
		}
		return sb.toString();
	}
	
	@Override
	public Object get(String key) {
		if("version".equals(key))
			return getVersionInfo();
		else
			return super.get(key);
	}

	@Override
	public Date buildDate() {
		return getter.get("version.build_date", new Date());
	}

	@Override
	public Integer buildNumber() {
		return getter.get("version.build_number", 0);
	}

	@Override
	public Integer major() {
		return getter.get("version.major", 0);
	}

	@Override
	public Integer minor() {
		return getter.get("version.minor", 0);
	}

	@Override
	public String releaseInfo() {
		return getter.get("version.release", "");
	}

	@Override
	public Integer revision() {
		return getter.get("version.revision", 0);
	}

}
