package com.hp.itis.core2.vars;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.DataSource;

import com.hp.itis.core2.db.DbOperator;
import com.hp.itis.core2.db.SqlPreparation;

public class DbPersistentVars extends PrefixedVars implements IPersistentVars {
	private IWritableVars vars;
	private Set<String> wroteKeys = Collections.synchronizedSet(new HashSet<String>());
	private DbOperator dbOperator;
	private String loadSql;
	private String getSql;
	private String addSql;
	private String updateSql;
	private String delSql;
	private boolean simpleMode = false;
	private boolean loaded = false;
	
	private class KeyValueVars implements IVars {
		private String key;
		
		public KeyValueVars(String key) {
			this.key = key;
		}

		@Override
		public Object get(String key) {
			if("key".equals(key))
				return this.key;
			else if("value".equals(key))
				return vars.get(this.key);
			return null;
		}
		
	}
	
	public DbPersistentVars(DataSource dataSource, String loadSql, String getSql,
			String addSql, String updateSql, String delSql) {
		this(new MapVars<Object>(new ConcurrentHashMap<String, Object>()),
				dataSource, loadSql, getSql, addSql, updateSql, delSql
				);
	}
	
	/**
	 * 构造器
	 * @param vars 
	 * @param dataSource
	 * @param loadSql 例如： select key, value from t;
	 * @param getSql 例如： select key, value from t where key=#[key]
	 */
	public DbPersistentVars(IWritableVars vars, DataSource dataSource, String loadSql, String getSql, 
			String addSql, String updateSql, String delSql) {
		this.vars = vars;
		this.dbOperator = new DbOperator(dataSource);
		this.loadSql = loadSql;
		this.getSql = getSql;
		this.addSql = addSql;
		this.updateSql = updateSql;
		this.delSql = delSql;
	}
	
	public DbPersistentVars(IWritableVars vars, DataSource dataSource, String loadSql, String getSql) {
		this(vars, dataSource, loadSql, getSql, null, null, null);
		simpleMode = true;
	}
	
	public DbPersistentVars(DataSource dataSource, String loadSql, String getSql) {
		this(dataSource, loadSql, getSql, null, null, null);
		simpleMode = true;
	}

	@Override
	public Object get(String key) {
		if(loaded)
			return vars.get(key);
		else {
			try {
				return getFromDb(key);
			} catch (SQLException e) {
				return vars.get(key);
			}
		}
	}
	
	public Object getFromDb(String key) throws SQLException {
		ResultSet rs = getResults(key);
		try {
			if(rs != null) {
				if(rs.next()) {
					Object value = rs.getObject(2);
					vars.put(key, value);
				}
			}
			return vars.get(key);
		}
		finally {
			rs.close();
		}
	}

	@Override
	public void load() throws SQLException {
		ResultSet rs = getResults(null);
		try {
			if(rs != null) {
				while(rs.next()) {
					String key = rs.getString(1);
					Object value = rs.getObject(2);
					vars.put(key, value);
				}
				loaded = true;
			}
		}
		finally {
			rs.close();
		}
	}

	@Override
	public void save() throws SQLException {
		for(String key : wroteKeys) {
			Object value = vars.get(key);
			if(simpleMode) {
				ResultSet rs = getResults(key);
				if(null == rs)
					continue;
				try {
					if(null != value) {
						//update
						if(rs.next()) {
							rs.updateString(1, key);
							rs.updateObject(2, vars.get(key));
							rs.updateRow();
						}
						//insert
						else {
							rs.moveToInsertRow();
							rs.updateString(1, key);
							rs.updateObject(2, vars.get(key));
							rs.insertRow();
						}
					}
					//delete
					else {
						if(rs.next()) {
							rs.deleteRow();
						}
					}
				}
				finally {
					rs.close();
				}
			}
			else {
				ResultSet rs = getResults(key);
				if(null == rs)
					continue;
				boolean exists = false;
				try {
					exists = rs.next();
				}
				finally {
					rs.close();
				}
				if(null != value) {
					//update
					if(exists)
						executeSql(updateSql, key);
					//insert
					else {
						executeSql(addSql, key);
					}
				}
				//delete
				else if(exists) {
					executeSql(delSql, key);
				}
			}
		}
		wroteKeys.clear();
	}

	@Override
	public void put(String key, Object value) {
		vars.put(key, value);
		wroteKeys.add(key);
	}
	
	protected void executeSql(String sql, String key) throws SQLException {
		dbOperator.execute(sql, new KeyValueVars(key));
	}
	
	protected ResultSet getResults(String key) throws SQLException {
		ResultSet rs = null;
		Connection conn = null;
		try {
			conn = dbOperator.getConnection();
			if(key != null) {
				if(simpleMode) {
					SqlPreparation p =dbOperator.prepareSql(conn, getSql, new KeyValueVars(key), 
							ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
					rs = dbOperator.query(p);
				}
				else
					rs = dbOperator.query(conn, getSql, new KeyValueVars(key));
			}
			else {
				rs = dbOperator.query(conn, loadSql, new KeyValueVars(key));
			}
			return dbOperator.getConnectedRs(conn, rs);
		} finally {
			if(conn != null && rs == null) {
				conn.close();
			}
		}
	}

}
