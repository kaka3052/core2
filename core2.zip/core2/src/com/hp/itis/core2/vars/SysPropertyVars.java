package com.hp.itis.core2.vars;


public class SysPropertyVars extends PropertiesVars {

	public SysPropertyVars() {
		super(System.getProperties());
	}

}
