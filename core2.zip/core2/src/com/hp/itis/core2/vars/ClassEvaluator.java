package com.hp.itis.core2.vars;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.hp.itis.core2.commdata.TypeCaster;

/**
 * 类函数变量执行器
 * 
 * @author changjiang
 *
 */

class ClassEvaluator {
	
	public synchronized static Object[] makeParams(List<Object> strParams, Class<?>[] types)
	{
		if(null==strParams)
			return null;
		Object[] params = new Object[types.length];
		for(int i=0, j=0; i<types.length; i++)
		{
			if(i<strParams.size())
			{
				if(types[i].isArray() && types.length-i==1)
				{
					//处理数组参数 
					if((strParams.get(j).getClass().isArray() || strParams.get(j) instanceof List<?>) && strParams.size() - j == 1) {
						List<Object> lastParams = new ArrayList<Object>();
						if(strParams.get(j).getClass().isArray()) {
							for(int k=0; k<Array.getLength(strParams.get(j)); k++)
								lastParams.add(Array.get(strParams.get(j), k));
						}
						else
							lastParams.addAll((List<?>)strParams.get(j));
						Object arrayParam = Array.newInstance(types[i].getComponentType(), lastParams.size());
						for(int k=0; k<lastParams.size(); k++) 
							Array.set(arrayParam, k, TypeCaster.cast(types[i].getComponentType(), lastParams.get(k)));
						params[i] = arrayParam;
					}
					else {
						Object arrayParam = Array.newInstance(types[i].getComponentType(), strParams.size() - j);
						for(int k=0; k<Array.getLength(arrayParam); j++, k++)
							Array.set(arrayParam, k, TypeCaster.cast(types[i].getComponentType(), strParams.get(j)));
						params[i] = arrayParam; 
					}
				}
				else
				{
					params[i] = TypeCaster.cast(types[i], strParams.get(j));
					j++;
				}
			}
			else
				params[i] = null;
		}
		return params;
	}
	
	public static Object eval(Class<?> evaluator, String fun, List<Object> params) throws Exception
	{
		Method[] methods = evaluator.getMethods();
		for(Method method :methods)
		{
			if(method.getName().equalsIgnoreCase(fun))
			{
				Object[] paramObjs = makeParams(params, method.getParameterTypes());
				Object obj = method.invoke(null, paramObjs);
				return obj;
			}
		}
		throw new Exception("");
	}
	
	public synchronized static Set<String> getVars(Class<?> evaluator)
	{
		Set<String> vars = new LinkedHashSet<String>();
		Method[] methods = evaluator.getMethods();
		for(Method method :methods)
		{
			if(method.getDeclaringClass().equals(evaluator) 
				&& !method.getReturnType().isPrimitive()
				&& method.getParameterTypes().length==0)
			{
				vars.add(method.getName());
			}
		}
		return vars;
	}
	
	public synchronized static Set<String> getFuns(Class<?> evaluator)
	{
		Set<String> vars = new LinkedHashSet<String>();
		Method[] methods = evaluator.getMethods();
		for(Method method :methods)
		{
			if(method.getDeclaringClass().equals(evaluator))
			{
				vars.add(method.getName());
			}
		}
		return vars;
	}
	
}
