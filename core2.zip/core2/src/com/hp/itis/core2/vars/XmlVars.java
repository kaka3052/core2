package com.hp.itis.core2.vars;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XmlVars extends PrefixedVars implements IWritableVars, IEnumerableVars {

	private Element el;
	
	public XmlVars(Node node) {
		if(node instanceof Document)
			el = ((Document)node).getDocumentElement();
		else
			el = (Element)node;
	}

	@Override
	public Object get(String key) {
		if("children".equals(key))
			return getChildren();
		if(el.hasAttribute(key))
			return el.getAttribute(key);
		NodeList nl =el.getElementsByTagName(key);
		if(nl.getLength()>0) {
			Element c = (Element)(nl.item(0));
			String r = c.getTextContent();
			if(null == r)
				return r;
			return r.trim();
		}
		return null;
	}

	@Override
	public void put(String key, Object value) {
		if(null == value)
			el.removeAttribute(key);
		else
			el.setAttribute(key, value.toString());
	}

	@Override
	public boolean contains(String key) {
		if(el.hasAttribute(key))
			return true;
		NodeList nl =el.getElementsByTagName(key);
		return (nl.getLength()>0);
	}

	@Override
	public int size() {
		return el.getAttributes().getLength();
	}

	@Override
	public Iterator<String> iterator() {
		final NamedNodeMap attrs = el.getAttributes();
		return new Iterator<String>() {
			int i= 0 ;
			@Override
			public boolean hasNext() {
				return i<attrs.getLength();
			}

			@Override
			public String next() {
				return attrs.item(i).getLocalName();
			}

			@Override
			public void remove() {
			}
			
		};
	}
	
	private List<XmlVars> getChildren() {
		List<XmlVars> result = new ArrayList<XmlVars>();
		NodeList nodes = el.getChildNodes();
		for(int i=0; i<nodes.getLength(); i++) {
			Node node = nodes.item(i);
			if(node instanceof Element)
				result.add(new XmlVars((Element)node));
		}
		return result;
	}

}
