package com.hp.itis.core2.vars;

import java.util.Iterator;

import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.evf.EvfDocument;
import com.hp.itis.core2.evf.Section;

public class EvfVars extends PrefixedVars implements IEnumerableVars {

	private SectionVars secVars;
	private DocumentVars docVars;
	
	public static class SectionVars extends PrefixedVars implements IEnumerableVars {
		
		private Section section;
		
		public SectionVars(Section section) {
			this.section = section;
		}

		static int getIndex(String key) {
			int i = -1;
			if(null != key && !"".equals(key))
				try {
					i = TypeCaster.toNumber(key).intValue();
				}
				catch(Throwable e){};
			return i;
		}
		
		@Override
		public Object get(String key) {
			if("object".equals(key))
				return section;
			int i = getIndex(key);
			if(i>=0 && section.count()>i)
				return section.getRecord(i);
			return null;
		}

		@Override
		public Iterator<String> iterator() {
			return new Iterator<String>() {
				Integer i= 0;
				@Override
				public boolean hasNext() {
					return section.count()>i;
				}

				@Override
				public String next() {
					String r = i.toString();
					i++;
					return r;
				}

				@Override
				public void remove() {

				}
			};
		}
		
		@Override
		public boolean contains(String key) {
			int i = getIndex(key);
			return (i>=0 && section.count()>i);
		}

		@Override
		public int size() {
			return section.count();
		}
		
	}
	
	public static class DocumentVars extends PrefixedVars implements IEnumerableVars {
		private EvfDocument doc;
		
		public DocumentVars(EvfDocument doc) {
			this.doc = doc;
		}

		static int getIndex(String key) {
			int i = -1;
			if(null != key && !"".equals(key))
				try {
					i = TypeCaster.toNumber(key).intValue();
				}
				catch(Throwable e){};
			return i;
		}
		
		@Override
		public Object get(String key) {
			if("object".equals(key))
				return doc;
			int i = getIndex(key);
			if(i>=0 && doc.sectionCount()>i)
				return doc.getSection(i);
			return null;
		}

		@Override
		public Iterator<String> iterator() {
			return new Iterator<String>() {
				Integer i= 0;
				@Override
				public boolean hasNext() {
					return doc.sectionCount()>i;
				}

				@Override
				public String next() {
					String r = i.toString();
					i++;
					return r;
				}

				@Override
				public void remove() {

				}
			};
		}
		
		@Override
		public boolean contains(String key) {
			int i = getIndex(key);
			return (i>=0 && doc.sectionCount()>i);
		}

		@Override
		public int size() {
			return doc.sectionCount();
		}
	}
	
	
	public EvfVars(Section section) {
		secVars = new SectionVars(section);
		if(section instanceof EvfDocument)
			docVars = new DocumentVars((EvfDocument)section);
	}
	
	@Override
	public Object get(String key) {
		if("document".equals(key))
			return docVars;
		return secVars.get(key);
	}

	@Override
	public Iterator<String> iterator() {
		return secVars.iterator();
	}
	
	@Override
	public boolean contains(String key) {
		return secVars.contains(key);
	}

	@Override
	public int size() {
		return secVars.size();
	}

}
