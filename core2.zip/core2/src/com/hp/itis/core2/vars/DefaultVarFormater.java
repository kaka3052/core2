package com.hp.itis.core2.vars;

public class DefaultVarFormater implements IVarFormater {

	@Override
	public String format(Object var, IVarHolder holder) {
		if(null != var)
			return var.toString();
		else
			return holder.raw();
	}

}
