package com.hp.itis.core2.vars;

import java.util.List;

public interface IVarHolder {

	String name();

	String defValue();

	String raw();

	List<String> params();

}