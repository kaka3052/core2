package com.hp.itis.core2.vars;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 组合变量表
 * 
 * @author changjiang
 *
 */
public class CombinedVars extends PrefixedVars implements IPersistentVars, IFunVars {

	/**有前缀的变量表*/
	Map<String, IVars> prefixedVars = new HashMap<String, IVars>();
	/**无前缀的变量表*/
	List<IVars> nonePrefixedVars = new ArrayList<IVars>();
	/**第一个可写的变量表*/
	IWritableVars writable = null;
	/**可持久化的变量表列表*/
	List<IPersistentVars> persistentVars = new ArrayList<IPersistentVars>();
	
	public CombinedVars(IVars...varList) {
		add(varList);
	}
	
	public void add(IVars... varList) {
		for(int i=0; i< varList.length; i++)
		{
			add(varList[i], false, false);
		}
	}
	
	public void add(IVars var, boolean readPrefer) {
		add(var, readPrefer, false);
	}
	
	public void add(IVars var, boolean readPrefer, boolean writePerfer) {
		String prefix = null;
		if(var instanceof IPrefixedVars)
		{
			prefix = ((IPrefixedVars)var).prefix();
			if(null != prefix)
			{
				prefixedVars.put(prefix, var);
			}
		}
		if(null == prefix) {
			if(readPrefer)
				nonePrefixedVars.add(0, var);
			else
				nonePrefixedVars.add(var);
		}
		if(writable == null || writePerfer) {
			if(var instanceof IWritableVars)
				writable = (IWritableVars)var;
		}
		if(var instanceof IPersistentVars) {
			persistentVars.add((IPersistentVars)var);
		}
	}
	
	private IVars getPrefixed(String name)
	{
		int p = name.lastIndexOf('.');
		if(p>=0)
		{
			return prefixedVars.get(name.substring(0, p));
		}
		else
			return null;
	}
	
	public Object eval(String fun, List<Object> params) {
		IVars prefixed = getPrefixed(fun);
		if(null != prefixed)
		{
			if(prefixed instanceof IFunVars)
				return ((IFunVars)prefixed).eval(fun, params);
			else
				return null;
		}
		else
		{
			Object result = null;
			for(IVars vars: nonePrefixedVars)
			{
				if(null != vars)
				{
					if(vars instanceof IFunVars)
						result = ((IFunVars)vars).eval(fun, params);
					else
						result = null;
					if(null != result)
						break;
				}
			}
			return result;
		}
	}

	public Object get(String key) {
		IVars prefixed = getPrefixed(key);
		if(null != prefixed)
			if(!(prefixed instanceof IFunVars))
				return prefixed.get(key);
			else
				return null;
			
		else
		{
			Object result = null;
			for(IVars vars: nonePrefixedVars)
			{
				if(null != vars)
				{
					if(!(prefixed instanceof IFunVars))
						result = vars.get(key);
					else
						result = null;
					if(null != result)
						break;
				}
			}
			return result;
		}
	}

	@Override
	public void load() throws Exception {
		for(IPersistentVars vars : persistentVars) {
			vars.load();
		}
	}

	@Override
	public void save() throws Exception {
		for(IPersistentVars vars : persistentVars) {
			vars.save();
		}
	}

	@Override
	public void put(String key, Object value) {
		if(writable != null)
			writable.put(key, value);
	}

}
