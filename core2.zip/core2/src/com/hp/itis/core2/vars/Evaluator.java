package com.hp.itis.core2.vars;

public class Evaluator implements IEvaluator {

	private IEvaluator evaluator;
	protected static final String DEF_EVALUATOR_CLASS = ExprEvaluator.class.getName();
	private static Class<? extends IEvaluator> evaluatorClass = initEvaluatorClass();
	
	@SuppressWarnings("unchecked")
	private static Class<? extends IEvaluator> initEvaluatorClass() {
		try {
			return (Class<? extends IEvaluator>) Class.forName(DEF_EVALUATOR_CLASS);
		} catch (ClassNotFoundException e) {
			return null;
		}
	}
	
	private Evaluator(IEvaluator evaluator) {
		this.evaluator = evaluator;
	}
	
	@Override
	public Object eval(IVars vars) {
		return evaluator.eval(vars);
	}

	@Override
	public Object eval() {
		return evaluator.eval();
	}

	@Override
	public Boolean prepare(String pattern, IVars vars) {
		return evaluator.prepare(pattern, vars);
	}

	@Override
	public Boolean prepare(String pattern) {
		return evaluator.prepare(pattern);
	}
	
	public IVars getVars() {
		return evaluator.getVars();
	}

	public void setVars(IVars vars) {
		evaluator.setVars(vars);
	}
	
	@Override
	public Throwable getLastError() {
		return evaluator.getLastError();
	}

	public static Class<? extends IEvaluator> getEvaluatorClass() {
		return evaluatorClass;
	}
	
	public static IEvaluator build(String pattern) {
		try {
			IEvaluator eval = new Evaluator(evaluatorClass.newInstance());
			eval.prepare(pattern);
			return eval;
		} catch (Exception e) {
			return null;
		}
	}

	public static void setEvaluatorClass(Class<? extends IEvaluator> evaluatorClass) {
		Evaluator.evaluatorClass = evaluatorClass;
	}

}
