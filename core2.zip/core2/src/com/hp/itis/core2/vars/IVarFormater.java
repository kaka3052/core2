package com.hp.itis.core2.vars;

public interface IVarFormater {

	public String format(Object var, IVarHolder holder);
	
}
