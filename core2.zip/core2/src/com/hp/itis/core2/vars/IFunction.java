package com.hp.itis.core2.vars;

import java.util.List;

public interface IFunction {
	/**
	 * 执行函数
	 * @param evaluator 执行器
	 * @param functionName 函数名称
	 * @param params 函数参数
	 * @return 函数执行结果值
	 */
	public Object eval(IEvaluator evaluator, String functionName, List<Object> params);
}
