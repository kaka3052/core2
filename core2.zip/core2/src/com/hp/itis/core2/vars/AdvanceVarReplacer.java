package com.hp.itis.core2.vars;

import java.util.ArrayList;
import java.util.List;

/**
 * 高级变量替换器<p>
 * 
 * 该替换器在实现了变量替换的基础上，可以进行函数替换。<p>
 * 变量的格式为${变量名[参数列表][:默认值]}<p>
 * 其中参数列表格式为 (param 1,...,param n)<p>
 * 如果参数或者默认值中包含','、'}'、')' 或 ':' 等特殊字符需要用'"'引起来，
 * 如果内容中需要使用'"'字符，则可以通过'""'这种方式进行转义。<p>
 * 注意：该类并不支持嵌套函数，但可以支持参数中使用变量<p>
 * 
 * @see com.boco.util.replacer.IVarReplacer
 * @see com.boco.util.replacer.SimpleVarReplacer
 * 
 * @author changjiang
 *
 */

public class AdvanceVarReplacer extends SimpleVarReplacer {
	

	public AdvanceVarReplacer(String pattern)
	{
		super(pattern);
	}
	
	public AdvanceVarReplacer(String pattern, char leadingChar, char bracket)
	{
		super(pattern, leadingChar, bracket);
	}
	
	public AdvanceVarReplacer(String pattern, char leadingChar, char bracket, IVarFormater formater) {
		super(pattern, leadingChar, bracket, formater);
	}
	
	/**
	 * 查找一个变量表达式<p>
	 * pattern[offset]默认认为是$
	 * @param offset 偏移量
	 * @param pattern 源模板字符串
	 * @return 如果找到返回表达式长度,否则返回0
	 */
	private int findVarExpr(int offset, char[] expr)
	{
		int bracketDeep = 0;
		boolean inQuote = false;
		if(expr.length - offset<4 || 
				expr[offset+1] != leftBracket)
			return 0;
	 	for(int i= offset+2; i< expr.length; i++)
	 	{
	 		if(expr[i] == rightBracket)
	 		{
	 			if(!inQuote)
	 			{
	 				if(bracketDeep == 0)
	 					return i+1;
	 				else
	 					bracketDeep--;
	 			}
	 		}
	 		else if(expr[i]==leftBracket)
	 		{
	 			if(!inQuote)
	 				bracketDeep++;
	 		}
	 		else if(expr[i]=='"')
	 		{
	 			inQuote = !inQuote;
	 		}
	 		
	 	}
	 	return 0;
	}
	
	private VarHolder buildVar(int offset, int endpos, char[] expr)
	{
		String raw = new String(expr, offset, endpos-offset);
		String content = new String(expr, offset+2, endpos-offset-3);
		String name = null;
		String defValue = null;
		List<String> params = null;
		if(content.startsWith("=")) {
			params = new ArrayList<String>();
			params.add(content.substring(1));
			name = "=";
			return new VarHolder(raw, name, defValue, params);
		}
		int startpos = offset+2;
		for(int i= startpos; i< endpos;)
		{
			if(expr[i]=='(')
			{
				if(null == name)
					name = new String(expr, startpos, i-startpos);
				params = new ArrayList<String>();
				i = buildParams(i+1, endpos, expr, params);
			}
			else if(expr[i]==':')
			{
				if(null == name)
					name = new String(expr, startpos, i-startpos);
				defValue = unQuote(new String(expr, i+1, endpos-i-2));
				break;
			}
			else
				i++;
		}
		if(null == name)
			name = new String(expr, startpos, endpos-startpos-1);
		return new VarHolder(raw, name, defValue, params);
	}
	
	private String unQuote(String quoteStr)
	{
		quoteStr = quoteStr.trim();
		if(quoteStr.startsWith("$"))
			quoteStr = "__".concat(quoteStr);
		else if(quoteStr.length()>1 
				&&quoteStr.startsWith("\"")
				&&quoteStr.endsWith("\""))
			quoteStr = quoteStr.substring(1, quoteStr.length()-1);
		return quoteStr.replace("\"\"", "\"");
	}
	
	private int buildParams(int offset, int endpos, char[] expr, List<String> params)
	{
		boolean inQuote = false;
		int sp = offset;
		int deep = 1;
		if(expr[sp]==')')
			return sp +1;
		for(int i= offset; i< endpos; i++)
		{
			if(expr[i]==',')
			{
				if(!inQuote && deep==1)
				{
					params.add(unQuote(new String(expr, sp, i-sp)));
					sp = i +1;
				}
			}
			else if(expr[i]=='(') {
				if(!inQuote)
					deep++;
			}
			else if(expr[i]==')')
			{
				if(!inQuote)
				{
					deep--;
					if(deep<=0) {
						params.add(unQuote(new String(expr, sp, i-sp)));
						return i +1;
					}
				}
			}
	 		else if(expr[i]=='"')
	 		{
	 			inQuote = !inQuote;
	 		}
		}
		return endpos;
	}
	
	
	
	/**
	 * 准备变量替换
	 */
	public Boolean prepare(String pattern)
	{
		char[]expr = new char[pattern.length()]; 
		pattern.getChars(0, pattern.length(), expr, 0);
		int sp = 0;
		int i;
		for(i=0; i< expr.length; )
		{
			if(expr[i]==leadingChar)
			{
				int r = findVarExpr(i, expr);
				if(r>0)
				{
					texts.add(new String(expr, sp, i-sp));
					VarHolder var = buildVar(i, r, expr);
					varDefs.add(var);
					i = r;
					sp = i;
				}
				else
					i++;
			}
			else
				i++;
		}
		texts.add(new String(expr, sp, i-sp));

		return true;
	}
	
	public static String replace(String pat, IVars... vars) {
		if(vars.length==0)
			return pat;
		if(vars.length==1)
			return (new AdvanceVarReplacer(pat)).replace(vars[0]);
		return (new AdvanceVarReplacer(pat)).replace(new CombinedVars(vars));
	}
}
