package com.hp.itis.core2.vars;

import java.util.Iterator;

import org.dom4j.Attribute;
import org.dom4j.Element;

public class Dom4jVars extends PrefixedVars implements IWritableVars, IEnumerableVars {
	
	private Element el;
	
	public Dom4jVars(Element el) {
		this.el = el;
	}

	@Override
	public Object get(String key) {
		String v = el.attributeValue(key);
		if(null == v) {
			Element c = el.element(key);
			if(c.isTextOnly())
				return c.getText();
		}
		return null;
	}

	@Override
	public void put(String key, Object value) {
		if(null == value)
			el.addAttribute(key, null);
		else
			el.addAttribute(key, value.toString());
	}

	@Override
	public boolean contains(String key) {
		return null != get(key);
	}

	@Override
	public int size() {
		return el.attributeCount();
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterator<String> iterator() {
		final Iterator<Attribute> it = el.attributeIterator();
		return new Iterator<String>() {

			@Override
			public boolean hasNext() {
				return it.hasNext();
			}

			@Override
			public String next() {
				return it.next().getName();
			}

			@Override
			public void remove() {
				it.remove();
			}
			
		};
	}

}
