package com.hp.itis.core2.vars;

import java.util.List;

/**
 * 函数或变量表示类
 * 
 * @author changjiang
 *
 */

class VarHolder implements IVarHolder {
	/**变量或函数名*/
	private String name = null;
	/**原始变量表达式*/
	private String raw = null;
	/**变量默认值*/
	private String defValue = null; //
	/**函数参数列表*/
	private List<String> params = null;
	
	public VarHolder(String raw, String name, String defValue, List<String> params)
	{
		this.name = name;
		this.params = params;
		this.defValue = defValue;
		this.raw = raw;
	}
	
	public VarHolder(String raw, String name)
	{
		this(raw, name, null);
	}
	
	public VarHolder(String raw, String name, String defValue)
	{
		this(raw, name, defValue, null);
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.replacer.IVarHolder#name()
	 */
	public String name()
	{
		return name;
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.replacer.IVarHolder#defValue()
	 */
	public String defValue()
	{
		return defValue;
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.replacer.IVarHolder#raw()
	 */
	public String raw()
	{
		return raw;
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.replacer.IVarHolder#params()
	 */
	public List<String> params()
	{
		return params;
	}
}
