package com.hp.itis.core2.vars;

import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.FieldMapper;
import com.hp.itis.core2.evf.Section;

public class AutomaticVars extends PrefixedVars implements IEnumerableVars, IWritableVars, IFunVars {

	private IVars vars = null;
	private Object obj = null;
	
	public AutomaticVars(Object o) {
		setObj(o);
	}
	
	public Object getObj() {
		return obj;
	}
	
	@SuppressWarnings("unchecked")
	public void setObj(Object o) {
		if(null == o)
			return;
		Class<?> c = o.getClass();
		obj = o;
		if(IVars.class.isAssignableFrom(c))
			vars = (IVars)o;
		else if(Map.class.isAssignableFrom(c))
			vars = new MapVars((Map)o);
		else if(CommData.class.isAssignableFrom(c)) 
			vars = new CommDataVars((CommData)o);
		else if(ResultSet.class.isAssignableFrom(c))
			vars = new ResultSetVars((ResultSet)o);
		else if(List.class.isAssignableFrom(c))
			vars = new ListVars((List)o);
		else if(org.w3c.dom.Node.class.isAssignableFrom(c))
			vars = new XmlVars((org.w3c.dom.Node)o);
		else if(org.dom4j.Element.class.isAssignableFrom(c))
			vars = new Dom4jVars((org.dom4j.Element)o);
		else if(Section.class.isAssignableFrom(c))
			vars = new EvfVars((Section)o);
		else
			vars = new PojoVars(o);
	}
	
	@Override
	public Object eval(String fun, List<Object> params) {
		if(null != vars && vars instanceof IFunVars) {
			return ((IFunVars)vars).eval(fun, params);
		}
		return null;
	}

	@Override
	public Object get(String key) {
		if(null != vars)
			return vars.get(key);
		return null;
	}
	
	public static boolean acceptable(Class<?> c) {
		return (Map.class.isAssignableFrom(c)) || (CommData.class.isAssignableFrom(c)) 
		|| FieldMapper.isDigestible(c) || IVars.class.isAssignableFrom(c)
		|| ResultSet.class.isAssignableFrom(c) || List.class.isAssignableFrom(c);
	}
	
	public IVars vars() {
		return vars;
	}

	@Override
	public Iterator<String> iterator() {
		if(vars instanceof IEnumerableVars)
			return ((IEnumerableVars)vars).iterator();
		return null;
	}

	@Override
	public void put(String key, Object value) {
		if(vars instanceof IWritableVars)
			((IWritableVars)vars).put(key, value);
	}
	
	public void put(Object o) {
		IVars sVars;
		if(o instanceof IVars)
			sVars = (IVars)o;
		else
			sVars = new AutomaticVars(o);
		if(sVars instanceof IEnumerableVars) {
			IEnumerableVars eVars = (IEnumerableVars)sVars;
			for(String key : eVars)
				put(key, eVars.get(key));
		}
		else {
			for(String key : this) {
				Object v = sVars.get(key);
				if(null != v)
					put(key, v);
			}
		}
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(String key : this) {
			if(sb.length()>0)
				sb.append(",");
			sb.append(key);
			sb.append(":\"");
			sb.append(get(key));
			sb.append("\"");
		}
		return sb.toString();
	}

	@Override
	public boolean contains(String key) {
		if(vars instanceof IEnumerableVars)
			return ((IEnumerableVars)vars).contains(key);
		return null != vars.get(key);
	}

	@Override
	public int size() {
		if(vars instanceof IEnumerableVars)
			return ((IEnumerableVars)vars).size();
		return 0;
	}

}
