package com.hp.itis.core2.vars;

public interface IEnumerableVars extends IVars, Iterable<String> {
	boolean contains(String key);
	int size();
}
