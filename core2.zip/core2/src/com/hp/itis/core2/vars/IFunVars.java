package com.hp.itis.core2.vars;

import java.util.List;

/**
 * 函数变量表标识接口
 * @author changjiang
 *
 */
public interface IFunVars extends IVars {
	/**
	 * 求值函数 
	 * @param fun 函数名
	 * @param params 函数参数
	 * @return 函数值
	 */
	public Object eval(String fun, List<Object> params);
}
