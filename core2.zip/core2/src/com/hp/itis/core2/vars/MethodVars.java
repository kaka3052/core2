package com.hp.itis.core2.vars;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * 类方法变量表类
 * @author changjiang
 *
 */

public class MethodVars extends PrefixedVars implements IFunVars, IEnumerableVars {

	private Set<String> vars;
	private Set<String> funs;
	private Class<?> evalClass;
	
	public MethodVars(Class<?> evalClass) {
		this.evalClass = evalClass;
		vars = ClassEvaluator.getVars(evalClass);
		funs = ClassEvaluator.getFuns(evalClass);
	}
	
	public MethodVars(String className) {
		try {
			this.evalClass = Class.forName(className);
			vars = ClassEvaluator.getVars(evalClass);
			funs = ClassEvaluator.getFuns(evalClass);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public Object eval(String fun, List<Object> params)
	{
		try {
			if(funs.contains(fun))
				return ClassEvaluator.eval(evalClass, fun, params);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Object get(String key) {
		try {
			if(vars.contains(key))
				return ClassEvaluator.eval(evalClass, key, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Iterator<String> iterator() {
		return vars.iterator();
	}

	@Override
	public boolean contains(String key) {
		return vars.contains(key) || funs.contains(key);
	}

	@Override
	public int size() {
		return vars.size();
	}
}
