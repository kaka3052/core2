package com.hp.itis.core2.vars;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class ResultSetVars extends PrefixedVars implements IEnumerableVars, IWritableVars {

	private ResultSet rs;
	private Set<String> keySet;
	
	public ResultSetVars(ResultSet rs) {
		this.rs = rs;
	}

	@Override
	public Object get(String key) {
		try {
			return rs.getObject(key);
		} catch (SQLException e) {
			return null;
		}
	}
	
	@Override
	public void put(String key, Object value) {
		try {
			rs.updateObject(key, value);
		} catch (SQLException e) {
		}
	}
	
	private Set<String> keySet() {
		if(null == keySet)
			keySet = new LinkedHashSet<String>();
		try {
			ResultSetMetaData md = rs.getMetaData();
			int count = md.getColumnCount();
			for(int i=1; i <= count; i++)
				keySet.add(md.getColumnName(i));
		} catch (SQLException e) {
			throw new RuntimeException(e);
		};
		return keySet;
	}

	@Override
	public Iterator<String> iterator() {
		return keySet().iterator();
	}

	@Override
	public boolean contains(String key) {
		return keySet().contains(key);
	}

	@Override
	public int size() {
		try {
			return rs.getMetaData().getColumnCount();
		} catch (SQLException e) {
			return 0;
		}
	}

}
