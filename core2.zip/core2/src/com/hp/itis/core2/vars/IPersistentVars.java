package com.hp.itis.core2.vars;

/**
 * 可持久化的变量表接口
 * 
 * @author changjiang
 *
 */
public interface IPersistentVars extends IWritableVars {
	public void load() throws Exception;
	public void save() throws Exception;
}
