package com.hp.itis.core2.vars;

import java.util.Date;

public interface IGetterVars {

	Object get(String key);

	int getInt(String key);

	char getChar(String key);

	byte getByte(String key);

	float getFloat(String key);

	short getShort(String key);

	double getDouble(String key);

	boolean getBoolean(String key);
	
	Number getNumber(String key);

	long getLong(String key);

	String getString(String key);

	Date getDate(String key);

	int get(String key, int def);

	char get(String key, char def);

	byte get(String key, byte def);

	long get(String key, long def);

	float get(String key, float def);

	short get(String key, short def);

	double get(String key, double def);

	boolean get(String key, boolean def);

	String get(String key, String def);

	Date get(String key, Date def);

	Object get(String key, Object def);

}