package com.hp.itis.core2.vars;

/**
 * 含前缀的变量接口
 * @author changjiang
 *
 */
public interface IPrefixedVars extends IVars {
	/**
	 * 取得变量前缀
	 * @return
	 */
	public String prefix();
	/**
	 * 设置变量前缀
	 * @param value
	 */
	public void prefix(String value);
}
