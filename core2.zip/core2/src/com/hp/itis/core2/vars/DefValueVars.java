package com.hp.itis.core2.vars;

import java.util.List;

public class DefValueVars extends PrefixedVars implements IFunVars {
	private Object value;
	private IVars vars = null;;
	
	public DefValueVars(Object value) {
		this(null, value);
	}
	
	public DefValueVars(IVars vars, Object value) {
		this.vars = vars;
		this.value = value;
	}
	
	@Override
	public Object eval(String fun, List<Object> params) {
		Object r = null;
		if(null != vars && vars instanceof IFunVars)
			r = ((IFunVars)vars).eval(fun, params);
		if(null == r)
			return value;
		else
			return r;
	}

	@Override
	public Object get(String key) {
		Object r = null;
		if(null != vars)
			r = vars.get(key);
		if(null == r)
			return value;
		else
			return r;
	}

}
