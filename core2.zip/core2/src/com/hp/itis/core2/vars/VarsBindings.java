package com.hp.itis.core2.vars;

import java.util.Collection;
import java.util.Set;

import javax.script.Bindings;
import javax.script.SimpleBindings;

public class VarsBindings extends VarsMap implements Bindings {

	private Bindings bindings;
	
	public Bindings getBindings() {
		return bindings;
	}

	public void setBindings(Bindings bindings) {
		this.bindings = bindings;
	}

	public VarsBindings(IVars vars, Bindings bindings) {
		super(vars);
		this.bindings = bindings;
	}
	
	public VarsBindings(IVars vars) {
		this(vars, new SimpleBindings());
	}

	@Override
	public boolean containsKey(Object key) {
		if(bindings.containsKey(key))
			return true;
		return super.containsKey(key);
	}

	@Override
	public Object get(Object key) {
		Object r = bindings.get(key);
		if(null != r)
			return r;
		return super.get(key);
	}

	@Override
	public Object put(String name, Object value) {
		if(bindings.containsKey(name))
			return bindings.put(name, value);
		else if(super.containsKey(name)){
			return super.put(name, value);
		}
		return bindings.put(name, value);
	}

	@Override
	public Object remove(Object key) {
		if(bindings.containsKey(key))
			return bindings.remove(key);
		else
			return super.remove(key);
	}

	@Override
	public void clear() {
		bindings.clear();
	}

	@Override
	public boolean containsValue(Object value) {
		return bindings.containsValue(value);
	}

	@Override
	public Set<java.util.Map.Entry<String, Object>> entrySet() {
		return bindings.entrySet();
	}

	@Override
	public boolean isEmpty() {
		return bindings.isEmpty();
	}

	@Override
	public Set<String> keySet() {
		return bindings.keySet();
	}

	@Override
	public int size() {
		return bindings.size();
	}

	@Override
	public Collection<Object> values() {
		return bindings.values();
	}
	
	

}
