package com.hp.itis.core2.vars;

import java.util.Iterator;
import java.util.List;

import com.hp.itis.core2.commdata.TypeCaster;

public class ListVars extends PrefixedVars implements IEnumerableVars,
		IWritableVars {

	private List<Object> list;
	
	public ListVars(List<Object> list) {
		this.list = list;
	}

	@Override
	public Object get(String key) {
		int i = getIndex(key);
		if(i>=0 && list.size()>i)
			return list.get(i);
		return null;
	}
	
	private int getIndex(String key) {
		int i = -1;
		if(null != key && !"".equals(key))
			try {
				i = TypeCaster.toNumber(key).intValue();
			}
			catch(Throwable e){};
		return i;
	}

	@Override
	public Iterator<String> iterator() {
		return new Iterator<String>() {
			Integer i= 0;
			@Override
			public boolean hasNext() {
				return list.size()>i;
			}

			@Override
			public String next() {
				String r = i.toString();
				i++;
				return r;
			}

			@Override
			public void remove() {
				list.remove(i);
				i--;
			}
		};
	}

	@Override
	public void put(String key, Object value) {
		if((null == key || "".equals(key)) && null != value)
			list.add(value);
		int i = getIndex(key);
		if(i>=0 && list.size()>i && null != value)
			list.set(i, value);
	}

	@Override
	public boolean contains(String key) {
		int i = getIndex(key);
		return (i>=0 && list.size()>i);
	}

	@Override
	public int size() {
		return list.size();
	}

}
