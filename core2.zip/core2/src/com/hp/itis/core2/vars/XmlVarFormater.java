package com.hp.itis.core2.vars;

public class XmlVarFormater extends DefaultVarFormater {
	
	@Override
	public String format(Object var, IVarHolder holder) {
		String r = super.format(var, holder);
		return encode(r);
	}
	
	private String encode(Object o) {
		if(null == o)
			return null;
		String s = o.toString();
		s = s.replace("&", "&amp;");
		s = s.replace("<", "&lt;");
		s = s.replace(">", "&gt;");
		s = s.replace("\"", "&quot;");
		return s;
	}
	
}
