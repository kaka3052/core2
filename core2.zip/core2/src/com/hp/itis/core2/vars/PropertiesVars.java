package com.hp.itis.core2.vars;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.Properties;

import com.hp.itis.core2.file.TextFile;

public class PropertiesVars extends PrefixedVars implements IPersistentVars, IEnumerableVars {
	private Properties properties;
	private String resName = null;
	private boolean xmlFormat = false;
	
	public PropertiesVars(Properties properties) {
		this.properties = properties;
	}
	
	public PropertiesVars(String resName) {
		this(resName, null);
	}
	
	public PropertiesVars(String resName, IVars vars) {
		this(resName, vars, resName.toLowerCase().endsWith(".xml"));
	}
	
	public PropertiesVars(String resName, IVars vars, boolean xmlFormat) {
		this.resName = resName;
		this.xmlFormat = xmlFormat;
		load(vars);
	}
	
	@Override
	public Object get(String key) {
		return properties.get(key);
	}

	@Override
	public void load() {
		load(null);
	}
	
	public void load(IVars vars) {
		if(null == resName)
			return;
		properties = new Properties();
		InputStream is = null;
		is = TextFile.getResource(resName);
		if(null == is)
			throw new RuntimeException("Can not load resource by name: " + resName);
		if(null != vars) {
			String t = TextFile.load(is);
			IVarReplacer pat = new AdvanceVarReplacer(t);
			t = pat.replace(vars);
			is = new ByteArrayInputStream(t.getBytes());
		}
		try {
			if(is != null) {
				if(xmlFormat)
					properties.loadFromXML(is);
				else
					properties.load(is);
			}
		} catch (Exception e) {}
		finally {
			if(null != is)
				try {
					is.close();
				} catch (IOException e) {}
		}
	}

	@Override
	public void save() {
		if(null == resName)
			return;
		OutputStream os = null;
		try {
			os = new FileOutputStream(resName);
			if(xmlFormat)
				properties.storeToXML(os, "");
			else
				properties.store(os, "");
		} catch (Exception e) {
			
		}
		finally {
			if(null != os)
				try {
					os.close();
				} catch (IOException e) {}
		}
	}

	@Override
	public void put(String key, Object value) {
		properties.put(key, value);
	}

	public boolean isXmlFormat() {
		return xmlFormat;
	}

	public void setXmlFormat(boolean xmlFormat) {
		this.xmlFormat = xmlFormat;
	}

	@Override
	public Iterator<String> iterator() {
		final Iterator<Object> keyset = properties.keySet().iterator();
		return new Iterator<String>() {

			@Override
			public boolean hasNext() {
				return keyset.hasNext();
			}

			@Override
			public String next() {
				return keyset.next().toString();
			}

			@Override
			public void remove() {
				keyset.remove();
			}
			
		};
	}

	@Override
	public boolean contains(String key) {
		return properties.containsKey(key);
	}

	@Override
	public int size() {
		return properties.size();
	}

}
