package com.hp.itis.core2.vars;

import java.util.Date;
import java.util.List;

import com.hp.itis.core2.commdata.TypeCaster;

public class GetterVars extends PrefixedVars implements IFunVars, IGetterVars {
	protected IVars vars;

	public GetterVars() {
	}

	public GetterVars(IVars vars) {
		this.vars = vars;
	}

	@Override
	public Object eval(String fun, List<Object> params) {
		if (null != vars)
			return ((IFunVars) vars).eval(fun, params);
		return null;
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#get(java.lang.String)
	 */
	@Override
	public Object get(String key) {
		if (null != vars)
			return vars.get(key);
		return null;
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#getInt(java.lang.String)
	 */
	final public int getInt(String key) {
		return (Integer) TypeCaster.cast(Integer.class, get(key));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#getChar(java.lang.String)
	 */
	final public char getChar(String key) {
		return (Character) TypeCaster.cast(Character.class, get(key));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#getByte(java.lang.String)
	 */
	final public byte getByte(String key) {
		return (Byte) TypeCaster.cast(Byte.class, get(key));
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#getFloat(java.lang.String)
	 */
	final public float getFloat(String key) {
		return (Float) TypeCaster.cast(Float.class, get(key));
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#getShort(java.lang.String)
	 */
	final public short getShort(String key) {
		return (Short) TypeCaster.cast(Short.class, get(key));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#getDouble(java.lang.String)
	 */
	final public double getDouble(String key) {
		return (Double) TypeCaster.cast(Double.class, get(key));
	}
	
	@Override
	public Number getNumber(String key) {
		return TypeCaster.toNumber(get(key));
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#getBoolean(java.lang.String)
	 */
	final public boolean getBoolean(String key) {
		return (Boolean) TypeCaster.cast(Boolean.class, get(key));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#getLong(java.lang.String)
	 */
	public long getLong(String key) {
		return (Long) TypeCaster.cast(Long.class, get(key));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#getString(java.lang.String)
	 */
	final public String getString(String key) {
		Object o = get(key);
		if (o == null)
			return null;

		return o.toString();
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#getDate(java.lang.String)
	 */
	public Date getDate(String key) {
		return (Date) TypeCaster.cast(Date.class, get(key));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#get(java.lang.String, int)
	 */
	public int get(String key, int def) {
		return (Integer) get(key, new Integer(def));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#get(java.lang.String, char)
	 */
	public char get(String key, char def) {
		return (Character) get(key, new Character(def));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#get(java.lang.String, byte)
	 */
	public byte get(String key, byte def) {
		return (Byte) get(key, new Byte(def));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#get(java.lang.String, long)
	 */
	public long get(String key, long def) {
		return (Long) get(key, new Long(def));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#get(java.lang.String, float)
	 */
	public float get(String key, float def) {
		return (Float) get(key, new Float(def));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#get(java.lang.String, short)
	 */
	public short get(String key, short def) {
		return (Short) get(key, new Short(def));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#get(java.lang.String, double)
	 */
	public double get(String key, double def) {
		return (Double) get(key, new Double(def));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#get(java.lang.String, boolean)
	 */
	public boolean get(String key, boolean def) {
		return (Boolean) get(key, new Boolean(def));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#get(java.lang.String, java.lang.String)
	 */
	public String get(String key, String def) {
		return (String) get(key, (Object) def);
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#get(java.lang.String, java.util.Date)
	 */
	public Date get(String key, Date def) {
		return (Date) get(key, (Object) def);
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.vars.IGetterVars#get(java.lang.String, java.lang.Object)
	 */
	public Object get(String key, Object def) {
		Object r = get(key);
		if (r != null && def != null) {
			try {
				return TypeCaster.cast(def.getClass(), r);
			} catch (Exception e) {
			}
		}
		return def;
	}

}
