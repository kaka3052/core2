package com.hp.itis.core2.vars;

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Set;


public class VarsMap extends AbstractMap<String, Object> {
	
	private IVars vars;

	public VarsMap(IVars vars) {
		this.vars = vars;
	}
	
	@Override
    public int size() {
		if(vars instanceof IEnumerableVars)
			return((IEnumerableVars)vars).size();
		return 0;
	}
	
	@Override
	public boolean containsKey(Object key) {
		if(null == key)
			return false;
		if(vars instanceof IEnumerableVars)
			return((IEnumerableVars)vars).contains(key.toString());
		return null != vars.get(key.toString());
	}
	
	@Override
	public Object get(Object key) {
		if(null == key)
			return null;
		return vars.get(key.toString());
	}
	
	@Override
    public Object put(String key, Object value) {
    	if(vars instanceof IWritableVars) {
    		((IWritableVars)vars).put(key, value);
    		return value;
    	}
    	return null;
    }
	
	public Set<String> keySet() {
		if(vars instanceof IEnumerableVars) {
			return new AbstractSet<String>() {

				@Override
				public Iterator<String> iterator() {
					return ((IEnumerableVars)vars).iterator();
				}

				@Override
				public int size() {
					return ((IEnumerableVars)vars).size();
				}

			};
		}
		return super.keySet();
	}

	@Override
	public Set<java.util.Map.Entry<String, Object>> entrySet() {
		if(vars instanceof IEnumerableVars) {
			final Iterator<String> it = ((IEnumerableVars)vars).iterator();
			return new AbstractSet<java.util.Map.Entry<String, Object>>() {

				@Override
				public Iterator<java.util.Map.Entry<String, Object>> iterator() {
					return new Iterator<java.util.Map.Entry<String, Object>>() {

						@Override
						public boolean hasNext() {
							return it.hasNext();
						}

						@Override
						public java.util.Map.Entry<String, Object> next() {
							String key = it.next();
							return new SimpleImmutableEntry<String, Object>(key, vars.get(key));
						}

						@Override
						public void remove() {
							it.remove();
						}
					};
				}

				@Override
				public int size() {
					return ((IEnumerableVars)vars).size();
				}
				
			};
		}
    	throw new UnsupportedOperationException();
	}

	public IVars getVars() {
		return vars;
	}

	public void setVars(IVars vars) {
		this.vars = vars;
	}



}
