package com.hp.itis.core2.vars;


/**
 * 变量表接口
 * @see IReplacer
 * @author changjiang
 *
 */

public interface IVars {
	/**
	 * 取得指定名称的变量值
	 * @param key 变量名
	 * @return 变量值
	 */
	public Object get(String key);
	
}
