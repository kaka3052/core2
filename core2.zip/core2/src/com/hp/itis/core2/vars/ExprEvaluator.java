package com.hp.itis.core2.vars;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.christopherschultz.evaluator.EvaluationContext;
import net.christopherschultz.evaluator.EvaluationException;
import net.christopherschultz.evaluator.Expression;
import net.christopherschultz.evaluator.ExpressionVisitor;
import net.christopherschultz.evaluator.Function;
import net.christopherschultz.evaluator.StandardFunction;
import net.christopherschultz.evaluator.parser.ExpressionParser;
import net.christopherschultz.evaluator.util.DefaultEvaluationContext;

import com.hp.itis.core2.commdata.TypeCaster;

public class ExprEvaluator extends AbstractEvaluator {
	
	private Expression exp;
	private VarsEvaluationContext ec = new VarsEvaluationContext();
	private Throwable lastError;
	
	protected class VarsEvalFunction extends Expression implements Function {

		@SuppressWarnings("unchecked")
		@Override
	    public final Object call(EvaluationContext ec,
			     String functionName,
			     List argumentExpressions) throws EvaluationException {
	    	return this.call(ec, functionName, StandardFunction.getExpressionValueArray(ec, argumentExpressions));
	    }
	    
		public Object call(EvaluationContext ec, String functionName, Object[] params)
				throws EvaluationException {
			
			if(null == functionName || functionName.length()==0)
	    		return null;
			List<Object> args = new ArrayList<Object>();
			if(null != params)
				for(int i=0; i<params.length; i++)
					args.add(params[i]);
	    	char typeChar = functionName.charAt(0);
	    	if(typeChar=='$' || typeChar=='#' || typeChar=='@')
	    		functionName = functionName.substring(1);
	    	if(functionName.length()==0 && args.size()>0)
	    		return castTo(typeChar, args.get(0));
	    	if(vars instanceof IFunVars)
	    		return castTo(typeChar, ((IFunVars)vars).eval(functionName, args));
	    	return null;
		}

		@Override
		public void acceptVisitor(ExpressionVisitor arg0) {
		}

		@Override
		public Object evaluate(EvaluationContext arg0)
				throws EvaluationException {
			return null;
		}

		@SuppressWarnings("unchecked")
		@Override
		public List getSubExpressions() {
			return null;
		}

	}
	
	protected class VarsEvaluationContext implements EvaluationContext {

		EvaluationContext def = new DefaultEvaluationContext().loadStandard();
		VarsEvalFunction varsEvalFunction = new VarsEvalFunction();

	    public Object get(String identifier)
	    {
	    	if(null == identifier || identifier.length()==0)
	    		return null;
	    	char typeChar = identifier.charAt(0);
	    	if(typeChar=='$' || typeChar=='#' || typeChar=='@')
	    		identifier = identifier.substring(1);
	    	Object value = null;
	    	if(null != vars)
	    		value = castTo(typeChar, vars.get(identifier));
	    	if(null == value)
	    		value = def.get(identifier);
	        if(null != vars && null == value)
	            value = varsEvalFunction;
	        if(null == value)
	        	return value;
	        return value;
	    }

		@SuppressWarnings("unchecked")
		@Override
		public Map getAll() {
			return def.getAll();
		}

		@Override
		public Object getProperty(String key) {
			return def.getProperty(key);
		}

		@Override
		public Object remove(String identifier) {
			return def.remove(identifier);
		}

		@Override
		public void removeProperty(Object key) {
			def.removeProperty(key);
		}

		@Override
		public Object set(String identifier, Object value) {
			return def.set(identifier, value);
		}

		@Override
		public void setProperty(String key, Object value) {
			def.setProperty(key, value);
		}
	}

    private static Object castTo(char typeChar, Object value) {
        if(null == value)
        	return value;
    	switch(typeChar) {
    		case '$': return value.toString(); 
    		case '#': return TypeCaster.toNumber(value); 
    		case '@': return TypeCaster.toBoolean(value); 
    	}
    	return value;
    }
	
	@Override
	public Object eval() {
		try {
			Object r = exp.evaluate(ec);
			if(r instanceof Expression) {
				r = ((Expression)r).evaluate(ec);
			}
			lastError = null;
			return r;
		} catch (EvaluationException e) {
			lastError = e;
			return null;
		}
	}

	@Override
	public Boolean prepare(String pattern) {
		try {
			exp = ExpressionParser.parseExpression(pattern);
			lastError = null;
		} catch (Throwable e) {
			lastError = e;
			return false;
		}
		return true;
	}
	
	public Throwable getLastError() {
		return lastError;
	}

	public static IEvaluator build(String pattern) {
		ExprEvaluator eval = new ExprEvaluator();
		if(eval.prepare(pattern))
			return eval;
		else {
			if(null != eval.lastError)
				throw new RuntimeException(eval.lastError);
			return null;
		}
	}

}
