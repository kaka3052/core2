package com.hp.itis.core2.vars;

import java.util.regex.Matcher;

/**
 * 正则匹配变量表
 * 
 * @author changjiang
 *
 */
public class ReMatcherVars extends PrefixedVars {

	private Matcher matcher;
	
	public ReMatcherVars(Matcher matcher, String prefix)
	{
		this.matcher = matcher;
	}
	
	public ReMatcherVars(Matcher matcher)
	{
		this(matcher, null); 
	}

	public Object get(String key) {
		try
		{
			int index = Integer.valueOf(key);
			return matcher.group(index);
		}
		catch(Exception e)
		{
			return null;
		}
	}

}
