package com.hp.itis.core2.vars;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.hp.itis.core2.commdata.FieldMapper;
import com.hp.itis.core2.commdata.TypeCaster;


public class PojoVars extends PrefixedVars implements IWritableVars, IFunVars, IEnumerableVars {
	private Object pojo;
	private Map<String, Method> getters;
	private Map<String, Method> setters;
	private Map<String, Method> funs;

	public PojoVars(Object pojo) {
		this();
		setPojo(pojo);
	}
	
	public PojoVars() {
	}
	
	public void setPojo(Object pojo) {
		this.pojo = pojo;
		Method[] methods = pojo.getClass().getMethods();
		Method m;
		for (int i = 0; i < methods.length; i++) {
			m = methods[i];
			//if(!m.getDeclaringClass().isAssignableFrom(Object.class)) {
			String fName = FieldMapper.getterName(m);
			if(fName != null)
				getters().put(fName, m);
			else {
				fName = FieldMapper.setterName(m);
				if(fName != null)
					setters().put(fName, m);
				else
					funs().put(m.getName(), m);
			}
			//}
		}
	}

	@Override
	public Object eval(String fun, List<Object> params) {
		if(null == funs)
			return null;
		if(null == fun)
			return null;
		Method m;
		try {
			if(params == null) {
				m = funs.get(fun);
				if(null != m)
					return m.invoke(pojo);
			}
			else {
				m = funs.get(fun);
				if(null != m) {
					Class<?>[] paramTypes = m.getParameterTypes();
					Object[] args = ClassEvaluator.makeParams(params, paramTypes);
					return m.invoke(pojo, args);
				}
			}
		}
		catch(Exception e){};
		return null;
	}
	
	private Map<String, Method> getters() {
		if(null == getters)
			getters = new LinkedHashMap<String, Method>();
		return getters;
	}
	
	private Map<String, Method> setters() {
		if(null == setters)
			setters = new LinkedHashMap<String, Method>();
		return setters;
	}
	
	private Map<String, Method> funs() {
		if(null == funs)
			funs = new HashMap<String, Method>();
		return funs;
	}

	@Override
	public Object get(String key) {
		if(null == key)
			return null;
		if(null == getters)
			return null;
		Method m = getters.get(key);
		if(null == m)
			return null;
		try {
			return m.invoke(pojo);
		}
		catch(Exception e){};
		return null;
	}

	@Override
	public void put(String key, Object value) {
		if(null == key)
			return;
		if(null == setters)
			return;
		Method m = setters.get(key);
		if(null == m)
			return;
		try {
			Class<?> pType = m.getParameterTypes()[0];
			m.invoke(pojo, TypeCaster.cast(pType, value));
		}
		catch(Exception e){
			//throw new RuntimeException(e);
		};
	}
	

	public static boolean extractPojo(IVars vars, Object pojo) {
		Class<?> c = pojo.getClass();
		Method ms[] = c.getDeclaredMethods();
		Method m;
		for(int i = 0; i < ms.length; i++) {
			m = ms[i];
			String fName = FieldMapper.setterName(m);
			if (null != fName) {
				//调用set方法，设置pojo相应属性
				Object[] param = new Object[1];
				//对特殊类型进行必要的转换
				Class<?> pType = m.getParameterTypes()[0];
				Object o = vars.get(fName);
				if(pType.isPrimitive() && null == o)
					continue;
				param[0] = TypeCaster.cast(pType, o);
				try {
					m.invoke(pojo, param);
				} catch (Exception e) {
					return false;
				}
			}
		}
		return true;
	}

	@Override
	public Iterator<String> iterator() {
		return getters().keySet().iterator();
	}

	@Override
	public boolean contains(String key) {
		return getters().containsKey(key) || funs.containsKey(key);
	}

	@Override
	public int size() {
		return getters().size();
	}
}
