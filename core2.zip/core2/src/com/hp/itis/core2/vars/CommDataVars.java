package com.hp.itis.core2.vars;

import java.util.Iterator;

import com.hp.itis.core2.commdata.CommData;

public class CommDataVars extends PrefixedVars implements IEnumerableVars, IWritableVars {

	private CommData commData = null;

	@Override
	public Object get(String key) {
		if(null == commData)
			return null;
		else
			return commData.get(key);
	}

	public CommDataVars(CommData commData) {
		this.commData = commData;
	}
	
	public CommDataVars() {

	}
	
	public void setCommData(CommData commData) {
		this.commData = commData;
	}
	
	@Override
	public Iterator<String> iterator() {
		return commData.keySet().iterator();
	}

	@Override
	public void put(String key, Object value) {
		commData.put(key, value);
	}

	@Override
	public boolean contains(String key) {
		return commData.keySet().contains(key);
	}

	@Override
	public int size() {
		return commData.keySet().size();
	}
}
