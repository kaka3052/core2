package com.hp.itis.core2.vars;

abstract public class AbstractEvaluator implements IEvaluator {
	
	protected IVars vars = null;

	@Override
	public Object eval(IVars vars) {
		this.vars = vars;
		return eval();
	}

	@Override
	abstract public Object eval();

	@Override
	public Boolean prepare(String pattern, IVars vars) {
		this.vars = vars;
		return prepare(pattern);
	}

	@Override
	abstract public Boolean prepare(String pattern);

	@Override
	public IVars getVars() {
		return vars;
	}

	@Override
	public void setVars(IVars vars) {
		this.vars = vars;
	}

}
