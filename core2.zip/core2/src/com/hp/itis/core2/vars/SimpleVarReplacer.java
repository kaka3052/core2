package com.hp.itis.core2.vars;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 简单变量替换器<p>
 * 该替换器仅实现了变量替换，无法进行函数替换。<p>
 * @see com.boco.util.replacer.IVarReplacer
 * @see com.boco.util.replacer.AdvanceVarReplacer
 * @author changjiang
 *
 */
public class SimpleVarReplacer implements IVarReplacer{
	protected char leftBracket = '{';
	protected char rightBracket = '}';
	protected ArrayList<String> texts = new ArrayList<String>();
	protected ArrayList<IVarHolder> varDefs = new ArrayList<IVarHolder>();
	protected char leadingChar = '$';
	protected char bracket = '{';
	protected IVarFormater formater;
	
	public SimpleVarReplacer(String pattern)
	{
		this(pattern, '$', '{');
	}
	
	public SimpleVarReplacer(String pattern, char leadingChar, char bracket) {
		this(pattern, leadingChar, bracket, null);
	}
	
	public SimpleVarReplacer(String pattern, char leadingChar, char bracket, IVarFormater formater)
	{
		this.leadingChar = leadingChar;
		this.bracket = bracket;
		buildVarPattern();
		prepare(pattern);
		if(null == formater)
			formater = new DefaultVarFormater();
		this.formater = formater;
	}
	
	public void setFormater(IVarFormater formater) {
		this.formater = formater;
	}
	
	protected void buildVarPattern()
	{
		switch(bracket)
		{
			case '[':
				leftBracket = bracket;
				rightBracket = ']';
				break;
			case '(':
				leftBracket = bracket;
				rightBracket = ')';
				break;
			case '<':
				leftBracket = bracket;
				rightBracket = '>';
				break;
			default: //{
				leftBracket = bracket;
				rightBracket = '}';
		}
	}
	
	/**
	 * 准备变量替换
	 */
	public Boolean prepare(String pattern)
	{
		Pattern varPattern = Pattern.compile("\\" + leadingChar + "\\" + leftBracket + "(.+?)(:(.+?))?\\" + rightBracket);
		Matcher exprParser = varPattern.matcher(pattern);
		int pos;
		for(pos=0; exprParser.find(pos); pos=exprParser.end())
		{
			texts.add(pattern.substring(pos, exprParser.start()));
			varDefs.add(new VarHolder(exprParser.group(0), exprParser.group(1), exprParser.group(3)));
			
		}
		texts.add(pattern.substring(pos));
		return true;
	}
	
	private Object getValue(IVars vars, String key)
	{
		if(key.startsWith("__$"))
			return vars.get(key.substring(3));
		else
			return key;
	}
	
	/**
	 * 进行变量替换
	 */
	public String replace(IVars vars)
	{
		StringBuffer result = new StringBuffer();
		for(int i=0; i<varDefs.size(); i++)
		{
			result.append(texts.get(i));
			IVarHolder holder = varDefs.get(i);
			Object varValue = null;
			if(null==holder.params())
				varValue = vars.get(holder.name()); //变量替换
			else
			{
				ArrayList<Object> vParams = new ArrayList<Object>();
				for(String param :holder.params())
				{
					vParams.add(getValue(vars, param));
				}
				if("=".equals(holder.name()) && vParams.size()>0) {
					try {
						IEvaluator eval = Evaluator.build(vParams.get(0).toString());
						varValue = eval.eval(vars);
					} 
					catch(Exception e) {
						//e.printStackTrace();
						varValue = null;
					}
				}
				else {
					if(vars instanceof IFunVars)
						varValue = ((IFunVars)vars).eval(holder.name(), vParams); //函数替换
				}
			}
			//使用默认值
			if(null == varValue)
			{
				String defValue = holder.defValue();
				if(null != defValue)
				{
					varValue = getValue(vars, defValue);
				}
			}
			result.append(formater.format(varValue, holder));
		}
		result.append(texts.get(texts.size()-1));
		return result.toString();
	}

	@Override
	public List<IVarHolder> getHolders() {
		return varDefs;
	}
	
	public static String replace(String pat, IVars... vars) {
		if(vars.length==0)
			return pat;
		if(vars.length==1)
			return (new SimpleVarReplacer(pat)).replace(vars[0]);
		return (new SimpleVarReplacer(pat)).replace(new CombinedVars(vars));
	}
	
}
