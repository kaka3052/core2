package com.hp.itis.core2.vars;

import java.lang.reflect.Constructor;
import java.util.List;

public class VarReplacer implements IVarReplacer {

	private static Class<? extends IVarReplacer> replacerClass = AdvanceVarReplacer.class;
	private IVarReplacer replacer;
	
	private  VarReplacer(IVarReplacer replacer) {
		this.replacer = replacer;
	}
	
	@Override
	public List<IVarHolder> getHolders() {
		return replacer.getHolders();
	}

	@Override
	public Boolean prepare(String pattern) {
		return replacer.prepare(pattern);
	}

	@Override
	public String replace(IVars vars) {
		return replacer.replace(vars);
	}
	
	public static IVarReplacer build(String pattern) {
		try {
			Constructor<? extends IVarReplacer> constructor = replacerClass.getConstructor(String.class);
			return new VarReplacer(constructor.newInstance(pattern));
		} catch (Exception e) {
		}
		return null;
	}
	
	public static IVarReplacer build(String pattern, char leadingChar, char bracket) {
		try {
			Constructor<? extends IVarReplacer> constructor = replacerClass.getConstructor(String.class, char.class, char.class);
			return new VarReplacer(constructor.newInstance(pattern, leadingChar, bracket));
		} catch (Exception e) {
		}
		return null;
	}
	
	public static String replace(String pattern, IVars vars) {
		return build(pattern).replace(vars);
	}
	
	public static void setReplacerClass(Class<? extends IVarReplacer> replacerClass) {
		VarReplacer.replacerClass = replacerClass;
	}

	public static Class<? extends IVarReplacer> getReplacerClass() {
		return replacerClass;
	}

	@Override
	public void setFormater(IVarFormater formater) {
		replacer.setFormater(formater);
	}
}
