package com.hp.itis.core2.vars;

import java.util.List;

/**
 * 变量替换器接口
 * @see IVars
 * @author changjiang
 *
 */
public interface IVarReplacer {
	
	/**
	 * 初始化变量替换器模板
	 * @param pattern 替换模板
	 * @return 成功与否
	 */
	Boolean prepare(String pattern);
	
	/**
	 * 执行替换
	 * @param vars 变量列表
	 * @return 替换结果
	 */
	String replace(IVars vars);
	
	/**
	 * 取得变量占位器列表
	 */
	List<IVarHolder> getHolders();
	
	void setFormater(IVarFormater formater);
	
}
