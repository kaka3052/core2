package com.hp.itis.core2.vars;


/**
 * 含前缀的变量类
 * 
 * @author changjiang
 *
 */

public class PrefixedVars implements IPrefixedVars {
	
	private String prefix = null;
	private IVars vars;
	
	public String prefix() {
		return prefix;
	}

	public void prefix(String value) {
		prefix = value;
	}
	
	public IVars vars() {
		return vars;
	}
	
	public void vars(IVars vars) {
		this.vars = vars;
	}
	
	public PrefixedVars() {
		
	}
	
	public PrefixedVars(String prefix) {
		this.prefix = prefix;
	}
	
	public PrefixedVars(IVars vars, String prefix) {
		this.prefix = prefix;
		this.vars = vars;
	}

	public Object get(String key) {
		if(null == vars)
			return null;
		if(null != prefix && null != key && key.startsWith(prefix + ".")) {
			key = key.substring(prefix.length()+1);
		}
		return vars.get(key);
	}

}
