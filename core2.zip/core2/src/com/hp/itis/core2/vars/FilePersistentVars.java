package com.hp.itis.core2.vars;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class FilePersistentVars extends PrefixedVars implements IPersistentVars{
	private Map<String, Object> vars = null;
	private File file;
	
	
	public FilePersistentVars(String fileName) throws IOException {
		this(new File(fileName));
	}
	
	public FilePersistentVars(String fileName, Map<String, Object> vars) throws IOException {
		this(new File(fileName), vars);
	}
	
	public FilePersistentVars(File file, Map<String, Object> vars) throws IOException
	{
		if(null == vars)
			this.vars = new LinkedHashMap<String, Object>();
		else
			this.vars = vars;
		this.file = file;
		load();
	}
	
	public FilePersistentVars(File file) throws IOException
	{
		this(file, null);
	}
	
	public Object get(String key)
	{
		return vars.get(key);
	}
	
	public void put(String key, Object value)
	{
		vars.put(key, value);
	}
	
	public void load() throws IOException
	{
		if(!file.exists())
			return;
		BufferedReader br = null;
		try {
			FileInputStream fis = new FileInputStream(file);
			br = new BufferedReader(new InputStreamReader(fis));
			while(true)
			{
				String line = br.readLine();
				if(null == line)
					break;
				int kb = line.indexOf('=');
				if(kb<0)
				{
					if(line.length()>0)
						vars.put(line, "");
				}
				else
					vars.put(line.substring(0, kb), line.substring(kb+1, line.length()));
			}			
		}
		finally
		{
			if(br!=null)
			{
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	public void save() throws IOException
	{
		if(!file.exists())
			file.getParentFile().mkdirs();
		BufferedWriter bw = null;
		try {
			FileOutputStream fos = new FileOutputStream(file, false);
			bw = new BufferedWriter(new OutputStreamWriter(fos));
			for(Entry<String, Object> pair: vars.entrySet())
			{
				bw.write(pair.getKey());
				bw.write("=");
				bw.write(pair.getValue().toString());
				bw.write("\n");
			}
			bw.close();
		}
		finally
		{
			if(bw != null)
				try {
					bw.close();
				} catch (IOException e) {}
		}
	}
	
}
