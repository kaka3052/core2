package com.hp.itis.core2.vars;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CmdLineVars extends MapVars<String> {

	public CmdLineVars(String[] args) {
		parseParams(args);
	}

	private void parseParams(String[] args)
	{
		Pattern pattern = Pattern.compile("^\\-{0,2}(.+?)(=(.*))?$");
		for(int i=0; i < args.length; i++)
		{
			Matcher matcher = pattern.matcher(args[i]);
			if(matcher.find())
			{				
				if(null == matcher.group(2))
					map.put(matcher.group(1), "true");	//输入变量没设值，值默认设为true
				else
					map.put(matcher.group(1), matcher.group(3));//输入变量设有值，保存变量->值
			}
		}
	}

}
