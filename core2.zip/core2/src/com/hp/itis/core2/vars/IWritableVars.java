package com.hp.itis.core2.vars;

/**
 * 可写入的变量表接口
 * 
 * @author changjiang
 *
 */
public interface IWritableVars extends IVars {
	public void put(String key, Object value);
}
