package com.hp.itis.core2.vars;

public interface IEvaluator {
	/**
	 * 初始化表达式解析器模板
	 * @param pattern 解析器模板
	 * @return 成功与否
	 */
	Boolean prepare(String pattern, IVars vars);
	Boolean prepare(String pattern);
	
	/**
	 * 执行解析
	 * @param vars 变量列表
	 * @return 解析结果
	 */
	Object eval(IVars vars);
	Object eval();
	
	/**
	 * 表达式变量
	 * @return
	 */
	IVars getVars();
	void setVars(IVars vars);
	
	Throwable getLastError();

}
