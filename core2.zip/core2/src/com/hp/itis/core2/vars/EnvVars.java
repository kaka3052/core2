package com.hp.itis.core2.vars;


/**
 * 环境变量表
 * 
 * @author changjiang
 *
 */
public class EnvVars extends PrefixedVars {
	IVars vars = null;
	public EnvVars()
	{
		vars = new MapVars<String>(System.getenv());
	}

	public Object get(String key) {
		return vars.get(key);
	}

}
