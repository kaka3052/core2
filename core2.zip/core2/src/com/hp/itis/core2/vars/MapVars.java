package com.hp.itis.core2.vars;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Map变量表实现类
 * 
 * @author changjiang
 *
 */
public class MapVars<T extends Object> extends PrefixedVars implements IWritableVars, IEnumerableVars {
	protected Map<String, T> map;
	
	public MapVars(Map<String, T> map)
	{
		this.map = map;
	}
	
	public MapVars()
	{
		this.map = new LinkedHashMap<String, T>();
	}
	
	public Object get(String key) {
		if(null == map)
			return null;
		else
			return map.get(key);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void put(String key, Object value) {
		if(value != null)
			map.put(key, (T)value);
		else
			map.remove(key);
	}

	@Override
	public Iterator<String> iterator() {
		return map.keySet().iterator();
	}

	@Override
	public boolean contains(String key) {
		return map.containsKey(key);
	}

	@Override
	public int size() {
		return map.size();
	}
}
