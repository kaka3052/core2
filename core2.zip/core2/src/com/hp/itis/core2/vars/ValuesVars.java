package com.hp.itis.core2.vars;


public class ValuesVars extends MapVars<Object> implements IEnumerableVars, IWritableVars {

	public ValuesVars(Object... v) {
		for(int i=0; i<v.length-1; i=i+2)
			if(v[i] != null)
				map.put(v[i].toString(), v[i+1]);
	}

}
