package com.hp.itis.core2.task;

public interface IOneTimeTask extends ITask {
	public static final int DEF_TIMELIMIT = 30*60*1000;
	
}
