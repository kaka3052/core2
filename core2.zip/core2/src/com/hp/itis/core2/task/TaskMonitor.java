package com.hp.itis.core2.task;

public class TaskMonitor extends ActiveModule implements IExecutionEventSink {

	private int stopWaitTime = 1000;
	private int intervalSeconds = 10;
	
	public boolean inmmortal()
	{
		return true;
	}
	
	public void setStopWaitTime(int value)
	{
		stopWaitTime = value;
	}
	
	public void setIntervalSeconds(int value)
	{
		intervalSeconds = value;
	}
	
	public long interval()
	{
		return intervalSeconds * 1000;
	}
	
	private void checkHangUps()
	{
		long currentTime = System.currentTimeMillis();
		for(IExecution e: TaskService.getRunningExecutions())
		{
			if(null != e.taskRunner())
			{
				if(e.task().timeLimit()>0 &&
						currentTime - e.taskRunner().activeTime() > e.task().timeLimit())
				{
					if(e.task() instanceof IDurableTask)
						e.restart(stopWaitTime);
					else
						e.cancel(stopWaitTime);
				}
			}
		}
	}
	
	@Override
	public void run() {
		checkHangUps();
	}

	public void onExecutionEvent(IExecution execution, ExecutionEvent event) {
		
	}

}
