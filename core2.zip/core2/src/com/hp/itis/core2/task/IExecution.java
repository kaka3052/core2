package com.hp.itis.core2.task;


public interface IExecution extends IRunnerEventSink{
	
	enum ExecutionState{READY, RUNNING, CANCELED, FINISHED, PAUSED, BLOCKED}
	
	ITask task();
	
	ITaskRunner taskRunner();
	
	void start();
	
	void cancel(int wait);
	
	void restart(int wait);
	
	ExecutionState getState();
	
	int getId();
	
	String getName();
	
	long getCreateTime();
	
	boolean waitFinish(int miliSeconds);

}
