package com.hp.itis.core2.task;

public interface ITask extends Runnable {
	String name();
	int timeLimit();
	void onCancel();
}
