package com.hp.itis.core2.task;

public interface IExecutionFactory {
	
	IExecution newExecution(ITask task, IExecutionEventSink eventListener);
	
}
