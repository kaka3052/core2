package com.hp.itis.core2.task;

abstract public class ExecutiveTask implements IExecutiveTask {

	private String name = null;
	private IExecution execution = null;
	
	public void cancel() {
		cancel(-1);
	}
	
	public IExecution execution() {
		return execution;
	}

	public IExecution execute() {
		execution =  TaskService.execute(this);
		return execution;
	}

	public IExecution getExecution() {
		return execution;
	}
	
	public void cancel(int wait) {
		if(null != execution)
			execution.cancel(wait);
	}

	public void pause() {
		if(null != execution)
		{
			if(null != execution.taskRunner())
				execution.taskRunner().pause();
		}
	}
	
	public void act() {
		if(null != execution)
		{
			if(null != execution.taskRunner())
				execution.taskRunner().doActive();
		}
	}

	public void resume() {
		if(null != execution)
		{
			if(null != execution.taskRunner())
				execution.taskRunner().resume();
		}
		else
			execute();
	}

	public void setListener(IExecutionEventSink listener) {
		TaskService.setTaskEventListenner(this, listener);
	}

	public String name() {
		if(name == null)
			return this.getClass().getSimpleName();
		return name;
	}
	
	public void setName(String value) {
		name = value;
	}

	public void onCancel() {
		
	}

	public int timeLimit() {
		return 0;
	}

	abstract public void run();
}
