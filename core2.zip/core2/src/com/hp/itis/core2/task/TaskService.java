package com.hp.itis.core2.task;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

public class TaskService {

	private static List<IExecutionEventSink> eventListeners = new Vector<IExecutionEventSink>();
	private static Map<Integer, IExecution> runningExecutions = new LinkedHashMap<Integer, IExecution>();
	private static Map<ITask, IExecutionEventSink> taskEventListeners = new ConcurrentHashMap<ITask, IExecutionEventSink>();
	private static ITaskExecutor taskExecutor = new TaskExecutor(new ExecutionFactoryImpl(), new EventSinkImpl());
	private static boolean isShutdown = false;
	
	private static class EventSinkImpl implements IExecutionEventSink{
		
		public void onExecutionEvent(IExecution execution, ExecutionEvent event) {
			try
			{
				for(IExecutionEventSink eventListener: eventListeners)
				{
					eventListener.onExecutionEvent(execution, event);
				}
				IExecutionEventSink eventListener = taskEventListeners.get(execution.task());
				if(null != eventListener)
				{
					eventListener.onExecutionEvent(execution, event);
				}
			}
			finally
			{
				if(event == IExecutionEventSink.ExecutionEvent.TASK_BEGIN)
				{
					synchronized(runningExecutions)
					{
						runningExecutions.put(execution.getId(), execution);
					}
				}
				else if(event == IExecutionEventSink.ExecutionEvent.TASK_FINISH ||
						event == IExecutionEventSink.ExecutionEvent.TASK_CANCEL)
				{
					taskEventListeners.remove(execution.task());
					synchronized(runningExecutions)
					{
						runningExecutions.remove(execution.getId());
					}
				}
				
			}
			
		}
	}
	
	private static class ExecutionFactoryImpl implements IExecutionFactory {

		public IExecution newExecution(ITask task,
				IExecutionEventSink eventListener) {
			if(task instanceof IDurableTask)
			{
				return new ThreadExecution(task, eventListener);
			}
			else
			{
				return new ThreadPoolExecution(task, eventListener);
			}
		}
		
	}
	
	public void setExecutionFactory(IExecutionFactory executionFactory) {
		taskExecutor.setExecutionFactory(executionFactory);
	}
	
	public static IExecution execute(ITask task)
	{
		if(!isShutdown)
			return taskExecutor.execute(task);
		else
			return null;
	}
	
	
	public static void regEventListener(IExecutionEventSink listener)
	{
		eventListeners.add(listener);
	}
	
	public static void removeEventListener(IExecutionEventSink listener)
	{
		eventListeners.remove(listener);
	}
	
	public static void clearEventListener()
	{
		eventListeners.clear();
	}
	
	public static void setTaskEventListenner(ITask task, IExecutionEventSink listener)
	{
		taskEventListeners.put(task, listener);
	}
	
	public static List<IExecution> getRunningExecutions()
	{
		synchronized(runningExecutions)
		{
			List<IExecution> result = new ArrayList<IExecution>(runningExecutions.size());
			result.addAll(runningExecutions.values());
			return result;
		}
	}
	
	public static IExecution getExecution(int eid)
	{
		return runningExecutions.get(eid);
	}
	
	public static IExecution getCurrentExecution() {
		List<IExecution> executions = getRunningExecutions();
		Thread currentThread = Thread.currentThread();
		for(IExecution exec : executions) {
			if(exec.taskRunner() != null && exec.taskRunner().runningThread() == currentThread)
				return exec;	
		}
		return null;
	}
	
	public static void shutdown() {
		shutdown(-1);
	}
	
	public static void shutdown(final int wait) {
		new Thread(new Runnable() {

			@Override
			public void run() {
				_shutdown(wait);
			}
			
			}
		).start();
	}
	
	public static void _shutdown(int wait)
	{
		isShutdown = true;
		List<IExecution> executions = getRunningExecutions();
		ThreadPoolService.getInstance().shutdown();
		if(wait>0)
		{
			long objTime = System.currentTimeMillis() + wait;
			int leftTime = wait;
			for(IExecution exec : executions)
			{
				exec.cancel(leftTime / 2);
				leftTime = (int)(objTime - System.currentTimeMillis());
				if(leftTime<0)
					leftTime = 0;
			}
		}
		else
		{
			for(IExecution exec : executions)
			{
				exec.cancel(wait);
			}
		}
	}

}
