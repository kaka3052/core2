package com.hp.itis.core2.task;

public interface IExecutiveTask extends ITask {
	IExecution execute();
	void cancel(int wait);
	void pause();
	void resume();
	void act();
	void setName(String value);
	void setListener(IExecutionEventSink listener);
	IExecution getExecution();
}
