package com.hp.itis.core2.task;

public interface IActiveModule extends IDurableTask {
	void setName(String value);
	void setStart(boolean value);
	boolean getStart();
}
