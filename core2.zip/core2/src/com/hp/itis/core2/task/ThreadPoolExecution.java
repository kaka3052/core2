package com.hp.itis.core2.task;

public class ThreadPoolExecution  extends AbstractExecution  {
	
	private IThreadPoolService threadPool;
	
	public ThreadPoolExecution(ITask task, IExecutionEventSink eventListener, IThreadPoolService threadPool) {
		super(task, eventListener);
		if(null == threadPool)
			this.threadPool = ThreadPoolService.getInstance();
		else
			this.threadPool = threadPool;
	}
	
	public ThreadPoolExecution(ITask task, IExecutionEventSink eventListener) {
		this(task, eventListener, null);
	}

	public void cancel(int wait) {
		if(!threadPool.remove(taskRunner))
			super.cancel(wait);
		else
			doCancel();
	}

	@Override
	protected void execute() {
		threadPool.execute(taskRunner);
	}
}
