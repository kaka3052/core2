package com.hp.itis.core2.task;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class ThreadPoolService implements IThreadPoolService{
	
	
	private static class RejectedExecutionHandlerImp implements RejectedExecutionHandler {
		public RejectedExecutionHandlerImp() {
		}
		public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
		}
	}
	
	
	private ThreadPoolExecutor threadPool = null;
	private BlockingQueue<Runnable> workQueue;
	private static ThreadPoolService service = null;
	private int corePoolSize = 0;
	private int maxPoolSize = 200;
	private int keepAliveSeconds = 5;
	
	private ThreadPoolService()
	{
		service = this;
	}
	
	public void init()
	{
		if(null != threadPool)
			return;
		workQueue = new SynchronousQueue<Runnable>();
		RejectedExecutionHandlerImp reh = new RejectedExecutionHandlerImp();
		threadPool = new ThreadPoolExecutor(
				corePoolSize, // core pool size;
				maxPoolSize, // max pool size;
				keepAliveSeconds, // keep alive time;
				TimeUnit.SECONDS, // time unit;
				workQueue, // pool queue
				reh); // RejectedExecutionHandler
	}
	
	public static IThreadPoolService getInstance(){
		if(null == service)
			service = new ThreadPoolService();
		return service;
	}

	public int getCorePoolSize() {
		return corePoolSize;
	}

	public int getMaxPoolSize() {
		return maxPoolSize;
	}

	public int getKeepAliveSeconds() {
		return keepAliveSeconds;
	}
	
	public void setCorePoolSize(int value)
	{
		corePoolSize = value;
	}
	
	public void setMaxPoolSize(int value)
	{
		maxPoolSize = value;
	}
	
	public void setKeepAliveSeconds(int value)
	{
		keepAliveSeconds = value;
	}
	
	public void setThreadFactory(ThreadFactory threadFactory)
	{
		if(null == threadPool)
			init();
		threadPool.setThreadFactory(threadFactory);
	}
	
	public Future<?> submit(Runnable task)
	{
		if(null == threadPool)
			init();
		return threadPool.submit(task);
	}

	public boolean awaitTermination(long timeout, TimeUnit unit)
			throws InterruptedException {
		if(null == threadPool)
			init();
		return threadPool.awaitTermination(timeout, unit);
	}

	public boolean isShutdown() {
		if(null == threadPool)
			init();
		return threadPool.isShutdown();
	}

	public boolean isTerminated() {
		if(null == threadPool)
			init();
		return threadPool.isTerminated();
	}

	public void shutdown() {
		if(null == threadPool)
			init();
		threadPool.shutdown();
	}

	public List<Runnable> shutdownNow() {
		if(null == threadPool)
			init();
		return threadPool.shutdownNow();
	}

	public <T> Future<T> submit(Callable<T> task) {
		if(null == threadPool)
			init();
		return threadPool.submit(task);
	}

	public <T> Future<T> submit(Runnable task, T result) {
		if(null == threadPool)
			init();
		return threadPool.submit(task, result);
	}

	public void execute(Runnable command) {
		if(null == threadPool)
			init();
		threadPool.execute(command);
	}
	
	public boolean remove(Runnable task)
	{
		return threadPool.remove(task);
	}

	@Override
	public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks)
			throws InterruptedException {
		return threadPool.invokeAll(tasks);
	}

	@Override
	public <T> List<Future<T>> invokeAll(
			Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit)
			throws InterruptedException {
		return invokeAll(tasks, timeout, unit);
	}

	@Override
	public <T> T invokeAny(Collection<? extends Callable<T>> tasks)
			throws InterruptedException, ExecutionException {
		return invokeAny(tasks);
	}

	@Override
	public <T> T invokeAny(Collection<? extends Callable<T>> tasks,
			long timeout, TimeUnit unit) throws InterruptedException,
			ExecutionException, TimeoutException {
		return invokeAny(tasks, timeout, unit);
	}

}
