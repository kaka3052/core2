package com.hp.itis.core2.task;

abstract public class ActiveModule extends DurableTask implements IActiveModule {

	private boolean started = false;
	private String name;
	
	public boolean getStart() {
		return started;
	}

	public void setName(String value) {
		name = value;
	}
	
	public String name()
	{
		if(null != name)
			return super.name();
		else
			return name;
	}

	public void setStart(boolean value) {
		started = value;
	}

}
