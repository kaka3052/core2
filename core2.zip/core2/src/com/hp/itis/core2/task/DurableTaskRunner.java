package com.hp.itis.core2.task;



public class DurableTaskRunner extends TaskRunner {
	
	private IDurableTask durableTask;
	
	public DurableTaskRunner(IDurableTask durableTask, IRunnerEventSink eventListener)
	{
		super(durableTask, eventListener);
		this.durableTask = durableTask;
	}
	
	public void run() {
		thread = Thread.currentThread();
		thread.setName(durableTask.name());
		doStart();
		durableTask.beforeExecute();
		try
		{
			while(state != RunnerState.STOPPED)
			{
				while(state == RunnerState.PAUSED)
				{
					try {
						synchronized(this) {
							this.wait(10000);
						}
					} catch (InterruptedException e) {
					}
				}
				super.doActive();
				durableTask.run();
				try {
					if(durableTask.interval()>0) {
						synchronized(this) {
							this.wait(durableTask.interval());
						}
					}
					else if(durableTask.interval()==0)
						Thread.yield();
				} catch (InterruptedException e) {
				}
			}
		}
		finally
		{
			doEnd();
		}
	}
	
	public synchronized void doActive()
	{
		this.notify();
		super.doActive();
	}
	
	protected synchronized void doResume()
	{
		this.notify();
		super.doResume();
	}

}
