package com.hp.itis.core2.task;

public interface ITaskRunner extends Runnable{
	
	enum RunnerState{RUNNING, STOPPED, PAUSED, BLOCKED}
	
	RunnerState getState();
	
	public long activeTime();
	
	void stop(int wait);
	
	void pause();
	
	void resume();
	
	void doActive();
	
	Thread runningThread();
}
