package com.hp.itis.core2.task;

public interface IRunnerEventSink {
	enum RunnerEvent{RUNNER_START, 
		RUNNER_ACTIVE,
		RUNNER_STOP,
		RUNNER_PAUSE,
		RUNNER_RESUME};
		
		void onRunnerEvent(ITaskRunner runner, RunnerEvent event);
}
