package com.hp.itis.core2.task;

public interface IDurableTask extends ITask {
	public static final int DEF_TIMELIMIT = 30*60*1000;
	
	long interval();
	void beforeExecute();
	boolean immortal();
}
