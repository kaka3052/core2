package com.hp.itis.core2.task;

import java.util.concurrent.ExecutorService;

public interface IThreadPoolService extends ExecutorService {

	boolean remove(Runnable task);
	
	public int getCorePoolSize();

	public int getMaxPoolSize();

	public int getKeepAliveSeconds();
	
	public void setCorePoolSize(int value);
	
	public void setMaxPoolSize(int value);
	
	public void setKeepAliveSeconds(int value);

}
