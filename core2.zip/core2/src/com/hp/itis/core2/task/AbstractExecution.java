package com.hp.itis.core2.task;

import com.hp.itis.core2.task.IExecutionEventSink.ExecutionEvent;

abstract public class AbstractExecution implements IExecution, IRunnerEventSink{
	
	protected static int nextId = 1; 
	
	protected ITask task = null;
	protected ITaskRunner taskRunner = null;
	protected IExecutionEventSink eventListener = null;
	protected int id;
	protected String name;
	protected boolean canceled = false;
	protected boolean finished = false;
	protected long createTime = System.currentTimeMillis();
	
	public AbstractExecution(ITask task, IExecutionEventSink eventListener)
	{
		this.task = task;
		this.eventListener = eventListener;
		id = nextId++;
		if(null != task.name())
			name = task.name();
		else
			name = getDefName();
		doBegin();
	}
	
	protected String getDefName()
	{
		return task.getClass().getSimpleName();
	}
	

	protected ITaskRunner chooseRunner(ITask task)
	{
		if(task instanceof IDurableTask)
		{
			return new DurableTaskRunner((IDurableTask)task, this);
		}
		else
		{
			return new TaskRunner(task, this);
		}
	}
	
	public void start() {
		if(null != taskRunner)
			return;
		finished = false;
		canceled = false;
		if(null == taskRunner)
		{
			taskRunner = chooseRunner(task);
		}
		execute();
	}

	public ITask task() {
		return task;
	}
	
	public ITaskRunner taskRunner()
	{
		return taskRunner;
	}

	public void restart(int wait) {
		if(null != taskRunner)
		{
			taskRunner.stop(wait);
		}
		start();
	}

	public void cancel(int wait) {
		canceled = true;
		if(null != taskRunner)
			taskRunner.stop(wait);
		doCancel();
	}
	
	public int getId()
	{
		return id;
	}
	
	public String getName()
	{
		return name;
	}
	
	public ExecutionState getState()
	{
		if(finished)
			return ExecutionState.FINISHED;
		if(canceled)
			return ExecutionState.CANCELED;
		if(null != taskRunner)
		{
			ITaskRunner.RunnerState runnerState = taskRunner.getState();
			if(runnerState == ITaskRunner.RunnerState.RUNNING)
				return ExecutionState.RUNNING;
			else if(runnerState == ITaskRunner.RunnerState.BLOCKED)
				return ExecutionState.BLOCKED;
			else if(runnerState == ITaskRunner.RunnerState.PAUSED)
				return ExecutionState.PAUSED;
		}
		return ExecutionState.READY;
	}
	
	public long getCreateTime()
	{
		return createTime;
	}
	
	public boolean waitFinish(int miliSeconds)
	{
		try {
			synchronized(this)
			{
				this.wait(miliSeconds);
			}
		} catch (InterruptedException e) {
			
		}
		return finished;
	}
	
	public void onRunnerStop()
	{
		taskRunner = null;
		synchronized(this)
		{
			this.notifyAll();
		}
	}
	
	
	protected void doBegin()
	{
		if(null != eventListener)
			eventListener.onExecutionEvent(this, ExecutionEvent.TASK_BEGIN);
	}

	protected void doRun()
	{
		if(null != eventListener)
			eventListener.onExecutionEvent(this, ExecutionEvent.TASK_RUN);
	}
	
	protected void doActive()
	{
		if(null != eventListener)
			eventListener.onExecutionEvent(this, ExecutionEvent.TASK_ACTIVE);
	}
	
	protected void doPause()
	{
		if(null != eventListener)
			eventListener.onExecutionEvent(this, ExecutionEvent.TASK_PAUSE);
	}
	
	protected void doResume()
	{
		if(null != eventListener)
			eventListener.onExecutionEvent(this, ExecutionEvent.TASK_RESUME);
	}
	
	protected void doCancel()
	{
		if(null != eventListener)
			eventListener.onExecutionEvent(this, ExecutionEvent.TASK_CANCEL);
	}
	
	protected void doFinish()
	{
		finished = true;
		if(null != eventListener)
			eventListener.onExecutionEvent(this, ExecutionEvent.TASK_FINISH);
	}
	
	public void onRunnerEvent(ITaskRunner runner, RunnerEvent event)
	{
		if(event == RunnerEvent.RUNNER_ACTIVE)
			doActive();
		else if(event == RunnerEvent.RUNNER_PAUSE)
			doPause();
		else if(event == RunnerEvent.RUNNER_RESUME)
			doResume();
		else if(event == RunnerEvent.RUNNER_START)
			doRun();
		else if(event == RunnerEvent.RUNNER_STOP)
		{
			if(!canceled)
				doFinish();
			onRunnerStop();
		}
		
	}
	
	abstract protected void execute();
	

}
