package com.hp.itis.core2.task;

public abstract class OneTimeTask extends ExecutiveTask implements IOneTimeTask {

	public int timeLimit() {
		return DEF_TIMELIMIT;
	}

}
