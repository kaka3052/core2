package com.hp.itis.core2.task;


public class ThreadExecution extends AbstractExecution {
	
	public ThreadExecution(ITask task, IExecutionEventSink eventListener)
	{
		super(task, eventListener);
	}

	protected void execute() {
		Thread t = new Thread(taskRunner);
		t.start();
	}
}
