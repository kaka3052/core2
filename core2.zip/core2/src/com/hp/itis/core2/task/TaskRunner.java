package com.hp.itis.core2.task;

import java.lang.Thread.State;

public class TaskRunner implements ITaskRunner {

	protected RunnerState state;
	protected ITask task;
	protected long activeTime;
	protected Thread thread = null;
	protected IRunnerEventSink eventListener;
	private boolean ended = false;
	
	public TaskRunner(ITask task, IRunnerEventSink eventListener)
	{
		this.task = task;
		this.eventListener = eventListener;
	}
	
	public long activeTime() {
		return activeTime;
	}

	public RunnerState getState() {
		if(null != thread && 
				state==RunnerState.RUNNING && 
					(State.WAITING == thread.getState() || 
						State.BLOCKED == thread.getState()))
			return RunnerState.BLOCKED;
		else
			return state;
	}

	public void run() {
		doStart();
		doActive();
		thread = Thread.currentThread();
		thread.setName(task.name());
		try
		{
			task.run();
		}
		finally
		{
			doEnd();
		}
	}

	public void pause() {
		doPause();
	}

	public void resume() {
		doResume();
	}

	public Thread runningThread() {
		return thread;
	}

	@SuppressWarnings("deprecation")
	public void stop(int wait) {
		state = RunnerState.STOPPED;
		if(null == thread)
			return;
		if(Thread.currentThread() == thread)
			return;
		if(thread.isAlive())
		{
			try	{
				task.onCancel();
			}catch(Exception e) {}
			
			thread.interrupt();
			Thread.yield();
		}
		if(thread.isAlive())
		{
			try {
				if(wait>0)
					thread.join(wait);
				else if(wait<0)
					thread.join();
			}
			catch(Exception e)
			{
				
			}
			finally
			{
				if(thread.isAlive())
				{
					thread.stop();
					state = RunnerState.STOPPED;
				}
			}
		}
		doEnd();
	}
	
	protected void doStart()
	{
		state = RunnerState.RUNNING;
		activeTime = System.currentTimeMillis();
		if(null != eventListener)
			eventListener.onRunnerEvent(this, IRunnerEventSink.RunnerEvent.RUNNER_START);
	}

	public void doActive()
	{
		state = RunnerState.RUNNING;
		activeTime = System.currentTimeMillis();
		if(null != eventListener)
			eventListener.onRunnerEvent(this, IRunnerEventSink.RunnerEvent.RUNNER_ACTIVE);
	}
	
	protected void doPause()
	{
		state = RunnerState.PAUSED;
		if(null != eventListener)
			eventListener.onRunnerEvent(this, IRunnerEventSink.RunnerEvent.RUNNER_PAUSE);
	}
	
	protected void doResume()
	{
		state = RunnerState.RUNNING;
		if(null != eventListener)
			eventListener.onRunnerEvent(this, IRunnerEventSink.RunnerEvent.RUNNER_RESUME);
	}
	
	protected void doEnd()
	{
		if(ended) return;
		ended = true;
		state = RunnerState.STOPPED;
		if(null != eventListener)
			eventListener.onRunnerEvent(this, IRunnerEventSink.RunnerEvent.RUNNER_STOP);
	}

}
