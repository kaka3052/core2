package com.hp.itis.core2.task;

public abstract class DurableTask extends ExecutiveTask implements IDurableTask{

	public void beforeExecute() {
		
	}

	public boolean immortal() {
		return false;
	}

	public long interval() {
		return 0;
	}

	public int timeLimit() {
		return DEF_TIMELIMIT;
	}

}
