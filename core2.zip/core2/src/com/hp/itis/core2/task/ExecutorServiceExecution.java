package com.hp.itis.core2.task;

import java.util.concurrent.ExecutorService;

public class ExecutorServiceExecution extends AbstractExecution {

	protected ExecutorService service;
	
	public ExecutorServiceExecution(ITask task, IExecutionEventSink eventListener, ExecutorService service) {
		super(task, eventListener);
		this.service = service;
	}

	@Override
	protected void execute() {
		service.submit(taskRunner);
	}
}
