package com.hp.itis.core2.task;

public interface ITaskExecutor extends IExecutionEventSink {
	IExecution execute(ITask task);
	void setExecutionFactory(IExecutionFactory executionFactory);
}
