package com.hp.itis.core2.task;

public class TaskExecutor implements ITaskExecutor{
	
	private IExecutionEventSink eventListener = null;
	private IExecutionFactory executionFactory;
	
	public TaskExecutor(IExecutionFactory executionFactory, IExecutionEventSink eventListener)
	{
		this.eventListener = eventListener;
		this.executionFactory = executionFactory;
	}
	
	public IExecution execute(ITask task)
	{
		IExecution execution = executionFactory.newExecution(task, this);
		
		execution.start();
		return execution;
	}
	


	public void onExecutionEvent(IExecution execution, ExecutionEvent event) {
		
		if(null != eventListener)
			eventListener.onExecutionEvent(execution, event);
	}

	public void setExecutionFactory(IExecutionFactory executionFactory) {
		this.executionFactory = executionFactory;
	}

}
