package com.hp.itis.core2.task;

public interface IExecutionEventSink {
	enum ExecutionEvent{TASK_BEGIN, 
					TASK_RUN,
					TASK_ACTIVE,
					TASK_CANCEL,
					TASK_PAUSE,
					TASK_RESUME,
					TASK_FINISH};
					
	void onExecutionEvent(IExecution execution, ExecutionEvent event);
}
