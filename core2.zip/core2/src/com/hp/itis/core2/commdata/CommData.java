package com.hp.itis.core2.commdata;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

/**
 * 通用数据类<p>
 * CommData主要是用于模块间，服务器和客户端间进行数据交换的通用数据格式对象，
 * 它代表一类键值对形式的树状结构，类似如下拓扑格式：
 * 	[contacts]
 * 		[0]
 * 			name: john
 * 			description: family
 * 			productId: 11
 * 			categoryId: 1
 * 		[1]
 * 			name: tommy
 * 			description: friend
 * 			productId: 22
 * 			categoryId: 2
 * 		[2]
 * 			name: kitty
 * 			description: girl friend
 * 			productId: 33
 * 			categoryId: 3
 * 
 * @author changj
 *
 */
public interface CommData extends Cloneable, Iterable<Object>, Serializable {

	/**
	 * 设置指定键的值对象
	 * @param key 键
	 * @param value 值对象
	 */
	void put(String key, Object value);

	/**
	 * 取得指定key的值对象
	 * @param key 键
	 * @return
	 */
	Object get(String key);
	
	/**
	 * 取得指定key的CommData值对象，如果key对应的对象非CommData则返回null
	 * @param key 键
	 * @return
	 */
	CommData getChild(String key);
	
	/**
	 * 返回对应Key对应的Int值
	 * @param key 键
	 * @return 
	 */
	Integer getInt(String key);
	
	/**
	 * 返回对应Key对应的Int值
	 * @param key
	 * @param def 默认值
	 * @return
	 */
	int get(String key, int def);
	
	/**
	 * 返回对应Key对应的Long值
	 * @param key 键
	 * @return 
	 */
	Long getLong(String key);
	
	/**
	 * 返回对应Key对应的Long值
	 * @param key
	 * @param def 默认值
	 * @return
	 */
	long get(String key, long def);
	
	/**
	 * 返回对应Key对应的Double值
	 * @param key 键
	 * @return
	 */
	Double getDouble(String key);
	
	/**
	 * 返回对应Key对应的Double值
	 * @param key
	 * @param def 默认值
	 * @return
	 */
	double get(String key, double def);
	
	/**
	 * 返回对应Key对应的Boolean值
	 * @param key 键
	 * @return
	 */
	Boolean getBoolean(String key);
	
	/**
	 * 返回对应Key对应的Boolean值
	 * @param key
	 * @param def 默认值
	 * @return
	 */
	boolean get(String key, boolean def);
	
	/**
	 * 返回对应Key对应的String值
	 * @param key
	 * @return
	 */
	String getString(String key);
	
	/**
	 * 返回对应Key对应的String值
	 * @param key
	 * @param def 默认值
	 * @return
	 */
	String get(String key, String def);
	
	/**
	 * 返回对应Key对应的Date值
	 * @param key
	 * @return
	 */
	Date getDate(String key);
	
	/**
	 * 返回对应Key对应的Date值
	 * @param key
	 * @param def 默认值
	 * @return
	 */
	Date get(String key, Date def);
	
	/**
	 * 返回对应Key对应的Object值, 尝试将结果自动转型为def所对应类型
	 * @param key
	 * @param def 默认值
	 * @return
	 */
	Object get(String key, Object def);
	
	/**
	 * 填充value所指定的对象到CommData中，目前支持的value类型：
	 * <ul>
	 * <li>Map，将Map中的键值对复制到CommData中
	 * <li>Collection，将Collection中的对象以遍历顺序的序号为Key复制到CommData中
	 * <li>Pojo，通过遍历调用Pojo的get方法，将Pojo的属性赋值到CommData中
	 * <li>CommData，将传入的CommData数据遍历复制至当前CommData对象
	 * </ul>
	 * @param value 操作成功与否
	 */
	boolean put(Object value);

	/**
	 * 返回键的集合
	 * @return
	 */
	Set<String> keySet();

	/**
	 * 从CommData中提取数据到value中，目前支持的value类型：
	 * <ul>
	 * <li>Map，将CommData中的键值对复制到中Map
	 * <li>Collection，复制CommData中的值对象到Collection中
	 * <li>Pojo，通过遍历调用Pojo的set方法，将CommData中的键值复制到Pojo所对应的属性中
	 * <li>CommData，将当前的CommData数据遍历复制至参数CommData对象
	 * </ul>
	 * @param value 操作成功与否
	 * @return
	 */
	boolean extract(Object value);
	
	/**
	 * 创建一个空的CommData实例
	 * @return
	 */
	CommData create();
	
	/**
	 * 添加一个空的子CommData节点
	 * @param key 节点键名
	 */
	CommData add(String key);
	
	/**
	 * 增加一个元素到表尾，其Key默认为当前表长度的字符串表现形式
	 */
	void push(Object value);
	
	/**
	 * 返回CommData的可阅读格式字符串
	 * @return
	 */
	String toString();
	
	/**
	 * 判断与参数anObject是否为同一对象或者同构同值
	 * @param anObject
	 * @return
	 */
	boolean equals(Object anObject);
	
	/**
	 * 返回表长度
	 * @return
	 */
	int size();
	
	/**
	 * 深层复制方法
	 * @return
	 */
	CommData clone();
	
}