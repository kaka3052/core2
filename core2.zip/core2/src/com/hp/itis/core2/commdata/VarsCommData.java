package com.hp.itis.core2.commdata;

import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Set;

import com.hp.itis.core2.vars.IEnumerableVars;
import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.IWritableVars;

public class VarsCommData extends AbstractCommData implements IWritableVars {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3400292072448083825L
	;
	private IVars vars;

	public VarsCommData(IVars vars) {
		this.vars = vars;
	}
	
	@Override
	public CommData create() {
		return null;
	}

	@Override
	public Object get(String key) {
		return vars.get(key);
	}

	@Override
	public Set<String> keySet() {
		if(vars instanceof IEnumerableVars)
			return new AbstractSet<String>() {

				@Override
				public Iterator<String> iterator() {
					return ((IEnumerableVars)vars).iterator();
				}

				@Override
				public int size() {
					return ((IEnumerableVars)vars).size();
				}

			};
		else
			return null;
	}

	@Override
	public void put(String key, Object value) {
		if(vars instanceof IWritableVars)
			((IWritableVars)vars).put(key, value);
	}
	

}
