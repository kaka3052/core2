/* 
 * @(#)FiledMapGetter.java	1.0	Nov 24, 2008
 *
 * Copyright 2008 Hewlett-Packard GDCC
 * All right reserved.
 */
package com.hp.itis.core2.commdata;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 工具类：尝试取得方法名所对应的字段名
 *
 * @version 1.0
 * @since Nov 24, 2008 11:02:35 AM
 * @author changj
 *
 */
public class FieldMapper {
	
	public static String getterName(Method m) {
		String mName = m.getName();
		if(0 == m.getParameterTypes().length) {
			FieldMap fieldMap = m.getAnnotation(FieldMap.class);
			if(fieldMap != null)
				return fieldMap.value();
			if(mName.startsWith("get") &&  mName.length() > 3) {
				String pName = mName.substring(3);
				pName = pName.substring(0, 1).toLowerCase()
						+ pName.substring(1);
				return pName;
			}
			if(mName.startsWith("is") &&  mName.length() > 2) {
				String pName = mName.substring(2);
				pName = pName.substring(0, 1).toLowerCase()
						+ pName.substring(1);
				return pName;
			}	
		}
		return null;
	}
	
	public static String setterName(Method m) {
		String mName = m.getName();
		if(1 == m.getParameterTypes().length) {
			FieldMap fieldMap = m.getAnnotation(FieldMap.class);
			if(fieldMap != null)
				return fieldMap.value();
			if(mName.startsWith("set") &&  mName.length() > 3) {
				String pName = mName.substring(3);
				pName = pName.substring(0, 1).toLowerCase()
						+ pName.substring(1);
				return pName;
			}	
		}
		return null;
	}
	
	public static Map<String, Method> findGetters(Class<?> c) {
		Map<String, Method> map = new LinkedHashMap<String, Method>();
		Method ms[] = c.getDeclaredMethods();
		Method m;
		for (int i = 0; i < ms.length; i++) {
			m = ms[i];
			String fName = FieldMapper.getterName(m);
			if(fName != null){
				if(!m.getDeclaringClass().isAssignableFrom(Object.class))
					map.put(fName, m);
			}
		}
		return map;
	}
	
	public static Map<String, Method> findSetters(Class<?> c) {
		Map<String, Method> map = new LinkedHashMap<String, Method>();
		Method ms[] = c.getMethods();
		Method m;
		for (int i = 0; i < ms.length; i++) {
			m = ms[i];
			String fName = FieldMapper.setterName(m);
			if(fName != null){
				if(!m.getDeclaringClass().isAssignableFrom(Object.class))
					map.put(fName, m);
			}
		}
		return map;
	}
	
	public static Method findGetter(Class<?> c, String name) {
		Method ms[] = c.getMethods();
		Method m;
		for(int i = 0; i < ms.length; i++) {
			m = ms[i];
			if(!isDigestible(m.getDeclaringClass()))
				continue;
			if(name.equals(getterName(m))) 
				return m;
		}
		return null;
	}
	
	public static Method findAllGetter(Class<?> c, String name) {
		Method ms[] = c.getMethods();
		Method m;
		for(int i = 0; i < ms.length; i++) {
			m = ms[i];
			if(name.equals(getterName(m))) 
				return m;
		}
		return null;
	}
	
	public static Method findSetter(Class<?> c, String name) {
		Method ms[] = c.getMethods();
		Method m;
		for(int i = 0; i < ms.length; i++) {
			m = ms[i];
			if(!isDigestible(m.getDeclaringClass()))
				continue;
			if(name.equals(setterName(m))) 
				return m;
		}
		return null;
	}
	
	public static Method findAllSetter(Class<?> c, String name) {
		Method ms[] = c.getMethods();
		Method m;
		for(int i = 0; i < ms.length; i++) {
			m = ms[i];
			if(name.equals(setterName(m))) 
				return m;
		}
		return null;
	}
	
	public static boolean isDigestible(Class<?> c) {
		Class<?> pc = c;
		while(pc != null) {
			if(pc.isAnnotationPresent(Digestible.class))
				return true;
			pc = pc.getSuperclass();
		}
		Class<?>[] interfaces = c.getInterfaces();
		for(int i=0; i<interfaces.length; i++)
			if(interfaces[i].isAnnotationPresent(Digestible.class))
				return true;
		return false;
	}
}
