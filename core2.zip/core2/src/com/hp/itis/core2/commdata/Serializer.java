package com.hp.itis.core2.commdata;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public interface Serializer {
	void read(CommData data, InputStream is) throws IOException;
	void write(CommData data, OutputStream os) throws IOException;
}
