package com.hp.itis.core2.commdata;

public interface DataVisitor {
	boolean visit(String path, String key, Object value);
}
