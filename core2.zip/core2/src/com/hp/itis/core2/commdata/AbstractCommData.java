package com.hp.itis.core2.commdata;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

abstract public class AbstractCommData implements CommData {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6339804521993929940L;

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.commdata.CommData#create()
	 */
	abstract public CommData create();

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.commdata.CommData#get(java.lang.String)
	 */
	abstract public Object get(String key);

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.commdata.CommData#keySet()
	 */
	abstract public Set<String> keySet();

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.commdata.CommData#put(java.lang.String, java.lang.Object)
	 */
	abstract public void put(String key, Object value);
	
//	public void accept(String path, DataVisitor visitor) {
//		if(null == path || path.length()==0)
//			return;
//		if(path.startsWith("/"))
//			path = path.substring(1);
//		String key;
//		int p = path.indexOf('/');
//		if(p>0) {
//			key = path.substring(0, p);
//			path = path.substring(p+1, path.length());
//		}
//		else {
//			key = path;
//			path = null;
//		}
//		if("*".equals(key)) {
//			for(String k : this.keySet()) {
//				if(!visitor.visit(path, key, get(k)));
//					return;
//			}
//		}
//		else if("**".equals(key)) {
//			for(String k : this.keySet()) {
//				if(!visitor.visit(path, key, get(k)));
//					return;
//			}
//		}
//	}
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.commdata.CommData#size()
	 */
	public int size() {
		int c = 0;
		Iterator<String> i = keySet().iterator();
		while(i.hasNext()) {
			c++;
			i.next();
		}
		return c;
	}
	
	@Override
	public void push(Object value) {
		put(String.valueOf(size()), value);
	}

	@Override
	public Iterator<Object> iterator() {
		final Iterator<String> keys = keySet().iterator();
		return new Iterator<Object>() {

			@Override
			public boolean hasNext() {
				return keys.hasNext();
			}

			@Override
			public Object next() {
				return get(keys.next());
			}

			@Override
			public void remove() {
				keys.remove();
			}
			
		};
	}

	protected static void toString(CommData cd, StringBuilder sb, String prefix) {
		for(String key : cd.keySet()) {
			Object v = cd.get(key);
			if(v instanceof AbstractCommData){
				sb.append(prefix);
				sb.append("[");
				sb.append(key);
				sb.append("]\n");
				toString((AbstractCommData)v, sb, prefix + "\t");
			}
			else{
				sb.append(prefix);
				sb.append(key);
				sb.append(": ");
				String s = v.toString();
				if(s.indexOf('"')>=0)
					s = s.replace("\"", "\"\"");
				if(s.indexOf('\n')>=0 || s.indexOf('\r')>=0 || s.startsWith("\t"))
					s = "\"" + s + "\"";
				sb.append(s);
				sb.append("\n");
			}
		}
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		toString(this, sb, "");
		return sb.toString();
	}
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.commdata.CommData#put(java.lang.Object)
	 */
	public boolean put(Object value) {
		if(value instanceof CommData) {
			return putCommData((CommData)value);
		}
		else if(value instanceof Map<?, ?>) {
			return putMap((Map<?, ?>)value);
		} 
		else if(value instanceof Collection<?>) {
			return putCollection((Collection<?>)value);
		} 
		else if(isPojo(value.getClass()))
			return putPojo(value);
		else 
			return false;
	}

	public Integer getInt(String key)
	{
		return (Integer)cast(Integer.class, get(key));
	}
	
	public Double getDouble(String key)
	{
		return (Double)cast(Double.class, get(key));
	}
	
	public Boolean getBoolean(String key)
	{
		return (Boolean)cast(Boolean.class,get(key) );
	}
	
	public String getString(String key)
	{
		Object o = get(key);
		if(o == null) return null;
		
		return o.toString();
	}

	@Override
	public CommData getChild(String key) {
		Object o = get(key);
		if(null == o)
			return null;
		if(!(o instanceof CommData))
			return null;
		return (CommData)o;
	}
	
	@Override
	public Date getDate(String key) {
		return (Date)cast(Date.class,get(key) );
	}

	@Override
	public Long getLong(String key) {
		return (Long)cast(Long.class,get(key) );
	}
	
	@Override
	public int get(String key, int def) {
		return (Integer)get(key, new Integer(def));
	}

	@Override
	public long get(String key, long def) {
		return (Long)get(key, new Long(def));
	}

	@Override
	public double get(String key, double def) {
		return (Double)get(key, new Double(def));
	}

	@Override
	public boolean get(String key, boolean def) {
		return (Boolean)get(key, new Boolean(def));
	}

	@Override
	public String get(String key, String def) {
		return (String)get(key, (Object)def);
	}

	@Override
	public Date get(String key, Date def) {
		return (Date)get(key, (Object)def);
	}
	
	public Object get(String key, Object def) {
		Object r = get(key);
		if(r != null && def != null){
			try {
				return cast(def.getClass(), r);
			}
			catch(Exception e) {
			}
		}
		return def;
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.commdata.CommData#extract(java.lang.Object)
	 */
	public boolean extract(Object value) {
		if(value instanceof Map<?, ?>) {
			return extractMap((Map<?, ?>)value);
		} 
		else if(value instanceof Collection<?>) {
			return extractCollection((Collection<?>)value);
		} 
		else if(isPojo(value.getClass()))
			return extractPojo(value);
		else
			return false;
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.commdata.CommData#add(java.lang.String)
	 */
	public CommData add(String key) {
		CommData cd = create();
		put(key, cd);
		return cd;
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.commdata.CommData#equals(java.lang.Object)
	 */
	public boolean equals(Object anObject) {
		if(null == anObject)
			return false;
		if(this == anObject)
			return true;
		if(!(anObject instanceof CommData))
			return false;
		CommData data = (CommData) anObject;
		if(size() != data.size())
			return false;
		Iterable<String> keys = keySet();
		for(String key : keys) {
			Object o1 = get(key);
			Object o2 = data.get(key);
			if(valueEqual(o1, o2))
				continue;
			if(o1 instanceof CommData) {
				if(((CommData) o1).equals(o2))
					continue;
			}
			return false;
		}
		return true;
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.commdata.CommData#clone(java.lang.Object)
	 */
	public CommData clone() {
		CommData c = create();
		c.put(this);
		return c;
	}
	
	/**
	 * 判断一个类是否为Pojo，具体应用时请覆盖该方法
	 * @param c
	 * @return
	 */
	protected boolean isPojo(Class<?> c) {
		return FieldMapper.isDigestible(c);
	}
	
	/**
	 * 判断一个对象是否为可结构化数据
	 * @param o
	 * @return
	 */
	protected boolean isDigestible(Class<?> c) {
		return (Map.class.isAssignableFrom(c)) || (Collection.class.isAssignableFrom(c)) 
		|| (CommData.class.isAssignableFrom(c)) || isPojo(c);
		
	}
	
	protected boolean putMap(Map<?, ?> value) {
		for(Entry<?, ?> entry : value.entrySet()) {
			Object o = entry.getValue();
			if(isDigestible(o.getClass()))
				add(entry.getKey().toString()).put(o);
			else
				put(entry.getKey().toString(), o);
		}
		return true;
	}

	protected boolean putCollection(Collection<?> value) {
		Integer i = 0;
		for(Object o : value) {
			if(isDigestible(o.getClass()))
				add(i.toString()).put(o);
			else
				put(i.toString(), o);
			i++;
		}
		return true;
	}
	
	protected boolean putPojo(Object pojo) {
		Class<?> c = pojo.getClass();
		Method ms[] = c.getDeclaredMethods();
		Method m;
		for (int i = 0; i < ms.length; i++) {
			m = ms[i];
			String fName = FieldMapper.getterName(m);
			if(fName != null){
				// 调用get方法，取得pojo相应属性
				try {
					Object o = m.invoke(pojo);
					if(null != o && isDigestible(o.getClass()))
						add(fName).put(o);
					else
						put(fName, o);
				} catch (Exception e) {
					return false;
				}
			}

		}
		return true;
	}
	
	protected boolean putCommData(CommData commData) {
		for(String key : commData.keySet()) {
			Object o = commData.get(key);
			if(o instanceof CommData) {
				CommData child = add(key);
				child.put(o);
			}
			else {
				put(key, o);
			}
		}
		return true;
	}
	
	@SuppressWarnings("unchecked")
	protected boolean extractMap(Map<?, ?> value) {
		try {
			Map<Object, Object> map = (Map<Object, Object>)value;
			for(String key : keySet()) {
				map.put(key, get(key));
			}
		} catch (Exception e) {
			return false;
		}
		return true;
	}
	
	/**
	 * 提取数据到Collection， 如果需要提取结构化数据，则以Collection中第一个元素的类型为准
	 * @param value
	 * @return
	 */
	protected boolean extractCollection(Collection<?> value) {
		Class<?> c = null;
		if(value.size()>0) {
			Object o = value.iterator().next();
			value.clear();
			c = o.getClass();
			try {
				c.getConstructor();
			} catch (Exception e) {
				c = null;
			}
		}
		return extractCollection(value, c);
	}
	
	/**
	 * 提取数据到Collection，如果是元素为结构化类型则由itemType指明
	 * @param value
	 * @param itemType 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	protected boolean extractCollection(Collection<?> value, Class<?> itemType) {
		try {
			Collection<Object> col = (Collection<Object>)value;
			if(null != itemType && isDigestible(itemType))
				for(String key : keySet()) {
					Object v = get(key);
					if(v instanceof CommData) {
						Object o = itemType.newInstance();
						((CommData)v).extract(o);
						v = o;
					}
					col.add(v);
				}
			else
				for(String key : keySet()) {
					col.add(get(key));
				}
		} catch (Exception e) {
			return false;
		}
		return true;
	}
	
	protected boolean extractPojo(Object pojo) {
		Class<?> c = pojo.getClass();
		Method ms[] = c.getDeclaredMethods();
		Method m;
		for(int i = 0; i < ms.length; i++) {
			m = ms[i];
			String fName = FieldMapper.setterName(m);
			if (fName != null) {
				//调用set方法，设置pojo相应属性
				Object[] param = new Object[1];
				//对特殊类型进行必要的转换
				Class<?> pType = m.getParameterTypes()[0];
				Object o = this.get(fName);
				if(pType.isPrimitive() && null == o)
					continue;
				try {
					param[0] = cast(pType, o);
					m.invoke(pojo, param);
				} catch (Exception e) {
					//e.printStackTrace();
					//return false;
				}
			}
		}
		//提取深层结构化数据到Pojo所对应的结构
		for(String key : keySet()) {
			Object v = get(key);
			if(v instanceof CommData) {
				try {
					if(0 == key.length())
						continue;
					m = FieldMapper.findGetter(c, key);
					if(null != m) {
						Object o = m.invoke(pojo);
						if(null != o && isDigestible(o.getClass()))
							((CommData)v).extract(o);
					}
					
				} catch (Exception e) {
					continue;
				}
			}
		}
		return true;
	}
	
	protected boolean extractCommData(CommData value) {
		for(String key : this.keySet()) {
			Object o = get(key);
			if(o instanceof CommData) {
				CommData child = value.create();
				child.put(o);
				value.put(key, child);
			}
			else {
				value.put(key, o);
			}
		}
		return true;
	}
	
	/**
	 * 转换对象到指定类型
	 * @param t 目标类型
	 * @param v 需要转换的值
	 * @return
	 */
	protected Object cast(Class<?> t, Object v) {
		return TypeCaster.cast(t, v);
	}
	
	protected boolean valueEqual(Object o1, Object o2) {
		if(o1 == o2)
			return true;
		if(null == o1)
			return false;
		if(o1.equals(o2))
			return true;
		if(o1 instanceof Date || o2 instanceof Date) {
			String s1, s2;
			if(o1 instanceof Date)
				s1 = (String)cast(String.class, o1);
			else
				s1 = o1.toString();
			if(o2 instanceof Date)
				s2 = (String)cast(String.class, o2);
			else
				s2 = o2.toString();
			if(s1.equals(s2))
				return true;
		}
		return false;
	}

}
