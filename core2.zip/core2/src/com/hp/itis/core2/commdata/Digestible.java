/* 
 * @(#)Digestible.java	1.0	Nov 24, 2008
 *
 * Copyright 2008 Hewlett-Packard GDCC
 * All right reserved.
 */
package com.hp.itis.core2.commdata;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 标示类实例是否可被分解为CommData数据项.
 * @see com.hp.itis.core2.commdata.CommDataImpl
 *
 * @version 1.0
 * @since Nov 24, 2008 10:43:14 AM
 * @author changj
 *
 */

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface Digestible {

}
