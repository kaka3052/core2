package com.hp.itis.core2.commdata;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class DefaultSerializer implements Serializer {

	@Override
	public void read(CommData data, InputStream is) throws IOException {
		ObjectInputStream ois = new ObjectInputStream(is);
		try {
			Object o = ois.readObject();
			data.put(o);
		} catch (ClassNotFoundException e) {
			
		}
		
	}

	@Override
	public void write(CommData data, OutputStream os) throws IOException {
		ObjectOutputStream oos = new ObjectOutputStream(os);
		oos.writeObject(data);
	}

}
