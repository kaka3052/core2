package com.hp.itis.core2.commdata;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * CommObject 实现类
 * @author changj
 *
 */
public class CommDataImpl extends AbstractCommData implements CommData {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8798771968072760531L;
	private Map<String, Object> data;
	
	public CommDataImpl() {
		data = new LinkedHashMap<String, Object>();
	}
	
	public CommDataImpl(Map<String, Object> map) {
		this.data = map;
	}
	
	public CommDataImpl(Object o) {
		this();
		put(o);
	}
	
	public CommData create() {
		return new CommDataImpl();
	}
	
	/* (non-Javadoc)
	 * @see com.hp.evictor.CommData#put(java.lang.String, java.lang.Object)
	 */
	public void put(String key, Object value) {
		if(value instanceof CommData && ! (value instanceof CommDataImpl))
			add(key).put(value);
		else {
			if(value == null)
				data.remove(key);
			else
				data.put(key, value);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.hp.evictor.CommData#get(java.lang.String)
	 */
	public Object get(String key) {
		return data.get(key);
	}
	
	/* (non-Javadoc)
	 * @see com.hp.evictor.CommData#keySet()
	 */
	public Set<String> keySet() {
		return data.keySet();
	}
	
	@Override
	public Iterator<Object> iterator() {
		return data.values().iterator();
	}
	
	@Override
	public int size() {
		return data.size();
	}
}
