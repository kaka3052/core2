package com.hp.itis.core2.commdata;

import java.io.InputStream;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class CommDataXmlImpl extends AbstractCommData {


	/**
	 * 
	 */
	private static final long serialVersionUID = -4103828031896055798L;
	
	protected static final String EL_NAME = "e";
	protected Element element;
	protected Map<String, Object> map = new LinkedHashMap<String, Object>();
	
	public CommDataXmlImpl(InputStream is) {
		DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance(); 
		DocumentBuilder builder;
		Document doc;
		try {
			builder = factory.newDocumentBuilder();
			doc = builder.parse(is);
			element = doc.getDocumentElement();
			parse();
		} catch (Exception e) {
			throw new RuntimeException(e);
		} 
	}
	
	protected CommDataXmlImpl(Element el) {
		element = el;
		parse();
	}
	
	@Override
	public CommData create() {
		element.getOwnerDocument().createAttribute(EL_NAME);
		return new CommDataXmlImpl(element);
	}
	
	protected void parse() {
		NodeList children = element.getElementsByTagName(EL_NAME);
		for(int i=0; i<children.getLength(); i++) {
			Element child = (Element) children.item(i);
			String key = child.getAttribute("k");
			String type = child.getAttribute("t");
			if(null == type)
				map.put(key, new CommDataXmlImpl(child));
			else {
				String value = child.getAttribute("v");
				if("i".equals(type))
					map.put(key, Integer.parseInt(value));
				else if("b".equals(type))
					map.put(key, Boolean.parseBoolean(value));
				else if("n".equals(type))
					map.put(key, Double.parseDouble(value));
				else if("d".equals(type))
					map.put(key, TypeCaster.cast(Date.class, value));
				else
					map.put(key, value);
			}
		}
	}

	@Override
	public Object get(String key) {
		map.get(key);
		return null;
	}

	@Override
	public Set<String> keySet() {
		return map.keySet();
	}

	@Override
	public void put(String key, Object value) {
		
	}
}
