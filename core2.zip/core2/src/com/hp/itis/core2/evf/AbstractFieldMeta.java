package com.hp.itis.core2.evf;

import com.hp.itis.core2.vars.GetterVars;

abstract public class AbstractFieldMeta extends GetterVars implements FieldMeta {

	private String name;

	@Override
	public String getName() {
		if(null == name)
			return getString(EvfParseUtil.FMF_NAME);
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getType() {
		return getString("type");
	}

	@Override
	public String getUnit() {
		return getString("unit");
	}
	
	abstract public Object get(String key);

	abstract public void put(String key, Object value);

	abstract public FieldMeta clone();
}
