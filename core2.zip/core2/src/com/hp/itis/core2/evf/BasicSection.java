package com.hp.itis.core2.evf;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BasicSection implements Section {

	protected List<String> memos = new ArrayList<String>();
	protected List<Record> records = new ArrayList<Record>();
	protected Meta meta = new MetaImpl();
	protected Section owner = null;
	
	@Override
	public Record addRecord() {
		Record record = new BasicRecord(this);
		return addRecord(record);
	}

	@Override
	public int count() {
		return records.size();
	}

	@Override
	public Meta meta() {
		return meta;
	}

	@Override
	public Record getRecord(int index) {
		return records.get(index);
	}

	@Override
	public void removeRecord(Record record) {
		records.remove(record);
	}

	@Override
	public Iterator<Record> iterator() {
		return records.iterator();
	}

	@Override
	public Record addRecord(Record record) {
		records.add(record);
		return record;
	}

	@Override
	public void addMemo(String memo) {
		memos.add(memo);
	}

	@Override
	public String name() {
		return meta.getString("name");
	}

	@Override
	public List<String> getMemos() {
		return memos;
	}
	
	@Override
	public Section clone() {
		BasicSection r = new BasicSection();
		r.memos.addAll(memos);
		r.meta = meta.clone();
		for(Record rec : records) {
			Record crec = rec.clone();
			crec.owner(r);
		}
		return r;
	}

	@Override
	public void clearRecords() {
		records.clear();
	}

	@Override
	public void clearMemos() {
		memos.clear();
	}

	@Override
	public Section owner() {
		return owner;
	}

	@Override
	public void owner(Section owner) {
		this.owner = owner;
	}

}
