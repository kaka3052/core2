package com.hp.itis.core2.evf;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

public interface Parser {
	
	void reset(ParserContext context);

	void parse(InputStream is, String charset, ParserContext context) throws IOException;

	void parse(Reader reader, ParserContext context) throws IOException;

}