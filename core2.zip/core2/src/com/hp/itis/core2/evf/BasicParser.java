package com.hp.itis.core2.evf;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class BasicParser implements Parser {

	public BasicParser() {
	}
	
	public void parse(InputStream is, String charset, ParserContext context) throws IOException {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, charset));
			parse(reader, context);
		}
		finally {
			is.close();
		}
	}
	
	public void parse(Reader reader, ParserContext context) throws IOException {
		ParserEventSink eventSink = context.getEventSink();
		reset(context);
		eventSink.onParseBegin();
		while(true) {
			String line = readLine(reader, context);
			if(line == null)
				break;
			
			if(null == appendLine(line, context))
				continue;
			
			String[] values = parseLine(line, context);
			if(null == values)
				continue;
			
			values = eventSink.onParseValues(values);
			if(null == values)
				continue;
		}
		eventSink.onParseEnd();
	}
	
	protected String appendMemo(String memo, ParserContext context) {
		return context.getEventSink().onAppendMemo(memo);
	}
	
	protected String appendLine(String line, ParserContext context) {
		line = context.getEventSink().onParseLine(line);
		if(null == line)
			return null;
		if(line.length()>0 && line.charAt(0)==EvfParseUtil.MEMO_CHAR) {
			String l = line.substring(1);
			appendMemo(l, context);
			return null;
		}
		return line;
	}
	
	protected String readLine(Reader reader, ParserContext context) throws IOException {
		return EvfParseUtil.readLine(reader, EvfParseUtil.DEF_QUOTE_CHAR);
	}
	
	protected String[] parseLine(String line, ParserContext context) {
		return EvfParseUtil.parseLine(line, EvfParseUtil.DEF_QUOTE_CHAR, EvfParseUtil.DEF_SEPERATER);
	}

	@Override
	public void reset(ParserContext context) {
		
	}

}
