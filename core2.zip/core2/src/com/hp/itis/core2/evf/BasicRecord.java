package com.hp.itis.core2.evf;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.vars.GetterVars;

public class BasicRecord extends GetterVars implements Record {

	protected List<Object> valueList;
	protected Section owner;

	public BasicRecord(Section owner, String[] values) {
		owner(owner);
		setValues(values);
	}
	
	public BasicRecord(Section owner) {
		this(owner, null);
	}
	
	public void setValues(String[] values) {
		valueList = new ArrayList<Object>();
		if(null != values) {
			for(String v : values)
				valueList.add(v);
		}
	}

	@Override
	public Object get(int index) {
		Object value = null;
		if(index >= size() || index<0)
			value = null;
		else
			value = valueList.get(index);
		if(null == value || "".equals(value)) {
			FieldMeta fm = meta().getFieldMeta(index);
			Object def = null;
			if(null != fm)
				def = fm.get("default");
			if(null != def)
				value = def;
		}
		return value;
	}

	@Override
	public void put(int index, Object value) {
		if(index>=valueList.size())
			fillUp(index+1);
		valueList.set(index, value);
	}

	@Override
	public int size() {
		return valueList.size();
	}
	
	protected void fillUp(int size) {
		for(int i=valueList.size(); i<size; i++)
			valueList.add(null);
	}
	
	@Override
	public Record clone() {
		BasicRecord r = new BasicRecord(owner);
		r.valueList.addAll(valueList);
		return r;
	}
	
	@Override
	public Meta meta() {
		return owner.meta();
	}

	@Override
	public Section owner() {
		return owner;
	}
	
	@Override
	public void owner(Section owner) {
		this.owner = owner;
	}

	@Override
	public boolean contains(String key) {
		return null != get(key);
	}

	@Override
	public Object get(String key) {
		int i = meta().getFieldIndex(key);
		if(i>=0)
			return get(i);
		return null;
	}

	@Override
	public Iterator<String> iterator() {
		return meta().fieldNames().iterator();
	}

	@Override
	public void put(String key, Object value) {
		int i = meta().getFieldIndex(key);
		if(i>=0)
			put(i, value);
	}

	@Override
	public int get(int index, int def) {
		return (Integer) get(index, new Integer(def));
	}

	@Override
	public char get(int index, char def) {
		return (Character) get(index, new Character(def));
	}

	@Override
	public byte get(int index, byte def) {
		return (Byte) get(index, new Byte(def));
	}

	@Override
	public long get(int index, long def) {
		return (Long) get(index, new Long(def));
	}

	@Override
	public float get(int index, float def) {
		return (Float) get(index, new Float(def));
	}

	@Override
	public short get(int index, short def) {
		return (Short) get(index, new Short(def));
	}

	@Override
	public double get(int index, double def) {
		return (Double) get(index, new Double(def));
	}

	@Override
	public boolean get(int index, boolean def) {
		return (Boolean) get(index, new Boolean(def));
	}

	@Override
	public String get(int index, String def) {
		return (String) get(index, (Object)def);
	}

	@Override
	public Date get(int index, Date def) {
		return (Date) get(index, (Object)def);
	}

	@Override
	public Object get(int index, Object def) {
		Object r = get(index);
		if (r != null && def != null) {
			try {
				return TypeCaster.cast(def.getClass(), r);
			} catch (Exception e) {
			}
		}
		return def;
	}

	@Override
	public boolean getBoolean(int index) {
		return (Boolean) TypeCaster.cast(Double.class, get(index));
	}

	@Override
	public byte getByte(int index) {
		return (Byte) TypeCaster.cast(Byte.class, get(index));
	}

	@Override
	public char getChar(int index) {
		return (Character) TypeCaster.cast(Character.class, get(index));
	}

	@Override
	public Date getDate(int index) {
		return (Date) TypeCaster.cast(Date.class, get(index));
	}

	@Override
	public double getDouble(int index) {
		return (Double) TypeCaster.cast(Double.class, get(index));
	}

	@Override
	public float getFloat(int index) {
		return (Float) TypeCaster.cast(Float.class, get(index));
	}

	@Override
	public int getInt(int index) {
		return (Integer) TypeCaster.cast(Integer.class, get(index));
	}

	@Override
	public long getLong(int index) {
		return (Long) TypeCaster.cast(Long.class, get(index));
	}

	@Override
	public Number getNumber(int index) {
		return TypeCaster.toNumber(get(index));
	}

	@Override
	public short getShort(int index) {
		return (Short) TypeCaster.cast(Short.class, get(index));
	}

	@Override
	public String getString(int index) {
		return (String) TypeCaster.cast(String.class, get(index));
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<valueList.size(); i++) {
			FieldMeta  fm = meta().getFieldMeta(i);
			String name = null;
			if(null != fm)
				name = fm.getName();
			if(null == name)
				name = "[" + i + "]";
			sb.append(name);
			sb.append("=");
			Object value = valueList.get(i);
			if(null != value) {
				if(value instanceof String) {
					sb.append("\"");
					sb.append(value);
					sb.append("\"");
				}
				else
					sb.append(value);
			}
			sb.append(", ");
		}
		return sb.toString();
	}
}
