package com.hp.itis.core2.evf;

public interface ParserEventSink {
	String onAppendMemo(String memo);
	String onParseLine(String line);
	String[] onParseValues(String[] values);
	boolean onContinue();
	void onParseBegin();
	void onParseEnd();
}
