package com.hp.itis.core2.evf;

import java.io.IOException;
import java.io.OutputStream;

public interface Writer {

	void write(OutputStream os, EvfDocument doc) throws IOException;

}