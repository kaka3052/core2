package com.hp.itis.core2.evf;

public interface EvfEventSink extends EvfParserEventSink {
	Record onAppendRecord(Record record);
}
