package com.hp.itis.core2.evf;

import java.util.Set;

import com.hp.itis.core2.vars.IGetterVars;
import com.hp.itis.core2.vars.IWritableVars;

public interface Meta extends IGetterVars, IWritableVars, Cloneable {
	int fieldCount();
	String charset();
	void setTitles(Record record);
	Record getTitles();
	Set<String> metas();
	Set<String> fieldNames();
	FieldMeta getFieldMeta(String name);
	FieldMeta getFieldMeta(int index);
	FieldMeta addField(String name);
	void removeField(String name);
	int getFieldIndex(String name);
	Meta baseMeta();
	void baseMeta(Meta base);
	Meta docMeta();
	void docMeta(Meta docMeta);
	String terminator();
	char seperater();
	char quoteChar();
	int skipRows();
	boolean isTitled();
	boolean isTrimValues();
	Meta clone();
}
