package com.hp.itis.core2.evf;

public interface MetaLib {
	Meta getMeta(String name);
}
