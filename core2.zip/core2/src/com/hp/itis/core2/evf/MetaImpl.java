package com.hp.itis.core2.evf;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.hp.itis.core2.misc.StrUtil;
import com.hp.itis.core2.vars.GetterVars;

public class MetaImpl extends GetterVars implements Meta {

	private class FwFieldMeta extends AbstractFieldMeta {
		
		private Map<String, Object> metas = new LinkedHashMap<String, Object>();
		private FieldMeta base = null;
		
		public FwFieldMeta(FieldMeta base) {
			this(base, null);
		}
		
		public FwFieldMeta(FieldMeta base, String name) {
			this.base = base;
			if(null != name)
				put(EvfParseUtil.FMF_NAME, name);
		}
		
		@Override
		public FieldMeta clone() {
			FwFieldMeta c = new FwFieldMeta(base);
			c.metas.putAll(this.metas);
			return c;
		}

		@Override
		public Object get(String key) {
			Object r = metas.get(key);
			if(null == r && null != key && null != base)
				r = base.get(key);
			return r;
		}

		@Override
		public void put(String key, Object value) {
			metas.put(key, value);
		}
		
	}
	
	protected Meta base = null;
	protected Meta docMeta = null;
	protected int fieldCount = 0;
	protected List<FieldMeta> fieldMetas = new ArrayList<FieldMeta>();
	protected Map<String, Integer> fieldNameMap = new LinkedHashMap<String, Integer>();
	protected Map<String, Object> metas = new LinkedHashMap<String, Object>();
	
	public MetaImpl() {
		
	}
	
	public MetaImpl(Meta base) {
		baseMeta(base);
	}
	
	@Override
	public void baseMeta(Meta base) {
		this.base = base;
	}
	
	@Override
	public Meta baseMeta() {
		return base;
	}
	
	@Override
	public void docMeta(Meta docMeta) {
		this.docMeta = docMeta;
	}
	
	@Override
	public Meta docMeta() {
		return docMeta;
	}
	
	@Override
	public int fieldCount() {
		return fieldCount;
	}

	@Override
	public int getFieldIndex(String name) {
		int i = -1;
		if(fieldNameMap.containsKey(name))
			i = fieldNameMap.get(name);
		if(i<0 && null != base)
			i = base.getFieldIndex(name);
		return i;
	}

	@Override
	public FieldMeta getFieldMeta(String name) {
		return getFieldMeta(getFieldIndex(name));
	}

	@Override
	public FieldMeta getFieldMeta(int index) {
		if(index<0 || index>=fieldMetas.size())
			return null;
		FieldMeta r = fieldMetas.get(index);
		if(null == r && base != null)
			r = base.getFieldMeta(index);
		if(null == r && docMeta != null)
			r = docMeta.getFieldMeta(index);
		return r;
	}

	@Override
	public char quoteChar() {
		return get(EvfParseUtil.MF_QUOTE_CHAR, EvfParseUtil.DEF_QUOTE_CHAR);
	}

	@Override
	public char seperater() {
		return get(EvfParseUtil.MF_SEPERATER, EvfParseUtil.DEF_SEPERATER);
	}
	
	@Override
	public String terminator() {
		String v = getString(EvfParseUtil.MF_TERMINATOR);
		if(null == v)
			return EvfParseUtil.DEF_TERMINATOR;
		return StrUtil.strDec(v);
	}
	
	protected void setFieldMeta(String name, String values) {
		String[] fmetas = EvfParseUtil.parseLine(values, quoteChar(), seperater());
		if(fieldCount < fmetas.length)
			fieldCount = fmetas.length;
		for(int i=0; i< fieldCount; i++) {
			setFieldMeta(i, name, fmetas[i].toString());
		}
		if(name.equals(EvfParseUtil.FMF_NAME)) {
			buildFieldNameMap();
		}
	}

	@Override
	public String charset() {
		return getString(EvfParseUtil.MF_CHARSET);
	}

	@Override
	public Set<String> metas() {
		return metas.keySet();
	}

	@Override
	public Meta clone() {
		MetaImpl r = new MetaImpl();
		r.base = r;
		r.metas.putAll(metas);
		r.fieldNameMap.putAll(fieldNameMap);
		r.fieldCount = fieldCount;
		r.docMeta = docMeta.clone();
		for(FieldMeta fm : fieldMetas) {
			r.fieldMetas.add(fm.clone());
		}
		return r;
	}
	
	private void expendFields(int size) {
		while(fieldMetas.size()<size) {
			FieldMeta bfm = null;
			if(null != base)
				bfm = base.getFieldMeta(fieldMetas.size());
			fieldMetas.add(new FwFieldMeta(bfm));
		}
	}
	
	protected void setFieldMeta(int fieldIndex, String metaName, String value) {
		expendFields(fieldIndex+1);
		FieldMeta f = fieldMetas.get(fieldIndex);
		f.put(metaName, value);
	}

	@Override
	public FieldMeta addField(String name) {
		FieldMeta f = new FwFieldMeta(null, name);
		fieldMetas.add(f);
		buildFieldNameMap();
		return f;
	}

	@Override
	public void removeField(String name) {
		int i = getFieldIndex(name);
		if(i>=0)
			fieldMetas.remove(i);
		buildFieldNameMap();
	}
	
	private void buildFieldNameMap() {
		fieldNameMap.clear();
		for(int i=0; i< fieldMetas.size(); i++) {
			FieldMeta f = fieldMetas.get(i);
			fieldNameMap.put(f.getName(), i);
		}
	}

	@Override
	public int skipRows() {
		return get(EvfParseUtil.MF_SKIP_ROWS, 0);

	}

	@Override
	public boolean isTitled() {
		return get(EvfParseUtil.MF_TITLED, false);
	}
	
	@Override
	public boolean isTrimValues() {
		return get(EvfParseUtil.MF_TRIM_VALUES, true);
	}

	@Override
	public void setTitles(Record record) {
		expendFields(record.size());
		for(int i=0; i<record.size(); i++) {
			((AbstractFieldMeta)fieldMetas.get(i)).setName(record.getString(i));
		}
		buildFieldNameMap();
	}
	
	@Override
	public Record getTitles() {
		Record record = new BasicRecord(null);
		String[] titles = new String[fieldMetas.size()];
		for(int i=0; i<titles.length; i++) {
			titles[i] = fieldMetas.get(i).getName();
		}
		record.setValues(titles);
		return record;
	}

	@Override
	public void put(String key, Object value) {
		metas.put(key, value);
		if(key.charAt(0)==EvfParseUtil.META_FIELD_CHAR) {
			key = key.substring(1);
			setFieldMeta(key, (String)value);
		}
	}

	@Override
	public Object get(String key) {
		if(null == key || key.length()==0)
			return null;
		
		Object r = metas.get(key);
		if(null == r && base != null)
			return base.get(key);
		if(null == r && docMeta != null)
			return docMeta.get(key);
		
		if(key.charAt(0)==EvfParseUtil.META_FIELD_CHAR) {
			key = key.substring(1);
			StringBuilder sb = new StringBuilder();
			for(FieldMeta m : fieldMetas) {
				String f = m.getString(key);
				if(sb.length()>0)
					sb.append(seperater());
				sb.append(EvfParseUtil.quoteOnNeed(f, quoteChar(), seperater()));
			}
			r = sb.toString();
		}
		return r;
	}

	@Override
	public Set<String> fieldNames() {
		return fieldNameMap.keySet();
	}

}
