package com.hp.itis.core2.evf;

public class MetaValue {

	private String name;
	private Object value;
	
	public MetaValue() {
		
	}
	
	public MetaValue(String metaStr, char quoteChar) {
		int p = metaStr.indexOf(EvfParseUtil.META_VALUE_CHAR);
		if(p>0) {
			name = metaStr.substring(0, p);
			value = EvfParseUtil.unquote(metaStr.substring(p+1, metaStr.length()), quoteChar);
		}
		else
			name = metaStr;
	}
	
	public MetaValue(String name, Object value) {
		this.name = name;
		this.value = value;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Object getValue() {
		return value;
	}
	public void setValue(Object value) {
		this.value = value;
	}
	
}
