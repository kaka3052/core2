package com.hp.itis.core2.evf;

public interface EvfParserEventSink extends ParserEventSink {
	MetaValue onAppendMeta(MetaValue metaValue);
	void onSectionBegin();
	boolean onSectionEnd();
}
