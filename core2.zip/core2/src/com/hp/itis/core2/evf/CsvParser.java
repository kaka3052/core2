package com.hp.itis.core2.evf;

import java.io.IOException;
import java.io.Reader;

public class CsvParser extends BasicParser {
	
	protected static final String KEY_SETTING = "CSV_SETTINGS";
	
	protected static class ParseSettings {

		char quoteChar; 
		char seperater;
		String terminator;
		int chunkSize;
		int skipRows;
		boolean trimValues;

	}
	
	private ParseSettings parseSettings(ParserContext context) {
		return (ParseSettings)context.get(KEY_SETTING);
	}
	
	protected String appendLine(String line, ParserContext context) {
		ParseSettings set = parseSettings(context);
		if(set.skipRows>0) {
			set.skipRows--;
			return null;
		}
		return super.appendLine(line, context);
	}
	
	protected String readLine(Reader reader, ParserContext context) throws IOException {
		ParseSettings set = parseSettings(context);
		String line;
		if(EvfParseUtil.DEF_TERMINATOR.equals(set.terminator))
			line = EvfParseUtil.readLine(reader, set.quoteChar, set.chunkSize);
		else
			line = EvfParseUtil.readLine(reader, set.quoteChar, set.terminator, set.chunkSize);
		if(null != line && set.trimValues)
			line = line.trim();
		return line;
	}
	
	protected String[] parseLine(String line, ParserContext context) {
		ParseSettings set = parseSettings(context);
		String[] values = EvfParseUtil.parseLine(line, set.quoteChar, set.seperater);
		if(null != values && set.trimValues) {
			for(int i=0; i<values.length; i++) {
				if(null != values[i])
					values[i] = values[i].trim();
			}
		}
		return values;
	}
	
	@Override
	public void reset(ParserContext context) {
		Meta meta = context.getMeta();
		ParseSettings settings = new ParseSettings();
		settings.seperater =  meta.seperater();
		settings.quoteChar =  meta.quoteChar();
		settings.terminator = meta.terminator();
		settings.chunkSize =  meta.get(EvfParseUtil.MF_TRUNK_SIZE, 0);
		settings.skipRows = meta.skipRows();
		settings.trimValues = meta.isTrimValues();
		context.put(KEY_SETTING, settings);
	}
	
}
