package com.hp.itis.core2.evf;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class EvfWriter implements Writer {
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.evf.DocWriter#write(java.io.OutputStream, com.hp.itis.core2.evf.EvfDocument)
	 */
	public void write(OutputStream os, EvfDocument doc) throws IOException {
		java.io.Writer writer = new BufferedWriter(new OutputStreamWriter(os, doc.charset()));
		for(int i=0; i<doc.sections().size(); i++) {
			Section section = doc.sections().get(i);
			Meta meta = section.meta();
			char seperater = meta.seperater();
			char quoteChar = meta.quoteChar();
			for(String memo : section.getMemos()) {
				writer.write(EvfParseUtil.MEMO_CHAR);
				writer.write(memo);
				writer.write(meta.terminator());
			}
			for(String name : meta.metas()) {
				writer.write(EvfParseUtil.MEMO_CHAR);
				writer.write(EvfParseUtil.META_CHAR);
				writer.write(name);
				writer.write(EvfParseUtil.META_VALUE_CHAR);
				writer.write(EvfParseUtil.quoteOnNeed(meta.getString(name), quoteChar));
				writer.write(meta.terminator());
			}
			if(meta.isTitled()) {
				writer.write(recordToStr(meta.getTitles(), quoteChar, seperater));
				writer.write(meta.terminator());
			}
			for(Record rec : section) {
				writer.write(recordToStr(rec, quoteChar, seperater));
				writer.write(meta.terminator());
			}
			if(i != doc.sections().size()-1)
				writer.write(meta.terminator());
		}
		writer.flush();
	}
	
	protected String recordToStr(Record record, char quoteChar, char seperater) {
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<record.size(); i++) {
			if(i>0)
				sb.append(seperater);
			sb.append(EvfParseUtil.quoteOnNeed(record.getString(i), quoteChar, seperater));
		}
		return sb.toString();
	}
	

}
