package com.hp.itis.core2.evf;

import com.hp.itis.core2.vars.IGetterVars;
import com.hp.itis.core2.vars.IWritableVars;

public interface FieldMeta extends IGetterVars, IWritableVars, Cloneable{
	String getName();
	String getUnit();
	String getType();
	FieldMeta clone();
}
