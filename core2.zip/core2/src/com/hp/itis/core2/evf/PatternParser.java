package com.hp.itis.core2.evf;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.List;
import java.util.regex.Pattern;

import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.misc.StrUtil;

public class PatternParser extends BasicParser {
	
	protected static final String KEY_SETTING = "PATTERN_SETTINGS";
	
	protected static class ParseSettings {

		Pattern pattern; 
		int chunkSize;
		int[] fieldIndex;

	}
	
	private ParseSettings parseSettings(ParserContext context) {
		return (ParseSettings)context.get(KEY_SETTING);
	}
	
	protected String readLine(Reader reader, ParserContext context) throws IOException {
		ParseSettings set = parseSettings(context);
		return EvfParseUtil.readLine((BufferedReader)reader, set.pattern, set.chunkSize);
	}
	
	protected String[] parseLine(String line, ParserContext context) {
		ParseSettings set = parseSettings(context);
		return EvfParseUtil.parseLine(line, set.pattern, set.fieldIndex);
	}
	
	@Override
	public void reset(ParserContext context) {
		Meta meta = context.getMeta();
		ParseSettings setttings = new ParseSettings();
		setttings.pattern = Pattern.compile(meta.getString("pattern"));
		String sIdx = meta.getString("field-index");
		List<Integer> lIdx = StrUtil.str2list(sIdx, Integer.class, ",");
		setttings.fieldIndex = TypeCaster.toArray(lIdx, -1);
		setttings.chunkSize =  meta.get(EvfParseUtil.MF_TRUNK_SIZE, 0);
		context.put(KEY_SETTING, setttings);
	}
}
