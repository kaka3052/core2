package com.hp.itis.core2.evf;

import java.util.HashMap;
import java.util.Map;

import com.hp.itis.core2.vars.GetterVars;

public class DefaultParserContext extends GetterVars implements ParserContext {

	private ParserEventSink eventSink;
	private Meta meta;
	private Map<String, Object> settings = new HashMap<String, Object>();
	
	public DefaultParserContext() {
		
	}
	
	public void setEventSink(ParserEventSink eventSink) {
		this.eventSink = eventSink;
	}

	public void setMeta(Meta meta) {
		this.meta = meta;
	}
	
	public Object get(String key) {
		Object r = settings.get(key);
		if(null != r)
			return r;
		if(null != meta)
			return meta.get(key);
		return null;
	}

	public DefaultParserContext(ParserEventSink eventSink) {
		this.eventSink = eventSink;
	}
	
	@Override
	public ParserEventSink getEventSink() {
		return eventSink;
	}

	@Override
	public Meta getMeta() {
		return meta;
	}

	@Override
	public void put(String key, Object value) {
		settings.put(key, value);
	}

}
