package com.hp.itis.core2.evf;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EvfParseUtil {
	
	public static final char DEF_QUOTE_CHAR = '\"';
	public static final char DEF_SEPERATER = ',';
	public static final String DEF_TERMINATOR = "\n";
	public static final char MEMO_CHAR = '#';
	public static final char META_CHAR = '@';
	public static final char META_VALUE_CHAR = '=';
	public static final char META_FIELD_CHAR = '.';
	
	public static final String DEF_CHARSET = "utf-8";
	public static final String MF_HEAD = "evf";
	public static final String MF_CHARSET = "charset";
	public static final String MF_QUOTE_CHAR = "quote-char";
	public static final String MF_SEPERATER = "seperater";
	public static final String MF_TERMINATOR = "terminator";
	public static final String MF_SKIP_ROWS = "skip-rows";
	public static final String MF_SECTION_SIZE = "sectionSize";
	public static final String MF_TITLED = "titled";
	public static final String MF_TRIM_VALUES = "trim-values";
	public static final String MF_META = "meta";
	public static final String MF_TRUNK_SIZE = "trunk-size";
	
	public static final String MF_NAME = "name";
	public static final String FMF_NAME = "name";
	
	/**
	 * parse records from string line with csv format
	 * @param line
	 * @param quoteChar
	 * @param separator
	 * @return
	 */
	public static String[] parseLine(String line, char quoteChar, char separator) {
		boolean inQuotes = false;
		boolean preQuotes = false;
		StringBuilder sb = new StringBuilder();
		List<String> fields = new ArrayList<String>();
		for(int i=0; i<line.length(); i++) {
			char c = line.charAt(i);
			if(c==quoteChar) {
				if(!inQuotes && sb.length()==0) {
					inQuotes = true;
					continue;
				}
				if(preQuotes) {
					preQuotes = false;
					sb.append(quoteChar);
					continue;
				}
				if(inQuotes) {
					preQuotes = true;
					continue;
				}
			}
			if(preQuotes) {
				preQuotes = false;
				if(c==separator)
					inQuotes = false;
			}
			if(inQuotes)
				sb.append(c);
			else {
				if(c==separator) {
					fields.add(sb.toString());
					sb.setLength(0);
					preQuotes = false;
					inQuotes = false;
				}
				else
					sb.append(c);
			}
		}
		fields.add(sb.toString());
		return fields.toArray(new String[0]);
	}
	
	/**
	 * read and parse records from an Reader object with regular expression
	 * @param reader
	 * @param pattern
	 * @param groups
	 * @param limit
	 * @return
	 * @throws IOException
	 */
	public static String[] parseLine(BufferedReader reader, Pattern pattern, int[] groups, int limit) throws IOException {
		List<String>  fields = null;
		CharBuffer cb = CharBuffer.allocate(limit);
		reader.mark(limit);
		if(reader.read(cb)>0) {
			Matcher m = pattern.matcher(cb);
			if(m.find()) {
				fields = new ArrayList<String>();
				for(int g : groups) {
					fields.add(m.group(g));
				}
				reader.reset();
				reader.skip(m.end());
			}
		}
		return fields.toArray(new String[0]);
	}
	
	/**
	 * read and parse records from String line with regular expression
	 * @param reader
	 * @param pattern
	 * @param groups
	 * @param limit
	 * @return
	 * @throws IOException
	 */
	public static String[] parseLine(String line, Pattern pattern, int[] groups) {
		List<String> fields = null;
		Matcher m = pattern.matcher(line);
		if(m.find()) {
			fields = new ArrayList<String>();
			for(int g : groups) {
				if(g>=0)
					fields.add(m.group(g));
				else
					fields.add(null);
			}
		}
		return fields.toArray(new String[0]);
	}
	
	/**
	 * parse records from a String line by using fixed-length fields setting
	 * @param reader
	 * @param fieldsLength
	 * @return
	 * @throws IOException
	 */
	public static String[] parseLine(String line, int[] fixedLengths) throws IOException {
		if(null == line || line.length()==0)
			return null;
		List<String> fields = new ArrayList<String>();
		int p = 0;
		for(int fl : fixedLengths) {
			if(p>=line.length())
				break;
			String v = line.substring(p, p+fl);
			fields.add(v);
			p += fl;
		}
		return fields.toArray(new String[0]);
	}
	
	/**
	 * read a line from an Reader object with regular expression
	 * @param reader
	 * @param pattern
	 * @param limit
	 * @return
	 * @throws IOException
	 */
	public static String readLine(BufferedReader reader, Pattern pattern, int limit) throws IOException {
		String line = null;
		CharBuffer cb = CharBuffer.allocate(limit);
		reader.mark(limit);
		if(reader.read(cb)>=0) {
			Matcher m = pattern.matcher(cb);
			if(m.find()) {
				line = m.group(0);
				reader.reset();
				reader.skip(m.end());
			}
			else
				line = "";
		}
		return line;
	}
	
	
	public static String readLine(Reader reader) throws IOException {
		return readLine(reader, DEF_QUOTE_CHAR);
	}
	
	public static String readLine(Reader reader, char quoteChar) throws IOException {
		return readLine(reader, quoteChar, 0);
	}
	
	/**
	 * read a line from an Reader object with csv format and specified quoteChar and line limitation
	 * @param reader
	 * @param quoteChar
	 * @param limit
	 * @return
	 * @throws IOException
	 */
	public static String readLine(Reader reader, char quoteChar, int limit) throws IOException {
		boolean inQuotes = false;
		char pc = 0;
		int b = -1;
		StringBuilder sb = new StringBuilder();
		while(limit<=0 || sb.length()<limit) {
			b = reader.read();
			if(b<0)
				break;
			char c = (char) b;
			if(c==quoteChar)
				inQuotes = !inQuotes;
			if(!inQuotes && c=='\n') {
				if(pc=='\r')
					sb.setLength(sb.length()-1);
				break;
			}
			sb.append(c);
			pc = c;
		}
		if(b<0 && sb.length() == 0)
			return null;
		return sb.toString();
	}
	
	/**
	 * read a line from an Reader object with csv format and specified quoteChar, terminator and line limitation
	 * @param reader
	 * @param quoteChar
	 * @param terminator
	 * @param limit
	 * @return
	 * @throws IOException
	 */
	public static String readLine(Reader reader, char quoteChar, String terminator, int limit) throws IOException {
		boolean inQuotes = false;
		int mi = 0;
		StringBuilder sb = new StringBuilder();
		int b = -1;
		while(limit<=0 || sb.length()<limit) {
			b = reader.read();
			if(b<0)
				break;
			char c = (char) b;
			if(c==quoteChar)
				inQuotes = !inQuotes;
			if(!inQuotes) {
				if(c == terminator.charAt(mi)) {
					mi++;
					if(mi == terminator.length()) {
						if(mi>1)
							sb.setLength(sb.length()-mi+1);
						break;
					}
				}
				else
					mi = 0;
			}
			sb.append(c);
		}
		if(b<0 && sb.length() == 0)
			return null;
		return sb.toString();
	}
	
	public static String readLine(Reader reader, int length) throws IOException {
		CharBuffer cb = CharBuffer.allocate(length);
		if(reader.read(cb)<0)
			return null;
		return cb.toString();
	}
	
	public static String quoteOnNeed(String v, char quoteChar, char seperater) {
		if(null == v)
			return null;
		boolean quotes = v.indexOf(quoteChar)>=0;
		if(quotes)
			v = v.replace("" + quoteChar, "" + quoteChar + quoteChar);
		if(quotes || v.indexOf(seperater)>=0 || v.indexOf('\r')>=0 || v.indexOf('\n')>=0) {
			v = quoteChar + v + quoteChar;
		}
		return v;
	}
	
	public static String quoteOnNeed(String v, char quoteChar) {
		if(null == v)
			return null;
		boolean quotes = v.indexOf(quoteChar)>=0;
		if(quotes)
			v = v.replace("" + quoteChar, "" + quoteChar + quoteChar);
		if(quotes || v.indexOf('\r')>=0 || v.indexOf('\n')>=0) {
			v = quoteChar + v + quoteChar;
		}
		return v;
	}
	
	public static String unquote(String v, char quoteChar) {
		String r = v;
		if(v.length()>1 && v.charAt(0)==quoteChar && v.charAt(v.length()-1)==quoteChar) {
			r = v.substring(1, v.length()-1);
			r = r.replace(""+quoteChar+quoteChar, ""+quoteChar);
		}
		return r;
	}
}
