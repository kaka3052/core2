package com.hp.itis.core2.evf;

import java.util.List;

public interface Section extends Iterable<Record>, Cloneable {
	String name();
	Meta meta();
	Record addRecord();
	Record addRecord(Record record);
	Record getRecord(int index);
	void clearRecords();
	void addMemo(String memo);
	void clearMemos();
	List<String> getMemos();
	void removeRecord(Record record);
	Section owner();
	void owner(Section owner);
	int count();
	Section clone();
}
