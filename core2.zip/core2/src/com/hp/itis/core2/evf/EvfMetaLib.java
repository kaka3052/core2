package com.hp.itis.core2.evf;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.hp.itis.core2.file.ExPathExpander;
import com.hp.itis.core2.file.TextFile;

public class EvfMetaLib implements MetaLib {

	private String config;
	private List<MetaLib> metaLibs = new ArrayList<MetaLib>();

	public EvfMetaLib() {
	}
	
	public EvfMetaLib(String conf) throws IOException {
		config = conf;
		init();
	}
	
	@Override
	public Meta getMeta(String name) {
		Meta meta = _getMeta(name);
		if(null == meta)
			meta = _getMeta(null);
		return meta;
	}
	
	public Meta _getMeta(String name) {
		for(MetaLib lib : metaLibs) {
			Meta meta = lib.getMeta(name);
			if(null != meta)
				return meta;
		}
		return null;
	}
	
	public void setConfig(String v) {
		config = v;
	}
	
	public void init() throws IOException {
		List<String> files;
		if(config.contains("*") || config.contains("?"))
			files = ExPathExpander.expand(config);
		else {
			files = new ArrayList<String>();
			if(config.contains(",")) {
				String[] confs = config.split(",");
				for(String conf : confs)
					files.add(conf.trim());
			}
			else
				files.add(config.trim());
		}
		metaLibs.clear();
		for(String file : files) {
			EvfDocument lib = new EvfDocument();
			lib.parse(TextFile.getResource(file));
			metaLibs.add(lib);
		}
	}

}
