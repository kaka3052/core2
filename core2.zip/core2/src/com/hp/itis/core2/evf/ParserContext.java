package com.hp.itis.core2.evf;

import com.hp.itis.core2.vars.IGetterVars;
import com.hp.itis.core2.vars.IWritableVars;

public interface ParserContext extends IWritableVars, IGetterVars {

	Meta getMeta();
	ParserEventSink getEventSink();
	
}
