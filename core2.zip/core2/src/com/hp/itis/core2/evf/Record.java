package com.hp.itis.core2.evf;

import java.util.Date;

import com.hp.itis.core2.vars.IEnumerableVars;
import com.hp.itis.core2.vars.IGetterVars;
import com.hp.itis.core2.vars.IWritableVars;

public interface Record extends Cloneable, IWritableVars, IEnumerableVars, IGetterVars {
	
	void put(int index, Object value);
	
	void setValues(String[] values);
	
	Meta meta();
	
	Section owner();
	
	void owner(Section owner);
	
	Record clone();
	
	Object get(int index);

	int getInt(int index);

	char getChar(int index);

	byte getByte(int index);

	float getFloat(int index);

	short getShort(int index);

	double getDouble(int index);

	boolean getBoolean(int index);
	
	Number getNumber(int index);

	long getLong(int index);

	String getString(int index);

	Date getDate(int index);

	int get(int index, int def);

	char get(int index, char def);

	byte get(int index, byte def);

	long get(int index, long def);

	float get(int index, float def);

	short get(int index, short def);

	double get(int index, double def);

	boolean get(int index, boolean def);

	String get(int index, String def);

	Date get(int index, Date def);

	Object get(int index, Object def);
}
