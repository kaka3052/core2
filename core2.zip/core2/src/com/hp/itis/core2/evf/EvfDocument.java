package com.hp.itis.core2.evf;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class EvfDocument implements Section, MetaLib, Cloneable {

	protected List<Section> sections = new ArrayList<Section>();
	protected String charset = null;
	protected EvfDocument schema = null;
	
	public EvfDocument() {
		clear();
	}
	
	public EvfDocument(EvfDocument schema) {
		if(null == schema)
			return;
		for(Section section : schema.sections) {
			Section cSection = new BasicSection();
			cSection.meta().baseMeta(section.meta());
			sections.add(cSection);
		}
		this.schema = schema;
		this.charset = schema.charset;
	}
	
	public List<Section> sections() {
		return sections;
	}
	
	public String charset() {
		String r = null;
		if(null != defaultSection()) {
			r = defaultSection().meta().charset();
		}
		if(r == null)
			r = charset;
		if(r == null)
			r = EvfParseUtil.DEF_CHARSET;
		return r;
	}
	
	public void charset(String value) {
		this.charset = value;
	}
	
	public void clear() {
		sections.clear();
		sections.add(new BasicSection());
	}
	
	public void clearData() {
		for(Section section : sections)
			section.clearRecords();
	}
	
	public void parse(String text) throws IOException {
		parse(text, null);
	}
	
	public void parse(String text, MetaLib metaLib) throws IOException {
		parse(new StringReader(text), metaLib, null);
	}
	
	public void parse(Reader reader) throws IOException {
		parse(reader, null);
	}
	
	public void parse(Reader reader, MetaLib metaLib) throws IOException {
		parse(reader, metaLib, null);
	}
	
	public void parse(Reader reader, MetaLib metaLib, EvfEventSink evt) throws IOException {
		Parser parser = new EvfParser();
		parser.parse(reader, createParserContext(metaLib, evt));
	}
	
	public void parse(File file) throws IOException {
		parse(file, null);
	}
	
	public void parse(File file, MetaLib metaLib) throws IOException {
		parse(file, metaLib, null);
	}
	
	public void parse(File file, MetaLib metaLib, EvfEventSink evt) throws IOException {
		parse(new FileInputStream(file), metaLib, evt);
	}
	
	public void parse(InputStream is) throws IOException {
		parse(is, null);
	}
	
	public void parse(InputStream is, MetaLib metaLib) throws IOException {
		parse(is, metaLib, null);
	}
	
	public void parse(InputStream is, MetaLib metaLib, EvfEventSink evt) throws IOException {
		Parser parser = new EvfParser();
		parser.parse(is, charset, createParserContext(metaLib, evt));
	}
	
	public void addSection(Section section) {
		if(!sections.contains(section)) {
			sections.add(section);
			section.owner(this);
		}
	}
	
	public Section getSection(int index) {
		return sections.get(index);
	}
	
	public Section getSection(String name) {
		for(Section s : sections) {
			if(null==name && null == s.name())
				return s;
			if(name.equals(s.name()))
				return s;
		}
		return null;
	}
	
	public int sectionCount() {
		return sections.size();
	}
	
	public Section defaultSection() {
		if(sections.size()>0)
			return getSection(0);
		else
			return null;
	}
	
	public void removeSection(Section section) {
		sections.remove(section);
	}
	
	public void write(OutputStream os) throws IOException {
		(new EvfWriter()).write(os, this);
	}

	@Override
	public Meta getMeta(String name) {
		Section section = getSection(name);
		if(null != section)
			return section.meta();
		return null;
	}
	
	protected ParserContext createParserContext(final MetaLib metaLib, final EvfEventSink eventSink) {
		final DefaultParserContext context = new DefaultParserContext();
		context.setMeta(meta());
		EvfParserEventSink es = new EvfParserEventSink(){
			private Section currentSection;
			private int sIndex = 0;
			private int rCount = 0;
			
			@Override
			public String onAppendMemo(String memo) {
				if(null != eventSink)
					memo = eventSink.onAppendMemo(memo);
				if(null != memo)
					currentSection.addMemo(memo);
				return memo;
			}

			@Override
			public MetaValue onAppendMeta(MetaValue metaValue) {
				if(null != eventSink)
					metaValue = eventSink.onAppendMeta(metaValue);
				if(null != metaValue) {
					currentSection.meta().put(metaValue.getName(), metaValue.getValue());
					if("meta".equals(metaValue.getName()) && null != metaLib) {
						currentSection.meta().baseMeta(metaLib.getMeta((String)metaValue.getValue()));
					}
				}
				return metaValue;
			}

			private Record appendRecord(Record record) {
				rCount++;
				if(rCount == 1 && currentSection.meta().isTitled()) {
					currentSection.meta().setTitles(record);
					return record;
				}
				if(null != eventSink)
					record = eventSink.onAppendRecord(record);
				if(null != record)
					currentSection.addRecord(record);
				return record;
			}
			
			@Override
			public String onParseLine(String line) {
				if(null != eventSink)
					return eventSink.onParseLine(line);
				if(currentSection.meta().isTrimValues() && null != line)
					line = line.trim();
				return line;
			}

			@Override
			public void onSectionBegin() {
				if(null != eventSink)
					eventSink.onSectionBegin();
				currentSection = newSection();
				rCount = 0;
			}

			@Override
			public boolean onSectionEnd() {
				boolean r = true;
				if(null != eventSink) 
					r = eventSink.onSectionEnd();
				if(r)
					EvfDocument.this.addSection(currentSection);
				return r;
			}

			public Section newSection() {
				Section section = null;
				if(sIndex < sections.size()) 
					section = getSection(sIndex);
				else {
					section = new BasicSection();
				}
				sIndex++;
				section.owner(EvfDocument.this);
				context.setMeta(section.meta());
				return section;
			}

			@Override
			public String[] onParseValues(String[] values) {
				if(null != eventSink)
					values = eventSink.onParseValues(values);
				if(null != values) {
					Record record = null;
					if(null != values && values.length>0) {
						record = new BasicRecord(currentSection);
						record.setValues(values);
					}
					if(null != record)
						appendRecord(record);
				}
				return values;
					
			}

			@Override
			public boolean onContinue() {
				return true;
			}

			@Override
			public void onParseBegin() {
				
			}

			@Override
			public void onParseEnd() {
				
			}
			
		};
		context.setEventSink(es);
		return context;
	}
	
	@Override
	public EvfDocument clone() {
		EvfDocument r = new EvfDocument();
		for(Section sec : sections) {
			Section cSec = sec.clone();
			cSec.owner(this);
			r.sections.add(cSec);
		}
		r.schema = schema;
		return r;
	}

	@Override
	public void addMemo(String memo) {
		defaultSection().addMemo(memo);
	}

	@Override
	public Record addRecord() {
		return defaultSection().addRecord();
	}

	@Override
	public Record addRecord(Record record) {
		return defaultSection().addRecord(record);
	}

	@Override
	public void clearMemos() {
		defaultSection().clearMemos();
	}

	@Override
	public void clearRecords() {
		defaultSection().clearRecords();
	}

	@Override
	public int count() {
		return defaultSection().count();
	}

	@Override
	public List<String> getMemos() {
		return defaultSection().getMemos();
	}

	@Override
	public Record getRecord(int index) {
		return defaultSection().getRecord(index);
	}

	@Override
	public Meta meta() {
		return defaultSection().meta();
	}

	@Override
	public String name() {
		return defaultSection().name();
	}

	@Override
	public void removeRecord(Record record) {
		defaultSection().removeRecord(record);
	}

	@Override
	public Iterator<Record> iterator() {
		return defaultSection().iterator();
	}

	@Override
	public Section owner() {
		return null;
	}

	@Override
	public void owner(Section owner) {
		
	}
}
