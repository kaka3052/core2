package com.hp.itis.core2.evf;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.hp.itis.core2.vars.GetterVars;

public class EvfParser extends BasicParser {
	
	private class EvfParserContext extends GetterVars implements ParserContext {

		private Parser parser;
		private ParserContext context;
		private EvfParserEventSink evfEventSink;
		private EvfParserEventSink eventSink;
		private boolean sectionBegan = false;
		
		public EvfParserContext(Parser parser, ParserContext context) {
			this.context = context;
			this.parser = parser;
			eventSink = (EvfParserEventSink)context.getEventSink();
			
			evfEventSink =  new EvfParserEventSink() {
				
				@Override
				public String onAppendMemo(String memo) {
					if(memo.length()>0 && memo.charAt(0)==EvfParseUtil.META_CHAR) {
						MetaValue mv = new MetaValue(memo.substring(1, memo.length()), EvfParserContext.this.context.getMeta().quoteChar());
						if(null != mv.getName()) {
							onAppendMeta(mv);
							if(EvfParseUtil.MF_META.equals(mv.getName()))
								EvfParserContext.this.parser.reset(EvfParserContext.this.context);
						}
						return null;
					}
					else {
						if(null != memo)
							return eventSink.onAppendMemo(memo);
						return memo;
					}
				}

				@Override
				public boolean onContinue() {
					return eventSink.onContinue();
				}

				@Override
				public void onParseBegin() {
					eventSink.onParseBegin();
					eventSink.onSectionBegin();
					sectionBegan = true;
				}

				@Override
				public void onParseEnd() {
					if(sectionBegan) {
						sectionBegan = !eventSink.onSectionEnd();
					}
					eventSink.onParseEnd();
				}

				@Override
				public String onParseLine(String line) {
					line = eventSink.onParseLine(line);
					if(line.length() == 0) {
						if(sectionBegan) {
							sectionBegan = !eventSink.onSectionEnd();
						}
						return null;
					}
					if(!sectionBegan) {
						eventSink.onSectionBegin();
						sectionBegan = true;
					}
					return line;
				}

				@Override
				public String[] onParseValues(String[] values) {
					return eventSink.onParseValues(values);
				}

				@Override
				public MetaValue onAppendMeta(MetaValue metaValue) {
					return eventSink.onAppendMeta(metaValue);
				}

				@Override
				public void onSectionBegin() {
					eventSink.onSectionBegin();
				}

				@Override
				public boolean onSectionEnd() {
					return eventSink.onSectionEnd();
				}
				
			};
			
		}
		

		@Override
		public Object get(String key) {
			Object r = context.get(key);
			if(null != r)
				return r;
			if(null != context.getMeta())
				return context.getMeta().get(key);
			return null;
		}
		
		@Override
		public ParserEventSink getEventSink() {
			return evfEventSink;
		}

		@Override
		public Meta getMeta() {
			return context.getMeta();
		}

		@Override
		public void put(String key, Object value) {
			context.put(key, value);
		}
		

	}

	private Parser parser;

	public EvfParser() {
	}
	

	public void parse(InputStream is, String charset, ParserContext context) throws IOException {
		if(charset==null) {
			charset = detectCharset(is, 500, EvfParseUtil.DEF_CHARSET);
		}
		super.parse(is, charset, context);
	}
	
	public void parse(Reader reader, ParserContext context) throws IOException {
		String pm = context.getString("parser");
		if("pattern".equals(pm))
			parser = new PatternParser();
		else
			parser = new CsvParser();
		parser.parse(reader, new EvfParserContext(parser, context));
	}
	
	public String detectCharset(InputStream is, int detectLen, String defCharset) throws IOException {
		if(!is.markSupported())
			return defCharset;
		is.mark(detectLen);
		try {
			byte buf[] = new byte[detectLen];
			is.read(buf);
			Reader r = new InputStreamReader(new ByteArrayInputStream(buf), defCharset);
			String line = EvfParseUtil.readLine(r);
			if(line.length()>1 && line.charAt(0)==EvfParseUtil.MEMO_CHAR && line.charAt(1)==EvfParseUtil.META_CHAR) {
				int p = line.indexOf(EvfParseUtil.META_VALUE_CHAR);
				if(p>0) {
					String name = line.substring(2, p);
					String value = line.substring(p+1, line.length());
					if(name.equals(EvfParseUtil.MF_CHARSET))
						return value;
				}
			}
			return defCharset;
		}
		finally {
			is.reset();
		}
	}
}
