package com.hp.itis.core2.misc;

import org.apache.commons.logging.Log;

public interface PLog extends Log{

	void debug(Object obj, Object... args);

	void error(Object obj, Object... args);

	void fatal(Object obj, Object... args);

	void info(Object obj, Object... args);

	void warn(Object obj, Object... args);

	void trace(Object obj, Object... args);

	boolean isEnabled();

	void setEnabled(boolean enabled);
	
}