package com.hp.itis.core2.misc;


public class SException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6148430434936903473L;
	private Object o;

	public SException(Object o, Throwable cause) {
		super(cause);
		this.o = o;
	}

	public SException(Object o, String message, Throwable cause) {
		super(message, cause);
		this.o = o;
	}

	public SException(Object o, String message) {
		super(message);
		this.o = o;
	}

	public SException(Object o, int code, Object... args) {
		super(getMessage(o.getClass(), code, args));
		this.o = o;
	}
	
	protected static String mapMessage(String name, Integer code, Object... args) {
		String message = CodeMapper.instance().map(name, code.toString());
		if(message != null) {
			message = String.format(message, args);
			return message;
		}
		return null;
	}

	protected static String getMessage(Class<?> c, Integer code, Object... args) {
		while(c != Object.class && c != null) {
			String message = mapMessage(c.getSimpleName(), code, args);
			if(message != null) {
				return message;
			}
			c = c.getSuperclass();
		}
		return "UNKNOW ERROR: " + code;
	}

	public Object getSrc() {
		return o;
	}

}
