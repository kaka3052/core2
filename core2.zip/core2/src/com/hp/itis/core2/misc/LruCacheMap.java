package com.hp.itis.core2.misc;

import java.util.LinkedHashMap;
import java.util.Map;

public class LruCacheMap<K, V> extends LinkedHashMap<K, V> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1025642244298867715L;
	private int cacheSize = 1000;

	public LruCacheMap(int cacheSize, int initialCapacity, float loadFactor) {
		super(initialCapacity, loadFactor);
		this.cacheSize = cacheSize;
	}
	
	public LruCacheMap(int cacheSize) {
		super();
		this.cacheSize = cacheSize;
	}
	
    @Override 
    protected boolean removeEldestEntry (Map.Entry<K,V> eldest) {
        	return size() > cacheSize; 
    }
}
