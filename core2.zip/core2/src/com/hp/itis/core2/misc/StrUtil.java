package com.hp.itis.core2.misc;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.hp.itis.core2.commdata.TypeCaster;


public class StrUtil {

	/**
	 * 功能：进行简单的字符串转换 例子： 调用 TransformStr("123-456", "(\\d{3})\-(\\d{3})",
	 * "${2}-${1}"); 返回结果为：456-123 备注： 如果字符串没有匹配模板，则返回源字符串
	 * 
	 * @param str
	 *            源字符串
	 * @param patternStr
	 *            匹配模板字符串
	 * @param formatStr
	 *            格式字符串
	 * @return 转换后的字符串
	 */
	public static synchronized String transform(String str, String patternStr,
			String formatStr) {
		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(str);
		if (matcher.find()) {
			for (int i = 0; i <= matcher.groupCount(); i++) {
				formatStr = formatStr.replace("${" + i + "}", matcher.group(i));
			}
			return formatStr;
		}
		return str;
	}
	
	public static synchronized long str2Millisec(String str)
	{
		Double result = 0d;
		Pattern pattern;
		pattern = Pattern.compile("([\\-\\+]?)(([\\d\\.]+)w)?(([\\d\\.]+)d)?(([\\d\\.]+)h)?(([\\d\\.]+)m)?(([\\d\\.]+)s)?(([\\d\\.]+))?");
		Matcher matcher = pattern.matcher(str);
		if(matcher.find())
		{
			//w
			String part = matcher.group(3);
			if(part!=null)
				result += Double.valueOf(part) * 7*24*60*60*1000;
			//d
			part = matcher.group(5);
			if(part!=null)
				result += Double.valueOf(part) * 24*60*60*1000;
			
			//h
			part = matcher.group(7);
			if(part!=null)
				result += Double.valueOf(part) * 60*60*1000;
			
			//m
			part = matcher.group(9);
			if(part!=null)
				result += Double.valueOf(part) * 60*1000;
			
			//s
			part = matcher.group(11);
			if(part!=null)
				result += Double.valueOf(part) * 1000;
			//s
			part = matcher.group(13);
			if(part!=null)
				result += Double.valueOf(part);
			part = matcher.group(1);
			if(part.equals("-"))
				result = -result;
		}
		return result.longValue();
	}
	/**
	 * 	>1000就是s,>60000就是m，>3600000就是h
	 *  向上取值 ，如果有余数则下一级
	 * @param millsec
	 * @return
	 */
	
	public static String millisecToStr(long millsec){
		int h=1000*60*60;
		int m=1000*60;
		int s=1000;
		String re=String.valueOf(millsec);
		if(millsec>=h && millsec % h==0){
    	   re=String.valueOf(millsec/h)+"h";    	
    	}else if(millsec>=m && millsec % m==0){
    	   re=String.valueOf(millsec/m)+"m";
    	}else if(millsec>=s && millsec % s==0){
    	   re=String.valueOf(millsec/s)+"s";
    	}else{
    	   re=String.valueOf(millsec);
    	} 
		return re;
	}
    public static String domToStr(Node node) {
    	try {
	    	TransformerFactory tf = TransformerFactory.newInstance();
	    	Transformer t = tf.newTransformer();
	    	Document doc = null;
	    	if(node instanceof Document)
	    		doc = (Document)doc;
	    	else
	    		doc = node.getOwnerDocument();
	    	if(null != doc)
	    		t.setOutputProperty("encoding", doc.getInputEncoding());
	    	ByteArrayOutputStream bos = new ByteArrayOutputStream();
	    	t.transform(new DOMSource(node), new StreamResult(bos));
	    	return bos.toString();
    	}
    	catch(Throwable e) {
    		return null;
    	}
    }
    
    public static String arrayToStr(Object o) {
		if(o instanceof String[]) {
			return Arrays.toString((String[])o);
		}
		else if(o instanceof Object[]) {
			return Arrays.toString((Object[])o);
		}
		else if(o instanceof int[]) {
			return Arrays.toString((int[])o);
		}
		else if(o instanceof long[]) {
			return Arrays.toString((long[])o);
		}
		else if(o instanceof char[]) {
			return Arrays.toString((char[])o);
		}
		else if(o instanceof byte[]) {
			return Arrays.toString((byte[])o);
		}
		else if(o instanceof float[]) {
			return Arrays.toString((float[])o);
		}
		else if(o instanceof boolean[]) {
			return Arrays.toString((boolean[])o);
		}
		else if(o instanceof double[]) {
			return Arrays.toString((double[])o);
		}
		else if(o instanceof short[]) {
			return Arrays.toString((short[])o);
		}
		else
			return o.toString();
    }
    
    public static String pojoToStr(Object o) {
		StringBuilder sb = new StringBuilder();
		sb.append(o.getClass().getSimpleName());
		sb.append("{ ");
		Method[] methods = o.getClass().getDeclaredMethods();
		int c = 0;
		for(Method method : methods) {
			String name = method.getName();
			if(method.getParameterTypes().length==0) {
				if(name.startsWith("get"))
					name = name.substring(3);
				else if(name.startsWith("is"))
					name = name.substring(2);
				else
					continue;
				if(name.length()==0)
					continue;
				name = name.substring(0, 1).toLowerCase()
					+ name.substring(1);
				if(c>0)
					sb.append(", ");
				c++;
				sb.append(name);
				Object value = null;
				try {
					value = method.invoke(o);
					if(value instanceof Date) {
						SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
						value = format.format(value);
					}
					
				} catch (Exception e) {
					value = "*ERROR*";
					continue;
				}
				boolean quote = !(null == value || value instanceof Number || value instanceof Boolean);
				sb.append(":");
				if(quote)
					sb.append("\"");
				sb.append(value);
				if(quote)
					sb.append("\"");
			}
		}
		sb.append(" }");
		return sb.toString();
    }
	
	public static String toString(Object o) {
		if(null == o)
			return "null";
		if(o instanceof Node)
			return domToStr((Node)o);
		else if(TypeCaster.isBasicType(o)||o instanceof Map<?,?> || o instanceof Collection<?>)
			return o.toString();
		else if(o.getClass().isArray())
			return arrayToStr(o);
		else
			return pojoToStr(o);
	}
	
	/**
	 * 功能：将字符串转换为Map<String, String>
	 * 
	 * @param str
	 *            输入字符串
	 * @param splitter
	 *            行分隔符
	 * @param separator
	 *            键值分隔符
	 * @return
	 */
	public static Map<String, String> str2map(String str, String splitter,
			String separator) {
		String[] ta = str.split(splitter);
		Map<String, String> ret = new LinkedHashMap<String, String>();
		for (String line : ta) {
			int p = line.indexOf(separator);
			if(p>=0)
				ret.put(line.substring(0, p), line
						.substring(p + separator.length()));
			else
				ret.put(line, null);
		}
		return ret;
	}
	
	@SuppressWarnings({ "unchecked" })
	public static <T> List<T> str2list(String value, Class<T> type, String spliter) {
		if(value == null)
			return null;
		String[] values = value.split(",");
		List<T> result = new ArrayList<T>();
		for(String v : values)
			result.add((T)TypeCaster.cast(type, v));
		return result;
	}
	
	public static String reEsc(String expr) {
		expr = expr.replace(".", "\\.");
		expr = expr.replace("-", "\\-");
		expr = expr.replace("+", "\\+");
		expr = expr.replace("[", "\\[");
		expr = expr.replace("]", "\\]");
		expr = expr.replace("(", "\\(");
		expr = expr.replace(")", "\\)");
		expr = expr.replace("{", "\\{");
		expr = expr.replace("}", "\\}");
		expr = expr.replace("$", "\\$");
		expr = expr.replace("^", "\\^");
		expr = expr.replace("?", "\\?");
		return expr;
	}
	
	public static String neToRe(String expr) {
		expr = expr.replace(".", "\\.");
		expr = expr.replace("-", "\\-");
		expr = expr.replace("+", "\\+");
		expr = expr.replace("[", "\\[");
		expr = expr.replace("]", "\\]");
		expr = expr.replace("(", "\\(");
		expr = expr.replace(")", "\\)");
		expr = expr.replace("{", "\\{");
		expr = expr.replace("}", "\\}");
		expr = expr.replace("$", "\\$");
		expr = expr.replace("^", "\\^");
		expr = expr.replace("*", ".*");
		expr = expr.replace("?", ".");
		return "^" + expr + "$";
	}
	
	public static String strEnc(String str) {
		str = str.replace("\\", "\\\\");
		str = str.replace("\n", "\\n");
		str = str.replace("\r", "\\r");
		str = str.replace("\t", "\\t");
		str = str.replace("\f", "\\f");
		return str;
	}
	
	public static String strDec(String str) {
		str = str.replace("\\\\", "\\");
		str = str.replace("\\n", "\n");
		str = str.replace("\\r", "\r");
		str = str.replace("\\t", "\t");
		str = str.replace("\\f", "\f");
		return str;
	}
	
	public static boolean neMatch(String pattern, String value) {
		return Pattern.matches(neToRe(pattern), value);
	}
	
	public static Pattern nePattern(String pattern) {
		return Pattern.compile(neToRe(pattern));
	}

	/**
	 * 按正则表达式条件保留字符串列表的匹配项
	 * 
	 * @param list
	 *            需保留匹配项的字符串列表
	 * @param neStr
	 *            正则表达式串
	 */
	public static void neFilter(List<String> list, String pattern) {
		Pattern p = Pattern.compile(neToRe(pattern));
		for (int i = list.size() - 1; i >= 0; i--) {
			Matcher matcher = p.matcher(list.get(i));
			if (!matcher.find())
				list.remove(i);
		}

	}
}
