package com.hp.itis.core2.misc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
/**
 * 平台服务类，封装了一些基本的平台相关方法
 * @author changjiang
 *
 */
public class Platform {
	
	public static String execProcess(String... cmd) throws Exception
	{
		List<String> processCmd = new ArrayList<String>();
		for(String p : cmd)
			processCmd.add(p);
		return execProcess(processCmd, null, null, (InputStream)null, (OutputStream)null);
	}
	
	public static String execProcess(List<String> processCmd) throws Exception
	{
		return execProcess(processCmd, null, null, (InputStream)null, (OutputStream)null);
	}
	
	public static String execProcess(List<String> processCmd, Map<String, String> envs) throws Exception
	{
		return execProcess(processCmd, envs, null, (InputStream)null, (OutputStream)null);
	}
	
	public static String execProcess(List<String> processCmd, Map<String, String> envs, String workPath, final InputStream ifs, final OutputStream ofs) throws Exception
	{
		try {
			ProcessBuilder pb = new ProcessBuilder(processCmd);
			Process p;
			if(null == envs)
				envs = new HashMap<String, String>();
			pb.environment().putAll(envs);
	        //设置工作路径为子进程应用的目录
			if(null == workPath)
				workPath = new File(processCmd.get(0)).getParent();
			File wp = null;
			if(null != workPath) {
				wp = new File(workPath);
				if(!wp.exists())
					wp = null;
			}
			//手动参数
			if(processCmd.size()>1) { 
				pb.environment().putAll(envs);
				if(null != wp)
					pb.directory(wp);
				
				//merge the error output with the standard output
				pb.redirectErrorStream(true);
		        p = pb.start();
			}
			//采用系统的参数解析方式
			else {
				String[] envList = new String[envs.size() + 1];
				int i=0;
				for(Entry<String, String> entry : envs.entrySet()) {
					envList[i] = entry.getKey() + "=" + entry.getValue();
					i++;
				}
				envList[i] =  "PATH=" + System.getenv("PATH");
				String command = processCmd.get(0);
				if(System.getProperty("os.name").toUpperCase().indexOf("WINDOWS")>=0) {
					String[] cmdList = new String[3];
					cmdList[0] = "cmd.exe";
					cmdList[1] = "/C";
					cmdList[2] = command;
					p = Runtime.getRuntime().exec(cmdList, envList, wp);
				}
				else
					p = Runtime.getRuntime().exec(command, envList, wp);
			}
	        
			if(ifs!=null)
			{
				final OutputStream os = p.getOutputStream();
				new Thread(){
					public void run() {
						byte[] buf = new byte[512];
						int readbytes;
						try
						{
							while (true)
							{
								readbytes = ifs.read(buf);
								if(readbytes < 0) break;
								os.write(buf, 0, readbytes);
							}
						}catch(Exception e)
						{
							e.printStackTrace();
						}
					}
				}.start();
			}
			
	        if(ofs!=null)
	        {
	            InputStream ins = p.getInputStream();
	            byte[] buf = new byte[200];
				while (true) {
					int readbytes = ins.read(buf);
					if (readbytes < 0)
						break;
					ofs.write(buf, 0, readbytes);
				}
				ofs.close();
	        }
	        if(0!=p.waitFor())
	        {
	        	BufferedReader br = new BufferedReader(new InputStreamReader(p.getErrorStream()));
	        	StringBuffer sb = new StringBuffer();
	            String s;
	            while((s=br.readLine())!=null){
	            	sb.append(s);
	            }
	            return sb.toString();
	        }
	        else
	        	return null;
		}
		finally
		{
			if(null != ifs)
				ifs.close();
			if(null != ofs)
				ofs.close();
		}
	}
	
	public static String execProcess(List<String> processCmd, Map<String, String> envs, String workPath, String inputFileName, String outputFileName) throws Exception
	{	InputStream ifs = null;
		OutputStream ofs = null;
		if(inputFileName!=null && inputFileName.length()>0)
		{
			//从文件中读取数据写入进程的标准输入流
			File inputFile = new File(inputFileName);
			ifs = new FileInputStream(inputFile);
		}
		
        if(outputFileName!=null && outputFileName.length()>0)
        {
	        File outFile = new File(outputFileName);
	        //创建必要的目录
			File dir = new File(outFile.getParent());
			if (!dir.exists())
				dir.mkdirs();
			//将标准输出流保存置指定文件
			ofs = new FileOutputStream(outFile, false);
        }
        return execProcess(processCmd, envs, workPath, ifs, ofs);
	}
	
	//删除文件夹下所有内容，包括此文件夹
	public static void deletePath(File f) throws IOException {
	    if(!f.exists())//文件夹不存在不存在
	      throw new IOException("指定目录不存在:"+f.getName());

	    boolean rslt=true;//保存中间结果
	    if(!(rslt=f.delete())){//先尝试直接删除
	      //若文件夹非空。枚举、递归删除里面内容
	      File subs[] = f.listFiles();
	      for (int i = 0; i <= subs.length - 1; i++) {
	        if (subs[i].isDirectory())
	        	deletePath(subs[i]);//递归删除子文件夹内容
	        rslt = subs[i].delete();//删除子文件夹本身
	      }
	      rslt = f.delete();//删除此文件夹本身
	    }

	    if(!rslt)
	      throw new IOException("无法删除:"+f.getName());
	    return;
	}

}
