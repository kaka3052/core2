package com.hp.itis.core2.misc;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.List;

import com.hp.itis.core2.file.ExPathExpander;

public class ExClassLoader extends URLClassLoader {

	public ExClassLoader() {
		super(null);
	}
	
	public ExClassLoader(ClassLoader parent) {
		super(new URL[0], parent);
	}
	
	public void addURL(String url) {
		try {
			super.addURL(new URL(url));
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void addJars(String path) {
		List<String> paths = ExPathExpander.expand(path);
		for(String p : paths) {
			addURL("jar:file:/" + new File(p).getAbsolutePath() + "!/");
		}
	}
	
	public void addPath(String path) {
		if(path.startsWith("jar:") || path.startsWith("file:"))
			addURL(path);
		else {
			File f = new File(path);
			if(f.isDirectory()) {
				addURL("file:/" + f.getAbsolutePath());
			}
			else
				addJars(path);
		}
	}

}
