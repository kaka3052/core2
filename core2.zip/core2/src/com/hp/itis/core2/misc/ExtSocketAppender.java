package com.hp.itis.core2.misc;

import java.lang.reflect.Field;

import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.net.SocketAppender;
import org.apache.log4j.spi.LoggingEvent;

public class ExtSocketAppender extends SocketAppender {
	
	private String clientName = null;
	
	public void activateOptions() {
		LogLog.setQuietMode(true);
		super.activateOptions();
		LogLog.setQuietMode(false);
	}
	
	public void append(LoggingEvent event) {
		if(null != clientName) {
			try {
				Field field = event.getClass().getDeclaredField("threadName");
				field.setAccessible(true);
				field.set(event, clientName);
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}
		super.append(event);
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	
}
