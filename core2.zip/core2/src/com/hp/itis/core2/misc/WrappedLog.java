package com.hp.itis.core2.misc;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class WrappedLog implements PLog {

	protected Log log;
	protected String name = null;
	protected String[] defNames = null;
	protected boolean enabled = true;
	
	public WrappedLog(Log log)
	{
		this.log = log;
	}
	
	protected Log log() {
		return log;
	}
	
	public WrappedLog(String name, String... defs)
	{
		log = LogFactory.getLog(name);
		this.name = name;
		this.defNames = defs;
	}
	
	protected String wrap(Object obj, Object... args)
	{
		String message = null;
		if(obj instanceof Integer) {
			if(name != null)
				message = CodeMapper.instance().map(name, obj.toString());
			String[] defs = defNames();
			if(null == message && defs != null) {
				for(int i=0; i<defs.length; i++) {
					message = CodeMapper.instance().map(defs[i], obj.toString());
					if(message != null)
						break;
				}
			}
			if(null == message)
				message = "UNKNOWN RESOUCE ID: " + obj;
		}
		else
			message = obj.toString();
		if(null == args || args.length==0)
			return message.toString();
		return String.format(message.toString(), args);
	}
	
	protected String[] defNames() {
		return defNames;
	}
	
	public void debug(Object obj) {
		if(enabled && log().isDebugEnabled())
			log().debug(wrap(obj));
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.procengine.log.PLog#debug(java.lang.Object, java.lang.Object)
	 */
	public void debug(Object obj, Object... args) {
		if(enabled && log().isDebugEnabled())
			log().debug(wrap(obj, args));
	}

	public void debug(Object obj, Throwable error) {
		if(enabled && log().isDebugEnabled())
			log().debug(wrap(obj), error);
	}

	public void error(Object obj) {
		if(enabled && log().isErrorEnabled())
			log().error(wrap(obj));
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.procengine.log.PLog#error(java.lang.Object, java.lang.Object)
	 */
	public void error(Object obj, Object... args) {
		if(enabled && log().isErrorEnabled())
			log().error(wrap(obj, args));
	}

	public void error(Object obj, Throwable error) {
		if(enabled && log().isErrorEnabled())
			log().error(wrap(obj), error);
	}

	public void fatal(Object obj) {
		if(enabled && log().isFatalEnabled())
			log().fatal(wrap(obj));
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.procengine.log.PLog#fatal(java.lang.Object, java.lang.Object)
	 */
	public void fatal(Object obj, Object... args) {
		if(enabled && log().isFatalEnabled())
			log().fatal(wrap(obj, args));
	}

	public void fatal(Object obj, Throwable error) {
		if(enabled && log().isFatalEnabled())
			log().fatal(wrap(obj), error);
	}

	public void info(Object obj) {
		if(enabled && log().isInfoEnabled())
			log().info(wrap(obj));
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.procengine.log.PLog#info(java.lang.Object, java.lang.Object)
	 */
	public void info(Object obj, Object... args) {
		if(enabled && log().isInfoEnabled())
			log().info(wrap(obj, args));
	}

	public void info(Object obj, Throwable error) {
		if(enabled && log().isInfoEnabled())
			log().info(wrap(obj), error);
	}

	public void warn(Object obj) {
		if(enabled && log().isInfoEnabled())
			log().warn(wrap(obj));
	}

	/* (non-Javadoc)
	 * @see com.hp.itis.core2.procengine.log.PLog#warn(java.lang.Object, java.lang.Object)
	 */
	public void warn(Object obj, Object... args) {
		if(enabled && log().isWarnEnabled())
			log().warn(wrap(obj, args));
	}
	
	public void warn(Object obj, Throwable error) {
		if(enabled && log().isWarnEnabled())
			log().warn(wrap(obj), error);
	}
	
	@Override
	public void trace(Object obj) {
		if(enabled && log().isTraceEnabled())
			log().trace(wrap(obj));
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.procengine.log.PLog#trace(java.lang.Object, java.lang.Object)
	 */
	public void trace(Object obj, Object... args) {
		if(enabled && log().isTraceEnabled())
			log().trace(wrap(obj, args));
	}

	@Override
	public void trace(Object obj, Throwable error) {
		if(enabled && log().isTraceEnabled())
			log().trace(wrap(obj));
	}
	
	@Override
	public boolean isDebugEnabled() {
		return log().isDebugEnabled();
	}

	@Override
	public boolean isErrorEnabled() {
		return log().isErrorEnabled();
	}

	@Override
	public boolean isFatalEnabled() {
		return log().isFatalEnabled();
	}

	@Override
	public boolean isInfoEnabled() {
		return log().isInfoEnabled();
	}

	@Override
	public boolean isTraceEnabled() {
		return log().isTraceEnabled();
	}

	@Override
	public boolean isWarnEnabled() {
		return log().isWarnEnabled();
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

}
