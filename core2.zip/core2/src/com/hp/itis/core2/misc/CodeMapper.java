package com.hp.itis.core2.misc;

import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;
import com.hp.itis.core2.file.TextFile;

/**
 * 资源代码到资源文本的映射类
 * 配置文件格式：
 * <code_res>
 * <resource name="com.example.module.Module1" lang="zh">
 *	<map code="101">系统找不到指定文件</map>
 *	<map code="102">模块[%s]初始化失败</map>
 * </resource>
 * </code_res>
 * 
 * @author changj
 *
 */
public class CodeMapper {
	
	public static class ResourcePattern {
		private String lang;
		private Object code;
		private Object[] args;
		
		public ResourcePattern(String lang, Object code, Object ... args) {
			this.lang = lang;
			this.code = code;
			this.args = args;
		}
		
		public ResourcePattern(Object code, Object ... args) {
			this("", code, args);
		}

		public String getLang() {
			return lang;
		}

		public void setLang(String lang) {
			this.lang = lang;
		}

		public Object getCode() {
			return code;
		}

		public void setCode(Object code) {
			this.code = code;
		}

		public Object[] getArgs() {
			return args;
		}

		public void setArgs(Object[] args) {
			this.args = args;
		}
		
	}
	
	public static class CodeResource {
		private String resName;
		private String lang;
		
		public CodeResource(String resName) {
			this("", resName);
		}
		
		public CodeResource(String lang, String resName) {
			this.resName = resName;
			this.lang = lang;
		}
		
		public String get(Object code) {
			return gets(lang, code);
		}
		
		public String gets(String lang, Object code) {
			return CodeMapper.instance().map(lang, resName, code.toString());
		}
		
		public String get(Object code, String def) {
			String res = get(code);
			if(null == res)
				return def;
			return res;
		}
		
		public String format(Object code, Object ... args) {
			return formats(lang, code, args);
		}
		
		public String format(ResourcePattern pattern) {
			return formats(pattern.getLang(), pattern.getCode(), pattern.getArgs());
		}
		
		public String formats(String lang, Object code, Object ... args) {
			String res = gets(lang, code);
			if(null == res)
				return null;
			return String.format(res, args);
		}
		
		public String formats(String lang, ResourcePattern pattern) {
			return formats(lang, pattern.getCode(), pattern.getArgs());
		}

		public String getResName() {
			return resName;
		}

		public void setResName(String resName) {
			this.resName = resName;
		}

		public String getLang() {
			return lang;
		}

		public void setLang(String lang) {
			this.lang = lang;
		}
	}

	protected static final String RES_LANG_KEY = "res.lang";
	public static final String DEF_RES_FILE = "code_res.xml";
	
	private String lang = "";
	private CommData codeMap;
	private CommData loadCache;
	private static CodeMapper instance = new CodeMapper();
	
	
	public static CodeMapper instance() {
		return instance;
	}
	
	/**
	 * 默认构造器，默认将加载CLASS_PATH下的code_res.xml配置
	 */
	private CodeMapper() {
		clear();
		String lang = System.getProperty(RES_LANG_KEY);
		if(null != lang)
			this.lang = lang;
	}
	
	/**
	 * 添加资源配置
	 * @param resPath
	 */
	public boolean addResource(String resPath) {
		if(loadCache.get(resPath) != null)
			return true;
		loadCache.put(resPath, true);
		InputStream is = TextFile.getResource(resPath);
		if(null != is) {
			return addResource(is);
		}
		return false;
	}
	
	private boolean addResource(Class<?> c, String resPath) {
		if(loadCache.get(resPath) != null)
			return true;
		loadCache.put(resPath, true);
		InputStream is = c.getResourceAsStream(resPath);
		if(null == is)
			is = TextFile.getResource(resPath);
		if(null != is) {
			return addResource(is);
		}
		return false;
	}
	
	public boolean addResource(Class<?> c) {
		String pPath = c.getPackage().getName().replace('.', '/');
		boolean r = false;
		int p = 0;
		String rPath = "";
		while(true) {
			p = pPath.indexOf('/', p+1);
			if(p>=0) {
				rPath = pPath.substring(0, p);
				if(addResource(c, rPath + "/" + DEF_RES_FILE))
					r = true;
			}
			else {
				if(addResource(c, pPath + "/" + DEF_RES_FILE))
					r = true;
				break;
			}
		}
		return r;
	}
	
	public CodeResource getResource(Class<?> c) {
		addResource(c);
		return new CodeResource(lang, c.getSimpleName());
	}
	
	public CodeResource getResource(String lang, Class<?> c) {
		addResource(c);
		return new CodeResource(lang, c.getSimpleName());
	}
	
	public CodeResource getResource(String lang, String resName) {
		return new CodeResource(lang, resName);
	}
	
	public CodeResource getResource(String resName) {
		return new CodeResource(lang, resName);
	}
	
	public CodeResource getResource() {
		return getResource(lang, "");
	}
	
	/**
	 * 添加资源配置
	 * @param is XML格式的配置输入流
	 */
	public boolean addResource(InputStream is) {
		if(null == is)
			return false;
		DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance(); 
		DocumentBuilder builder;
		Document doc;
		try {
			builder = factory.newDocumentBuilder();
			doc = builder.parse(is);
			parse(doc.getDocumentElement());
			return true;
		}
		catch(Exception e) {
			return false;
		}
		finally {
			try {
				is.close();
			} catch (IOException e) {}
		}
	}
	
	public void clear() {
		codeMap = new CommDataImpl();
		loadCache = new CommDataImpl();
		codeMap.add("langMap");
		addResource(DEF_RES_FILE);
	}
	
	/**
	 * 映射资源编号为资源字符串
	 * @param code
	 * @return
	 */
	public String map(String resName, String code) {
		return map(lang, resName, code);
	}
	
	public String map(String lang, String resName, String code) {
		
		String res = _map(lang, resName, code);
		if(null != res)
			return res;
		
		res = _map(lang, "", code);
		return res;
	}
	
	private String _map(String lang, String resName, String code) {
		if(lang == "")
			lang = codeMap.getChild("langMap").get(resName, "");
		CommData resMap = codeMap.getChild(lang + "#" + resName);
		if(null == resMap && lang.indexOf('_')>0) {
			lang = lang.substring(0, lang.indexOf('_'));
			resMap = codeMap.getChild(lang + "#" + resName);
		}
		if(null == resMap) {
			resMap = codeMap.getChild("#" + resName);
		}
		if(null != resMap)
			return resMap.getString(code);
		return null;
	}
	
	public String map(String code) {
		return map("", code);
	}
	
	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}
	
	/**
	 * 解析xml配置为map
	 * @param el
	 */
	private void parse(Element el) {
		NodeList nl = el.getElementsByTagName("resource");
		for(int i=0; i<nl.getLength(); i++) {
			Element resEl = (Element)nl.item(i);
			String lang = resEl.getAttribute("lang");
			String name = resEl.getAttribute("name");
			String resKey = lang + "#" + name;
			CommData resMap = codeMap.getChild(resKey);
			if(null == resMap)
				resMap = codeMap.add(resKey);
			CommData langMap = codeMap.getChild("langMap");
			if(langMap.get(name) == null)
				langMap.put(name, lang);
			NodeList mapsEl = resEl.getElementsByTagName("map");
			for(int j=0; j<mapsEl.getLength(); j++) {
				parseMap((Element)mapsEl.item(j), resMap);
			}
		}
		
		//兼容v1
		NodeList mapsEl = el.getChildNodes();
		String lang = el.getAttribute("lang");
		String resKey = lang + "#";
		CommData resMap = codeMap.getChild(resKey);
		if(null == resMap)
			resMap = codeMap.add(resKey);
		for(int i=0; i< mapsEl.getLength(); i++) {
			if(!(mapsEl.item(i) instanceof Element))
				continue;
			Element mapEl = (Element)mapsEl.item(i);
			if(!"map".equals(mapEl.getTagName()))
				continue;
			parseMap(mapEl, resMap);
		}
	}
	
	private void parseMap(Element mapEl, CommData resMap) {
		String code = mapEl.getAttribute("code");
		String message = mapEl.getTextContent();
		try {
			resMap.put(code, message);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
}
