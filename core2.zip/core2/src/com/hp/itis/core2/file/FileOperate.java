package com.hp.itis.core2.file;

import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class FileOperate {
	private FileOperate() {
	}

	public static boolean delete(File dir) {
		if (dir.isDirectory()) {
			File[] listFiles = dir.listFiles();
			for (int i = 0; null != listFiles && i < listFiles.length && delete(listFiles[i]); i++) {
			}
			;
		}
		return dir.delete();
	}

	public static boolean delete(String dir) {
		return delete(new File(dir));
	}

	public static boolean clearDir(File dir) {
		if (dir.isDirectory()) {
			File[] listFiles = dir.listFiles();
			for (int i = 0; i < listFiles.length && clearDir(listFiles[i]); i++) {
			}
			;
		}
		return dir.list().length == 0;
	}

	public static boolean clearDir(String dir) {
		return clearDir(new File(dir));
	}

	public static long copyStream(InputStream is, OutputStream os) {
		try {
			int bytesum = 0;
			int byteread = 0;
			byte[] buffer = new byte[4096];
			while ((byteread = is.read(buffer)) != -1) {
				bytesum += byteread;
				os.write(buffer, 0, byteread);
			}
			return bytesum;
		} catch (Exception e) {
			return -1;
		} finally {
			try {
				os.flush();
				os.close();
			} catch (Exception e) {
			}
			try {
				is.close();
			} catch (Exception e) {
			}
		}

	}

	/**
	 * 复制单个文件
	 * 
	 * @param target
	 * @param target
	 * @return boolean
	 */
	public static boolean copyFile(File source, File target) {
		try {
			if (target.exists()) {
				InputStream is = new FileInputStream(source);
				OutputStream os = new FileOutputStream(target);
				return copyStream(is, os) >= 0;
			}
		} catch (Exception e) {
		}
		return false;
	}

	public static boolean copyFile(String source, String target) {
		return copyFile(new File(source), new File(target));
	}

	public static boolean copy(File source, File target) {
		if (source.isDirectory()) {
			target.mkdir();
			File[] files = source.listFiles();
			for (int i = 0; i < files.length; i++) {
				if (!copy(files[i], new File(target.getPath() + File.separator
						+ source.getName())))
					return false;
			}
			;
			return true;
		} else
			return copyFile(source, target);
	}

	public static boolean copy(String source, String target) {
		return copy(new File(source), new File(target));
	}

	/**
	 * 移动文件到指定目录
	 * 
	 * @param source
	 * @param target
	 */
	public static boolean move(File source, File target) {
		if (!source.renameTo(target)) {
			if (!copy(source, target))
				return false;
			if (!delete(source))
				return false;
		}
		return true;
	}

	/**
	 * 移动文件到指定目录
	 * 
	 * @param source
	 * @param target
	 */
	public static boolean move(String source, String target) {
		return move(new File(source), new File(target));
	}

	/**
	 * 将文件或文件夹压缩成zip文件
	 * 
	 * @param source
	 * @param target
	 * @throws Exception
	 */
	public static synchronized void zip(File source, File target)
			throws Exception {
		ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(target));
		zip(zos, source, "");
		zos.close();
	}

	public static synchronized void zip(String source, String target)
			throws Exception {
		zip(new File(source), new File(target));
	}

	private static synchronized void zip(ZipOutputStream zos, File file,
			String base) throws Exception {
		if (file.isDirectory()) {
			File[] files = file.listFiles();
			zos.putNextEntry(new ZipEntry(base + "/"));
			base = base.length() == 0 ? "" : base + "/";
			for (int i = 0; i < files.length; i++) {
				zip(zos, files[i], base + files[i].getName());
			}
		} else {
			zos.putNextEntry(new ZipEntry(base));
			FileInputStream in = new FileInputStream(file);
			int b;
			while ((b = in.read()) != -1) {
				zos.write(b);
			}
			in.close();
		}
	}
}
