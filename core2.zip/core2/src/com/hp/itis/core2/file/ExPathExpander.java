package com.hp.itis.core2.file;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hp.itis.core2.misc.StrUtil;

/**
 * A class used to enumerate all file names those match specific path pattern (exPath)
 * 
 * @author changjiang
 *
 */
		
public class ExPathExpander {

	/**
	 * The private function that only use by fatchFileNames
	 * 
	 * @param dir The base directory  
	 * @param regex Pattern object
	 * @param recursive The recursive call flag
	 * @param fileNames A pre-created list to store filenames
	 * @return
	 * @throws IOException
	 */
	private static int listDir(String dir, Pattern pattern, boolean recursive,
			ArrayList<String> fileNames) throws IOException {
		int result = 0;
		File file = new File(dir);
		File fileList[];
		if (!file.isDirectory()) {
			result = -1;
		} else {
			fileList = file.listFiles();
			if(null != fileList)
				for (int i = 0; i < fileList.length; i++) {
					if (recursive && fileList[i].isDirectory()) {
						listDir(fileList[i].getPath(), pattern, recursive, fileNames);
					} else {
						Matcher matcher = pattern.matcher(fileList[i].getName());
						if (matcher.find())
							fileNames.add(fileList[i].getPath());
					}
				}
		}
		return result;
	}
	
	/**
	 * description: enumerate all file names those match specific path pattern
	 * 
	 * @param exPath
	 * pattern format: /path/filepattern 
	 * if filepattern start with a "/" or "\" then the pattern will aplly recursivly to all file below path and its sub directories
	 * 
	 * example1: /path1/*.xml  --  enumerate all file with extension name ".xml"
	 * example2: /path1//*.xml  --  enumerate all file with extension name ".xml" below path1 and all its sub directories
	 * 
	 * @return filename list which matchs exPath 
	 */
	
	public static List<String> expand(String exPath) {
		ArrayList<String> fileNames =  new ArrayList<String>();
		String exFileName;
		//get the last separator and filename pattern part
		Pattern pathPattern = Pattern.compile("^(.*[^\\\\/])([\\\\/]{1,2})(.+?)$");
		Matcher pathMatcher = pathPattern.matcher(exPath);
		if(pathMatcher.find())
		{
			//if the last path separator is "//" or "\\", then list files recursivly
			boolean recursive = pathMatcher.group(2).length() > 1;
			exFileName = pathMatcher.group(3);
			//replace all special charactors for regex
			exFileName = StrUtil.neToRe(exFileName);
			Pattern filePattern = Pattern.compile(exFileName);
			try {
				//bug fixed here for recognizing the root path of windows or unix
				String baseDir = pathMatcher.group(1);
				if(baseDir.length()==0)
					baseDir = "/";
				else if(baseDir.length()==2 && baseDir.endsWith(":"))
					baseDir += "\\"; 			
				
				listDir(baseDir, filePattern, recursive, fileNames);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		else {
			File f = new File(exPath);
			if(f.exists())
				fileNames.add(f.getPath());
		}
		return fileNames;
	}
	
}
