package com.hp.itis.core2.file;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * 文件追加器
 * @author changjiang
 *
 */
public class FileAppender {

	/** 	最大缓存日志条数 */
	private int cacheCount;
	/** 	日志缓存过期时间 */
	private long cacheExpire;
	/** 	已缓存日志条数 */
	private int cached = 0;  
	/** 	上次刷新缓存时间 */
	private long lastPurgeTime;
	/** 	Throwable */
	private Throwable lastError = null;
	/** 	字符集 */
	private String charset;

	private Map<String, List<String>> cache = new LinkedHashMap<String, List<String>>();
	
	/**
	 * 
	 * @param cacheCount  最大缓存日志条数
	 * @param cacheExpire  日志缓存过期时间
	 * @param charset  字符集
	 */
	public FileAppender(int cacheCount, long cacheExpire, String charset) {
		this.cacheCount = cacheCount;
		this.cacheExpire = cacheExpire;
		if("".equals(charset))
			charset = null;
		this.charset = charset;
		lastPurgeTime = System.currentTimeMillis();
	}
	/**
	 * 添加字符串内容
	 * @param fileName 日志文件名 
	 * @param content  一行日志
	 */
	public void append(String fileName, String content) {
		List<String> target = cache.get(fileName);
		if(null == target) {
			target = new ArrayList<String>();
			cache.put(fileName, target);
		}
		target.add(content);
		cached++;
		tryPurge();
	}
	
	/**
	 * 如果达到缓存写入条件，则清空缓存并写入磁盘
	 */
	public void tryPurge() {
		if(cached>=cacheCount)
			purge();
		else if(lastPurgeTime+cacheExpire < System.currentTimeMillis())
			purge();
	}
	
	/**
	 * 清空缓存并写入磁盘
	 */
	public synchronized void purge() {
		for(Entry<String, List<String>> pair : cache.entrySet()) {
			File file = new File(pair.getKey());
			if(!file.exists())
				file.getParentFile().mkdirs();//创建父目录结构
			OutputStream os = null;
			try {
				os = new FileOutputStream(pair.getKey(), true);
				List<String> target = pair.getValue();
				for(int i=0; i<target.size(); i++) {
					if(null == charset)
						os.write(target.get(i).getBytes());
					else
						os.write(target.get(i).getBytes(charset));
				}
			} catch (Exception e) {
				lastError = e;
			}
			finally {
				if(null != os)
					try {
						os.close();
					} catch (IOException e) {
					}
			}	
		}
		cache.clear();
		cached = 0;
		lastPurgeTime = System.currentTimeMillis();
	}
	

	
	/**
	 * @return
	 */
	public Throwable lastError() {
		return lastError;
	}

	/**
	 * 
	 */
	public void clearError() {
		lastError = null;
	}
}
