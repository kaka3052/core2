package com.hp.itis.core2.file;

import java.net.MalformedURLException;
import java.net.URLClassLoader;
import java.net.URL;
import java.util.List;
import java.io.File;
import java.io.IOException;


 

public class JarsClassLoader extends URLClassLoader{
	
	public JarsClassLoader() {
		super(new URL[0], Thread.currentThread().getContextClassLoader());
	}
	
	public JarsClassLoader(String pathExpr) {
		this();
		addPath(pathExpr);
	}

	public void addPath(String pathExpr)
	{
		if(null == pathExpr)
			return;
		List<String> paths = ExPathExpander.expand(pathExpr);
		for(String path: paths)
		{
			try {
				super.addURL(new File(path).getCanonicalFile().toURI().toURL());
			} catch (MalformedURLException e) {
			} catch (IOException e) {
			}
		}
	}
}


