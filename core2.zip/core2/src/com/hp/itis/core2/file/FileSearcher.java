package com.hp.itis.core2.file;

import java.io.File;
import java.io.FileFilter;

public class FileSearcher {
	
	/**
	 * search files by given ant-liked path pattern, result will be handled
	 * by the call-back receiver's accept method, if need break to search 
	 * accept can return a false value.
	 * @param pattern
	 * @param receiver
	 */
	public void search(String pattern, FileFilter receiver) {
		
	}
	
	/**
	 * search and return all files that matches given ant-liked path pattern.
	 * @param pattern
	 * @return
	 */
	public File[] search(String pattern) {
		return null;
	}
}
