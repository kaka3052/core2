package com.hp.itis.core2.file;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URL;
import java.nio.CharBuffer;

public class TextFile {

	public static String load(String filename) {
		return load(new File(filename));
	}

	public static String load(String filename, String charset) {
		return load(new File(filename), charset);
	}

	public static String load(File file) {
		return load(file, null);
	}

	public static String load(File file, String charset) {
		FileInputStream fis = null;
		String r = null;
		try {
			fis = new FileInputStream(file);
			r = load(fis, charset);
		} catch (Exception e) {

		} finally {
			try {
				if (fis != null) {
					fis.close();
				}
			} catch (Exception e) {
			}
		}
		return r;
	}
	
	public static void save(String filename, String text) throws Exception {
		save(filename, text, null);
	}
	
	public static void save(File file, String text) throws Exception {
		save(file, text, null);
	}
	
	public static void save(String filename, String text, String charset) throws Exception {
		save(new File(filename), text, charset);
	}

	public static void save(File file, String text, String charset) throws Exception {
		InputStream is;
		if(null == charset)
			is = new ByteArrayInputStream(text.getBytes());
		else
			is = new ByteArrayInputStream(text.getBytes(charset));
		save(file, is);
	}

	public static void save(String filename, InputStream is) throws Exception {
		save(new File(filename), is);
	}

	public static void save(File file, InputStream is) throws Exception {
		save(new FileOutputStream(file), is);
	}
	
	public static void save(OutputStream os, InputStream is) throws Exception {
		copyStream(is, os);
	}
	
	public static long copyStream(InputStream is, OutputStream os) throws Exception {
		try {
			int bytesum = 0;
			int byteread = 0;
			byte[] buffer = new byte[4096];
			while ((byteread = is.read(buffer)) != -1) {
				bytesum += byteread;
				os.write(buffer, 0, byteread);
			}
			return bytesum;
		} 
		finally {
			try {
				os.flush();
				os.close();
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
			try {
				is.close();
			} catch (Exception e) {
			}
		}

	}

	/**
	 * 读取InputStream到String
	 * 
	 * @param is
	 * @return
	 */
	public static String load(InputStream is, String charSet) {
		BufferedReader in;
		try {
			if (null == charSet)
				in = new BufferedReader(new InputStreamReader(is));
			else
				in = new BufferedReader(new InputStreamReader(is, charSet));
		} catch (UnsupportedEncodingException e1) {
			return null;
		}
		CharBuffer cb = CharBuffer.allocate(100);
		StringBuffer buffer = new StringBuffer();

		try {
			int r = 0;
			while ((r = in.read(cb)) >= 0) {
				cb.limit(r);
				cb.rewind();
				buffer.append(cb);
			}
		} catch (IOException e) {
			return null;
		}
		return buffer.toString();
	}

	public static String load(InputStream is) {
		return load(is, null);
	}
	
	public static URL getURL(String resName) {
		if(null == resName)
			return null;
		URL url = Thread.currentThread().getContextClassLoader().getResource(resName);
		if(null != url)
			return url;
		File file = new File(resName);
		if(file.exists()) {
			try {
				url = file.toURI().toURL();
			} catch (Throwable e) {
			}
		}
		if(null != url)
			return url;
		URI uri = URI.create(resName);
		try {
			url = uri.toURL();
		} catch (Throwable e) {
		}
		return url;
	}

	/**
	 * 
	 */
	public static InputStream getResource(String resName) {
		URL url = getURL(resName);
		if(null == url)
			return null;
		try {
			return url.openStream();
		} catch (IOException e) {
			return null;
		}
	}

	public static String loadResource(String resName) {
		return loadResource(resName, null);
	}

	public static boolean resExists(String resName) {
		return null != getURL(resName);
	}

	public static String loadResource(String resName, String charset) {
		InputStream is = getResource(resName);
		if (null == is)
			return null;
		try {
			return load(is, charset);
		} finally {
			try {
				if (null != is)
					is.close();
			} catch (IOException e) {
			}
		}
	}
}
