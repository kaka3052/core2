package com.hp.itis.core2.procengine.triggers;

public class DefaultTrigger extends ActiveTrigger {

	@Override
	protected void setup() {
		
	}

}
