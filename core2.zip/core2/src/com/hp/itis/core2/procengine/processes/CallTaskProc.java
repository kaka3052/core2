package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.procengine.ProcEngine;

public class CallTaskProc extends DataProcess {

	private String taskName;
	
	@Override
	public boolean execute() throws Exception {
		return ProcEngine.instance().callTask(params, taskName);
	}

	@Override
	protected void setup() throws Exception {

	}

	public void setTask(String taskName) {
		this.taskName = taskName;
	}
	
}
