package com.hp.itis.core2.procengine.module;

public interface IJobContainer extends Iterable<IJob> {

	IJob getJob(String jobId);
	void remove(IJob job);
	void remove(String jobId);
	void update(IJob job);
	void clear();
	void reload();
	void init();
	
}
