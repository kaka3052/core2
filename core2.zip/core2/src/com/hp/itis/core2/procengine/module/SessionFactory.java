package com.hp.itis.core2.procengine.module;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Stack;

import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.procengine.task.ISession;
import com.hp.itis.core2.procengine.task.Session;

public class SessionFactory extends Module {
	
	private Map<String, ISession> activeSessions = Collections.synchronizedMap(new LinkedHashMap<String, ISession>());
	private ThreadLocal<Stack<ISession>> currentSessions = new ThreadLocal<Stack<ISession>>();
	
	public static final SessionFactory instance = new SessionFactory();
	
	public ISession currentSession() {
		try {
			return currentSessions.get().peek();
		}
		catch(Exception e) {
			return null;
		}
	}
	
	public ISession createSession(IEvent event) {
		ISession session = new Session(event);
		activeSessions.put(session.sessionID(), session);
		setCurrentSession(session);
		return session;
	}
	
	public void freeSession(ISession session) {
		activeSessions.remove(session.sessionID());
		setCurrentSession(null);
		if(activeSessions.size()==0) {
			synchronized(this) {
				this.notifyAll();
			}
		}
	}
	
	protected void setCurrentSession(ISession session) {
		Stack<ISession> stack = currentSessions.get();
		if(null != session) {
			if(null == stack) {
				stack = new Stack<ISession>();
				currentSessions.set(stack);
			}
			stack.push(session);
		}
		else {
			if(null != stack) {
				stack.pop();
				if(stack.size()==0)
					currentSessions.set(null);
			}
		}
	}
	
	public Collection<ISession> activeSessions() {
		return activeSessions.values();
	}
	
	public ISession getSessionById(String id) {
		return activeSessions.get(id);
	}
	
	public synchronized void waitAll() {
		while(activeSessions.size()>0) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				break;
			}
		}
	}
	
}
