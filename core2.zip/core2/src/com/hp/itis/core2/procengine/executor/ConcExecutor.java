package com.hp.itis.core2.procengine.executor;

import java.util.concurrent.Semaphore;

import com.hp.itis.core2.event.Event;
import com.hp.itis.core2.procengine.module.ControllableModule;
import com.hp.itis.core2.procengine.module.Module;
import com.hp.itis.core2.task.OneTimeTask;
/**
 * 并发执行器类
 * @author changjiang
 *
 */
public class ConcExecutor extends ControllableModule implements IExecutor {
	
	/**并发度*/
	private Semaphore concurrency;
	private IExecutable exec;
	private int maxConc;
	
	/**
	 * 并发线程工作类
	 */
	public class ConcWorker extends OneTimeTask {
		private Object task;
		private IExecutable exec;
		
		public ConcWorker(Object task, IExecutable exec)
		{
			this.exec = exec;
			this.task = task;
		}
		
		public String name() {
			String name;
			if(exec instanceof Module)
				name = super.name() + "." + ((Module)exec).name();
			else
				name = super.name();
			return task + "#" + name;
		}
		
		public void run()
		{
			try	{
				exec.execute(task);
			}
			catch(Throwable e)
			{
				dispatch(new Event(EXEC_ERROR, task, e));
			}
			finally
			{
				dispatch(new Event(EXEC_DONE, task, null));
				concurrency.release();
			}
		}
	}
	
	public ConcExecutor(IExecutable exec, int maxConc)
	{
		this.maxConc = maxConc;
		concurrency = new Semaphore(maxConc);
		this.exec = exec;
	}
	
	public void execute(Object task) {
		try {
			concurrency.acquire();
			log().debug(20001, maxConc - concurrency.availablePermits()-1, concurrency.getQueueLength());
			new ConcWorker(task, exec).execute();
		} catch (InterruptedException e) {
		}
	}
	
	public String name() {
		if(exec instanceof Module)
			return ((Module)exec).name();
		else
			return super.name();
	}

	@Override
	protected void activate() {
		
	}

	@Override
	protected void deactivate() {

	}

	@Override
	public void setExecutable(IExecutable exec) {
		this.exec = exec;
	}

}
