package com.hp.itis.core2.procengine.task;


public interface ITaskProfile {
	void taskBegin(ISession session, ITask task);
	void taskEnd(ISession session, ITask task);
	void procBegin(ISession session, IProcess process);
	void procEnd(ISession session, IProcess process);
	void procError(ISession session, IProcess process, Throwable e);
}
