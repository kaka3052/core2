package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.misc.StrUtil;
import com.hp.itis.core2.procengine.ProcEngine;

public class DemandProc extends DataProcess {

	private String target;
	private long timeout = 0;
	
	@Override
	protected boolean execute() throws Exception {
		Object v = value();
		if(null == v)
			v = session().event();
		Object result = ProcEngine.instance().demand(v, target, timeout);
		value(result);
		return true;
	}

	@Override
	protected void setup() throws Exception {
	}
	
	public void setEvent(String v) {
		this.target = v;
	}
	
	public void setTimeout(String timeout) {
		this.timeout = StrUtil.str2Millisec(timeout);
	}

}
