package com.hp.itis.core2.procengine.module;

import com.hp.itis.core2.procengine.exception.ModuleException;


public abstract class ControllableModule extends Module implements
		IControllableModule {
	
	protected ModuleState state = ModuleState.INIT;
	private boolean enable = true;

	@Override
	public boolean isActive() {
		return state == ModuleState.RUNNING;
	}
	
	@Override
	public void setActive(boolean value) throws ModuleException {
		if(!enable)
			return;
		if(value) {
			if(state == ModuleState.RUNNING || state == ModuleState.STARTING)
				return;
			if(state == ModuleState.STOPPING)
				throw new ModuleException(this, 1001);
			state = ModuleState.STARTING;
			activate();
			state = ModuleState.RUNNING;
			log().debug(2001, name());
		}
		else {
			if(state == ModuleState.STOPPED || state == ModuleState.STOPPING || state == ModuleState.INIT)
				return;
			if(state == ModuleState.STARTING)
				throw new ModuleException(this, 1002);
			state = ModuleState.STOPPING;
			deactivate();
			state = ModuleState.STOPPED;
			log().debug(2002, name());
		}
	}
	
	@Override
	public ModuleState moduleState() {
		return state;
	}
	
	@Override
	public void reload() throws ModuleException {
		setActive(false);
		Thread.yield();
		setActive(true);
	}
	
	public void setEnable(boolean v) {
		enable = v;
	}
	
	public boolean isEnable() {
		return enable;
	}
	
	abstract protected void activate() throws ModuleException;

	abstract protected void deactivate() throws ModuleException;


}
