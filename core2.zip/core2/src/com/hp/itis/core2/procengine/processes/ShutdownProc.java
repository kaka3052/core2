package com.hp.itis.core2.procengine.processes;


public class ShutdownProc extends DataProcess {
	@Override
	protected void setup() throws Exception {
		
	}

	@Override
	public boolean execute() throws Exception {
		new Thread(new Runnable() {
			@Override
			public void run() {
				System.exit(0);
			}
		}).start();
		return true;
	}

}
