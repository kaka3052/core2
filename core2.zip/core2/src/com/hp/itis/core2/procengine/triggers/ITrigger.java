package com.hp.itis.core2.procengine.triggers;

import com.hp.itis.core2.procengine.IEventProducer;
import com.hp.itis.core2.procengine.module.IControllableModule;

public interface ITrigger extends IEventProducer, IControllableModule {
}
