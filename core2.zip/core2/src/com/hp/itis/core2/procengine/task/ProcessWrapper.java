package com.hp.itis.core2.procengine.task;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.FieldMap;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.module.Module;

public class ProcessWrapper extends Module implements IProcess {
	
	/**激活模式，总是激活*/
	public final static int IM_ALWAYS = 0;
	/**激活模式，当成功时激活*/
	public final static int IM_ON_SUCCESS = 1;
	/**激活模式，当失败时激活*/
	public final static int IM_ON_FAIL = 2;
	/**激活模式，上一步完成不检查成功与否*/
	public final static int IM_CONTINUE = 3;
	
	private boolean newInstance = false;
	private boolean lazyInit = true;
	private Class<?> pClass;
	private IProcess process;
	private CommData params;
	private int invokeMode = IM_ON_SUCCESS;
	private boolean passing = false;

	@Override
	public boolean execute(ISession session) throws Exception {
		try {
			IProcess p = getProcess(session);
			return p.execute(session);
		}
		catch(Throwable e) {
			session.log().debug(e);
			session.report(e);
			return false;
		}
	}

	@Override
	public void init(CommData params) throws Exception {
		this.params = params;
		if(null == pClass)
			throw new RuntimeException("Cann't instantize process class: " + params.getString("class"));
		if(!lazyInit)
			getProcess(null);
	}
	
	private IProcess getProcess(ISession session) throws Exception {
		if(!newInstance && null != process)
			return process;
		if(null != process)
			process.destroy();
		CommData params = this.params;
		if(null == session)
			params = ProcEngine.instance().updateParams(params);
		else {
			params = ProcEngine.instance().updateParams(params, session.vars());
		}
		process = (IProcess)ProcEngine.instance().createObject(pClass, params);
		return process;
	}
	
	public void setNewInstance(boolean v) {
		newInstance = v;
	}
	
	public void setLazyInit(boolean v) {
		lazyInit = v;
	}
	
	public void setClass(String className) throws ClassNotFoundException {
		pClass = ProcEngine.instance().getClass(className);
	}
	
	@FieldMap("invoke")
	public void setInvokeMode(String value) {
		if("always".equalsIgnoreCase(value))
			invokeMode = IM_ALWAYS;
		else if("on_fail".equalsIgnoreCase(value))
			invokeMode = IM_ON_FAIL;
		else if("continue".equalsIgnoreCase(value))
			invokeMode = IM_CONTINUE;
		else
			invokeMode = IM_ON_SUCCESS;
	}
	
	public int invokeMode() {
		return invokeMode;
	}
	
	public void setPassing(boolean v) {
		passing = v;
	}
	
	
	public boolean passing() {
		return passing;
	}
	
	public String name() {
		String name = pClass.getSimpleName();
		if(name.endsWith("Proc"))
			name = name.substring(0, name.length()-4);
		return name;
	}

	@Override
	public void destroy() {
		if(null != process)
			process.destroy();
	}

}
