package com.hp.itis.core2.procengine.processes;

import java.util.regex.Pattern;

public class HttpTestProc extends HttpGetProc {

	private Pattern successPattern;
	private Pattern failPattern;
	
	public HttpTestProc() {
		resultKey = "_HTTP_CONTENT";
	}
	
	@Override
	protected boolean execute() throws Exception {
		try {
			boolean r = super.execute();
			if(!r)
				return false;
			String result = session().values().getString(resultKey);
			if(null == result)
				return false;
			if(null != successPattern) {
				r = successPattern.matcher(result).find();
				if(!r)
					return false;
			}
			if(null != successPattern) {
				r = !failPattern.matcher(result).find();
			}
			return r;
		}
		finally {
			session().values().put(resultKey, null);
		}
	}
	
	public void setSuccessPattern(String v) {
		successPattern = Pattern.compile(v);
	}
	
	public void setFailPattern(String v) {
		failPattern = Pattern.compile(v);
	}
	
}
