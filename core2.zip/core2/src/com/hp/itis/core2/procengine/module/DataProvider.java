package com.hp.itis.core2.procengine.module;

public class DataProvider implements IDataProvider {

	private IDataReceiver receiver;
	
	public IDataReceiver getReceiver() {
		return receiver;
	}

	@Override
	public void setReceiver(IDataReceiver receiver) {
		this.receiver = receiver;
	}
	
	public void provide(Object data) {
		if(null != receiver)
			receiver.onData(data);
	}

}
