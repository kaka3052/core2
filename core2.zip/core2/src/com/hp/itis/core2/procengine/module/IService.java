package com.hp.itis.core2.procengine.module;


public interface IService extends IControllableModule {
	void start() throws Exception;
	void stop() throws Exception;
}
