package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.mail.MailMessage;
import com.hp.itis.core2.mail.MailParams;
import com.hp.itis.core2.mail.MailSender;
import com.hp.itis.core2.vars.AutomaticVars;
import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.CommDataVars;
import com.hp.itis.core2.vars.IVars;


public class MailSendProc extends DataProcess {

	private MailSender mailSender = new MailSender();
	
	@Override
	protected boolean execute() throws Exception {
		MailParams mailParams = new MailParams();
		IVars vars = new CombinedVars(session().vars(), new CommDataVars(params));
		AutomaticVars paramVars = new AutomaticVars(mailParams);
		paramVars.put(vars);
		try {
			mailSender.sendMail(mailParams);
		}
		finally {
			if(value() instanceof MailMessage) {
				((MailMessage)value()).setTtl(mailParams.getTtl());
			}
		}
		return true;
	}

	@Override
	protected void setup() throws Exception {
		
	}
 
}
