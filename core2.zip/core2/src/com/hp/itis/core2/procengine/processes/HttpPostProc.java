package com.hp.itis.core2.procengine.processes;

public class HttpPostProc extends HttpGetProc {

	public HttpPostProc() {
		setMethod("POST");
	}
}
