package com.hp.itis.core2.procengine.executor;

import com.hp.itis.core2.event.Event;
import com.hp.itis.core2.procengine.module.ControllableModule;
import com.hp.itis.core2.procengine.module.Module;

/**
 * 
 * 同步执行器
 * @author changjiang
 *
 */

public class SyncExecutor extends ControllableModule implements IExecutor {

	private IExecutable exec;
	
	public SyncExecutor(IExecutable exec)
	{
		this.exec = exec;
	}

	public String name() {
		if(exec instanceof Module)
			return ((Module)exec).name();
		else
			return super.name();
	}
	
	@Override
	public void execute(Object task) {
		try
		{
			exec.execute(task);
		}
		catch(Exception e)
		{
			dispatch(new Event(EXEC_ERROR, task, e));
		}
		dispatch(new Event(EXEC_DONE, task, null));
	}

	@Override
	protected void activate() {

	}

	@Override
	protected void deactivate() {

	}

	@Override
	public void setExecutable(IExecutable exec) {
		this.exec = exec;
	}



}
