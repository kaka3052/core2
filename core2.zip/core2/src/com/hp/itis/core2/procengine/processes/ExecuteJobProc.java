package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.procengine.module.IJob;

public class ExecuteJobProc extends DataProcess {

	@Override
	protected boolean execute() throws Exception {
		IJob job = (IJob)value();
		value(job.execute());
		return true;
	}

	@Override
	protected void setup() throws Exception {
		
	}

}
