package com.hp.itis.core2.procengine;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventCondition;
import com.hp.itis.core2.event.IEventDemander;
import com.hp.itis.core2.misc.CodeMapper;
import com.hp.itis.core2.procengine.bean.IBeanFactory;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.module.ControllableModule;
import com.hp.itis.core2.procengine.module.EngineContext;
import com.hp.itis.core2.procengine.module.EventBus;
import com.hp.itis.core2.procengine.module.IConfigProvider;
import com.hp.itis.core2.procengine.module.IEngineContext;
import com.hp.itis.core2.procengine.module.IService;
import com.hp.itis.core2.procengine.module.SessionFactory;
import com.hp.itis.core2.procengine.task.ISession;
import com.hp.itis.core2.procengine.task.ITask;
import com.hp.itis.core2.procengine.task.Session;
import com.hp.itis.core2.task.ThreadPoolService;
import com.hp.itis.core2.vars.IVars;

public class ProcEngine extends ControllableModule implements IEngineContext {
	
	public static final String DEF_CONFIG_NAME = "core.xml";
	private boolean defineLoaded = false;
	private boolean reloading = false;
	private EngineContext context;
	private EventBus eventBus;
	
	private static ProcEngine instance = null;
	
	private ProcEngine() {
		CodeMapper.instance().addResource(this.getClass());
		context = new EngineContext();
	}
	
	public EngineContext context() {
		return context;
	}
	
	public static synchronized ProcEngine instance() {
		if(null == instance)
			instance = new ProcEngine();
		return instance;
	}
	
	public void loadDefination() throws ModuleException {
		loadDefination(null, null);
	}
	
	public void loadDefination(String path) throws ModuleException {
		loadDefination(path, null);
	}
	
	public void loadDefination(IVars vars) throws ModuleException {
		loadDefination(null, null);
	}
	
	public void loadDefination(String path, IVars vars) throws ModuleException {
		try {
			if(null == path)
				path = DEF_CONFIG_NAME;
			IConfigProvider conf = new ConfigLoader(path, vars);
			if(vars != null)
				addVars(vars);
			context.loadConfig(conf);
			defineLoaded = true;
		}
		catch(Throwable e){
			log().error(e, e);
			throw new ModuleException(this, e);
		}
	}
	
	public IEventDemander eventBus() {
		return eventBus;
	}
	
	@SuppressWarnings("unchecked")
	protected void init() throws Exception {
		CodeMapper.instance().setLang(context.get("core.lang", "en_US"));
		ThreadPoolService.getInstance().setCorePoolSize(context.get("threadPool.coreSize", 0));
		ThreadPoolService.getInstance().setKeepAliveSeconds(context.get("threadPool.keepAlive", 5));
		ThreadPoolService.getInstance().setMaxPoolSize(context.get("threadPool.maxSize", 100));
		eventBus = new EventBus(context.get("core.queueSize", -1));
		Collection<IEventConsumer> consumers = (Collection<IEventConsumer>)context.getBeans(IEventConsumer.class);
		for(IEventConsumer consumer : consumers) {
			for(String event: consumer.events())
				eventBus.addListener(event, consumer);
		}
		Collection<IEventProducer> procucers = (Collection<IEventProducer>)context.getBeans(IEventProducer.class);
		for(IEventProducer procucer : procucers) {
			procucer.setEventTarget(eventBus);
		}
	}
	
	public void start() throws ModuleException {
		if(!defineLoaded) {
			throw new ModuleException(this, 10001);
		}
		try {
			init();
		} catch (Exception e1) {
			throw new ModuleException(this, e1);
		}
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				try {
					setActive(false);
				} catch (Throwable e) {
					log().error(e, e);
				}
			}
		});
		setActive(true);
	}
	
	public void stop() {
		new Thread( new Runnable() {
			@Override
			public void run() {
				try {
					setActive(false);
				} catch (Throwable e) {
					log().error(e, e);
				}
			}
			}
		).start();
	}
	
	private void _reload() throws ModuleException {
		super.reload();
		synchronized(this)
		{
			reloading = false;
			this.notifyAll();
		}
	}
	
	public void reload() {
		reloading = true;
		new Thread( new Runnable() {
			@Override
				public void run() {
					try {
						_reload();
					} catch (ModuleException e) {
						log().error(e);
					}
				}
			}
		).start();
	}
	
	public void awaitStop() throws InterruptedException {
		synchronized(this)
		{
			while(moduleState() != ModuleState.STOPPED)
				this.wait(3000);
		}
	}
	
	public void awaitReload() throws InterruptedException {
		synchronized(this)
		{
			while(moduleState() != ModuleState.RUNNING || reloading)
				this.wait(3000);
		}
	}
	
	public ISession currentSession() {
		return SessionFactory.instance.currentSession();
	}
	
	public boolean callTask(String taskName) throws Exception {
		ISession session = currentSession();
		if(null != session)
			return callTask(session.values(), taskName);
		return callTask(null, taskName);
	}
	
	public boolean callTask(Object data, String taskName) throws Exception {
		Object o = context.getBean(taskName);
		if(null == o)
			return false;
		ITask task;
		if (o instanceof ITask)
			task = (ITask)o;
		else
			return false;
		ISession session = new Session(data);
		return task.execute(session);
	}
	
	public void dispatch(IEvent event) {
		eventBus.dispatch(event);
	}
	
	public IEvent dispatch(Object data, String target) {
		return eventBus.dispatch(data, target);
	}
	
	public IEvent dispatch(Object data) {
		return eventBus.dispatch(data);
	}
	
	public IEvent dispatch(Object data, String target, long delay) {
		return eventBus.dispatch(data, target, delay);
	}
	
	public IEvent dispatch(Object data, long delay) {
		return eventBus.dispatch(data, delay);
	}
	
	public IEvent waitEvent(IEventCondition condition, long timeout) throws InterruptedException {
		return eventBus.waitEvent(condition, timeout);
	}
	
	public IEvent demand(IEvent event, long timeout) throws InterruptedException {
		return eventBus.demand(event, timeout);
	}
	
	public Object demand(Object data, String target, long timeout) throws InterruptedException {
		return eventBus.demand(data, target, timeout);
	}
	
	public Object demand(Object data, long timeout) throws InterruptedException {
		return eventBus.demand(data, timeout);
	}
	
	public void supply(IEvent event, Object result) {
		eventBus.supply(event, result);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	protected void activate() throws ModuleException {
		//activate services
		Collection<IService> services = (Collection<IService>)reverseSet(context.getBeans(IService.class));
		for(IService service : services) {
			try {
				service.setActive(true);
			} catch (ModuleException e) {
				log().error(e, e);
			}
		}
		
		//activate consumers
		Collection<IEventConsumer> consumers = (Collection<IEventConsumer>)context.getBeans(IEventConsumer.class);
		for(IEventConsumer consumer : consumers) {
			try {
				consumer.setActive(true);
			} catch (ModuleException e) {
				log().error(e, e);
			}
		}
		//activate event bus
		eventBus.setActive(true);
		//activate producers
		Collection<IEventProducer> producers = (Collection<IEventProducer>)context.getBeans(IEventProducer.class);
		for(IEventProducer producer : producers) {
			try {
				producer.setActive(true);
			} catch (ModuleException e) {
				log().error(e, e);
			}
		}
		
		synchronized(this) {
			this.notifyAll();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void deactivate() {
		//deactivate producers
		Collection<IEventProducer> producers = (Collection<IEventProducer>)reverseSet(context.getBeans(IEventProducer.class));
		for(IEventProducer producer : producers) {
			if(!(producer instanceof IEventConsumer)) {
				try {
					producer.setActive(false);
				} catch (ModuleException e) {
					log().error(e, e);
				}
			}
		}
		//wait all session to finish
		SessionFactory.instance.waitAll();
		//deactivate event bus
		try {
			eventBus.setActive(false);
		} catch (ModuleException e) {
			log().error(e, e);
		}
		//deactivate consumers
		Collection<IEventConsumer> consumers = (Collection<IEventConsumer>)reverseSet(context.getBeans(IEventConsumer.class));
		for(IEventConsumer consumer : consumers) {
			try {
				consumer.setActive(false);
			} catch (ModuleException e) {
				log().error(e, e);
			}
		}
		
		//dactivate services
		Collection<IService> services = (Collection<IService>)reverseSet(context.getBeans(IService.class));
		for(IService service : services) {
			try {
				service.setActive(false);
			} catch (ModuleException e) {
				log().error(e, e);
			}
		}
		
		synchronized(this) {
			this.notifyAll();
		}
	}
	
	private Collection<?> reverseSet(Collection<?> set) {
		List<Object> list = new LinkedList<Object>();
		for(Object o : set)
			list.add(0, o);
		return list;
	}

	public void addVars(IVars vars) {
		context.addVars(vars);
	}

	public Object createObject(Class<?> c, CommData params, Object... args) throws Exception {
		return context.createObject(c, params, args);
	}

	public Object createObject(CommData params) throws Exception {
		return context.createObject(params);
	}

	public Object createObject(String className, CommData params, Object... args)
			throws Exception {
		return context.createObject(className, params, args);
	}
	
	@Override
	public Object createObject(Class<?> c, Object... args) throws Exception {
		return context.createObject(c, args);
	}

	@Override
	public Object createObject(String className, Object... args)
			throws Exception {
		return context.createObject(className, args);
	}
	
	@Override
	public void buildObject(Object o, CommData params) throws Exception {
		context.buildObject(o, params);
	}

	public Object eval(String fun, List<Object> params) {
		return context.eval(fun, params);
	}

	public Object get(String key) {
		return context.get(key);
	}

	public Object getBean(String name, Class<?> c) {
		return context.getBean(name, c);
	}

	public Object getBean(String name) {
		return context.getBean(name);
	}

	public IVars getFunVars() {
		return context.getFunVars();
	}

	public Object getBean(Class<?> c) {
		return context.getBean(c);
	}

	public Collection<?> getBeans(Class<?> c) {
		return context.getBeans(c);
	}

	public void put(String key, Object value) {
		context.put(key, value);
	}

	public CommData updateParams(CommData params, IVars vars) {
		return context.updateParams(params, vars);
	}

	public CommData updateParams(CommData params) {
		return context.updateParams(params);
	}


	@Override
	public Class<?> getClass(String className) throws ClassNotFoundException {
		return context.getClass(className);
	}

	@Override
	public void addBeanFactory(IBeanFactory factory) {
		context.addBeanFactory(factory);
	}

	@Override
	public void removeBeanFactory(IBeanFactory factory) {
		context.removeBeanFactory(factory);
	}

	@Override
	public ClassLoader getClassLoader() {
		return context.getClassLoader();
	}

}
