package com.hp.itis.core2.procengine.module;

import com.hp.itis.core2.procengine.exception.ModuleException;

abstract public class Service extends ControllableModule implements IService {

	@Override
	protected void activate() throws ModuleException {
		try {
			start();
		} catch (Exception e) {
			if(e instanceof ModuleException)
				throw (ModuleException)e;
			else
				throw new ModuleException(this, e);
		}
	}

	@Override
	protected void deactivate() throws ModuleException {
		try {
			stop();
		} catch (Exception e) {
			if(e instanceof ModuleException)
				throw (ModuleException)e;
			else
				throw new ModuleException(this, e);
		}
	}

	@Override
	abstract public void start() throws Exception;

	@Override
	abstract public void stop() throws Exception;

}
