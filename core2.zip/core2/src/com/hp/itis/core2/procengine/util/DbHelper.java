package com.hp.itis.core2.procengine.util;

import javax.sql.DataSource;

import com.hp.itis.core2.db.DbOperator;
import com.hp.itis.core2.procengine.ProcEngine;

public class DbHelper extends DbOperator {
	
	private static DbHelper instance = new DbHelper();
	
	public static DbHelper instance() {
		return instance;
	}
	
	protected static DataSource getDataSource() {
		DataSource ds = (DataSource)ProcEngine.instance().getBean(DataSource.class);
		if(null == ds)
			throw new RuntimeException("No DataSource defined in current context.");
		return ds;
	}
	
	public DbHelper() {
		super(getDataSource());
	}
	

}
