package com.hp.itis.core2.procengine.processes;

import java.io.Serializable;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageFormatException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.TextMessage;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.procengine.module.EventBus;

public class JmsSendProc extends DataProcess {

	public enum MessageType {
		event, object, text, map
	};
	
	private ConnectionFactory connFactory;
	private Connection conn;
	private boolean topicMode = true;
	private String destName;
	private Destination dest; 
	private boolean persistent;
	private Session jmsSession;
	private MessageType messageType = MessageType.event;
	private MessageProducer producer;
	protected String eventName;
	protected String content; 
	protected boolean transacted = false;
	protected String acknowledgeMode;
	
	@Override
	public boolean execute() throws Exception {
		Message message = buildMessage();
		producer.send(message);
		return true;
	}
	
	protected Message buildMessage() throws JMSException {
		switch(messageType) {
			case object:	return buildObjectMessage();
			case text:	return buildTextMessage();
			case map:	return buildMapMessage();
			default:	return buildEventMessage();
		}
	}
	
	protected Message buildEventMessage() throws JMSException {
		ObjectMessage message = jmsSession.createObjectMessage();
		Object v = value();
		IEvent event = null;
		if(v == session().event().data() && null == eventName)
			event = session().event();
		else {
			if(null == eventName || "".equals(eventName))
				eventName = session().event().type();
			if(v instanceof IEvent)
				event = (IEvent)v;
			else
				event = EventBus.createEvent(v, eventName, false);
		}
		message.setObject(event);
		return message;
	}
	
	protected Message buildObjectMessage() throws JMSException {
		ObjectMessage message = jmsSession.createObjectMessage();
		message.setObject((Serializable)value());
		return message;
	}
	
	protected Message buildTextMessage() throws JMSException {
		TextMessage message = jmsSession.createTextMessage();
		String content = String.valueOf(value());
		message.setText(content);
		return message;
	}
	
	protected Message buildMapMessage() throws JMSException {
		MapMessage message = jmsSession.createMapMessage();
		CommData cd = session().values();
		for(String key : cd.keySet()) {
			try {
				message.setObject(key, cd.get(key));
			}
			catch(MessageFormatException e){};
		}
		return message;
	}

	@Override
	protected void setup() throws Exception {
		conn = connFactory.createConnection();
		if("client".equalsIgnoreCase(acknowledgeMode))
			jmsSession = conn.createSession(transacted, Session.CLIENT_ACKNOWLEDGE);
		else if("dups".equalsIgnoreCase(acknowledgeMode))
			jmsSession = conn.createSession(transacted, Session.DUPS_OK_ACKNOWLEDGE);
		else
			jmsSession = conn.createSession(transacted, Session.AUTO_ACKNOWLEDGE);
			
		if(null == dest) {
			if(topicMode)
				dest = jmsSession.createTopic(destName);
			else
				dest = jmsSession.createQueue(destName);
		}
		producer = jmsSession.createProducer(dest);
        if (persistent) {
            producer.setDeliveryMode(DeliveryMode.PERSISTENT);
        } else {
            producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
        }
	}
	
	public void setConnFactory(ConnectionFactory connFactory) {
		this.connFactory = connFactory;
	}

	public void setMode(String v) {
		topicMode = "topic".equals(v);
	}
	
	public void setDest(Object v) {
		if(v instanceof String)
			destName = (String)v;
		else if(v instanceof Destination)
			dest = (Destination)v;
	}
	
	public void setEventName(String v) {
		this.eventName = v;
	}
	
	public void setPersistent(boolean v) {
		persistent = v;
	}
	
	public void setAcknowledgeMode(String acknowledgeMode) {
		this.acknowledgeMode = acknowledgeMode;
	}

	public void setTransacted(boolean transacted) {
		this.transacted = transacted;
	}
	
	public void destroy() {
		try {
			producer.close();
		} catch (JMSException e) {}
		try {
			jmsSession.close();
		} catch (JMSException e) {}
	}

	public void setMessageType(String messageType) {
		this.messageType = MessageType.valueOf(messageType);
	}

}
