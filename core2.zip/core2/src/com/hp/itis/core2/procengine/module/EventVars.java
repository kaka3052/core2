package com.hp.itis.core2.procengine.module;

import java.util.List;

import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.vars.AutomaticVars;
import com.hp.itis.core2.vars.IFunVars;
import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.PrefixedVars;

public class EventVars extends PrefixedVars implements IFunVars {

	private IEvent event;
	private IVars dataVars;
	private IVars sourceVars;
	
	public EventVars(IEvent event) {
		setEvent(event);
	}

	public IEvent getEvent() {
		return event;
	}

	public void setEvent(IEvent event) {
		this.event = event;
		if(null != event.data())
			dataVars = new AutomaticVars(event.data());
		else
			dataVars = null;
		if(null != event.source())
			sourceVars = new AutomaticVars(event.source());
		else
			sourceVars = null;
	}

	@Override
	public Object get(String key) {
		if("_EVENT".equals(key))
			return event;
		if("_EVENT_NAME".equals(key))
			return event.type();
		if("_EVENT_DATA".equals(key))
			return event.data();
		if("_EVENT_SOURCE".equals(key))
			return event.source();
		Object r = null;
		if(null != dataVars)
			r = dataVars.get(key);
		if(null == r && null != sourceVars)
			r = sourceVars.get(key);
		if(null == r)
			r = ProcEngine.instance().get(key);
		return r;
	}

	@Override
	public Object eval(String fun, List<Object> params) {
		return ProcEngine.instance().eval(fun, params);
	}

}
