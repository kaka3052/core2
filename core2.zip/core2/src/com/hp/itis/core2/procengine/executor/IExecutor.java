package com.hp.itis.core2.procengine.executor;

import com.hp.itis.core2.event.IEventDispatcher;
import com.hp.itis.core2.procengine.module.IControllableModule;

public interface IExecutor extends IExecutable, IEventDispatcher, IControllableModule {
	String EXEC_DONE = "ExecDone";
	String EXEC_ERROR = "ExecError";
	
	/**运行模式，同步*/
	int RM_SYNC = 0;
	/**运行模式，异步*/
	int RM_ASYN = 1;
	/**运行模式，并发*/
	int RM_CONC = 2;
	/**运行模式，异步并发*/
	int RM_ASCO = 3;
	
	void setExecutable(IExecutable exec);
}
