package com.hp.itis.core2.procengine.processes;

import java.io.File;
import java.io.FileInputStream;

import com.hp.itis.core2.file.FileOperate;
import com.sun.net.httpserver.HttpExchange;

public class HttpRespondProc extends DataProcess {

	private int responseCode = 200;
	private String contentType;
	private String charset;
	
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}
	
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
	public void setCharset(String charset) {
		this.charset = charset;
	}

	@Override
	protected boolean execute() throws Exception {
		return false;
	}

	@Override
	protected void setup() throws Exception {

	}
	
	public boolean execute(HttpExchange http) throws Exception {
		Object value = session().value();
		if(null != contentType) {
			if(null != charset)
				http.getResponseHeaders().set("Content-Type", contentType + "; charset=" + charset);
			else
				http.getResponseHeaders().set("Content-Type", contentType);
		}
		if(value instanceof HttpExchange) {
			http.sendResponseHeaders(responseCode, 0);
		}
		else if(value instanceof File) {
			FileInputStream fs = new FileInputStream((File)value);
			http.sendResponseHeaders(responseCode, fs.getChannel().size());
			FileOperate.copyStream(fs, http.getResponseBody());
		}
		else {
			String s = value.toString();
			byte[] bytes;
			if(null == charset)
				bytes = s.getBytes();
			else
				bytes = s.getBytes(charset);
			http.sendResponseHeaders(responseCode, bytes.length);
			http.getResponseBody().write(bytes);
		}
		http.close();
		return true;
	}

}
