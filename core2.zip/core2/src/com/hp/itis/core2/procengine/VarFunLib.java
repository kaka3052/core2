package com.hp.itis.core2.procengine;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.file.TextFile;
import com.hp.itis.core2.misc.StrUtil;
import com.hp.itis.core2.vars.AdvanceVarReplacer;
import com.hp.itis.core2.vars.AutomaticVars;
import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.Evaluator;
import com.hp.itis.core2.vars.IEvaluator;
import com.hp.itis.core2.vars.IFunVars;
import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.IWritableVars;
import com.hp.itis.core2.vars.MethodVars;

/**
 * ProcEngine 内置变量函数 
 * @version 1.0
 * @author changjiang
 *
 */
public class VarFunLib {
	
	public static IFunVars getVars() {
		return new MethodVars(VarFunLib.class);
	}
	
	public static IFunVars getVars(IVars vars) {
		return new CombinedVars(vars, new MethodVars(VarFunLib.class));
	}
	
	/**
	 * 按照指定格式返回当前日期字符串<p>
	 * 通过参数format指定的日期格式将当前时间格式化并输出
	 * format格式参见JDK中java.text.SimpleDateFormat的描述
	 * 
	 * @see java.text.SimpleDateFormat
	 * @param format 格式模板，默认值为"yyyy-MM-dd"
	 * @return
	 */
	public static String date(String format)
	{
		if(null == format)
			format = "yyyy-MM-dd";
		SimpleDateFormat df = new SimpleDateFormat(format);
		return df.format(new Date());
	}

	/**
	 * 按照指定格式返回当前时间字符串<p>
	 * 通过参数format指定的日期格式将当前时间格式化并输出
	 * format格式参见JDK中java.text.SimpleDateFormat的描述
	 * 
	 * @see java.text.SimpleDateFormat
	 * @param format 格式模板，默认值为"HH:mm:ss"
	 * @return
	 */
	public static String time(String format)
	{
		if(null == format)
			format = "HH:mm:ss";
		SimpleDateFormat df = new SimpleDateFormat(format);
		return df.format(new Date());
	}
	
	public static String formatDate(String format, Object date)
	{
		if(null == date)
			return null;
		SimpleDateFormat df = new SimpleDateFormat(format);
		return df.format(toDate(date, null));
	}
	
	/**
	 * 将对象转换为long(毫秒)表示的timestamp类型
	 * @param o
	 * @return
	 */
	public static long timestamp(Object o)
	{
		if(null == o)
			return System.currentTimeMillis();
		Date d = (Date)TypeCaster.cast(Date.class, o);
		return d.getTime();
	}
	
	public static Date now() {
		return new Date();
	}
	
	/**
	 * 返回（简单）类型名
	 * @param o
	 * @return
	 */
	public static String typeName(Object o)
	{
		if(null == o)
			return "null";
		else
			return o.getClass().getSimpleName();
	}
	
	public static int hashcode(Object o) {
		if(null == o)
			return 0;
		return o.hashCode();
	}
	
	/**
	 * 判断指定字typeName为指定实例o的直接或间接类型（简单）名
	 * @param typeName 类型名
	 * @param o 实例
	 * @return
	 */
	public static Boolean typeOf(String typeName, Object o) {
		if(null == o)
			return true;
		if(null == typeName)
			return false;
		Class<?> clazz;
		if(o instanceof Class<?>)
			clazz = (Class<?>)o;
		else
			clazz = o.getClass();
		while(null != clazz) {
			if(clazz.getSimpleName().equalsIgnoreCase(typeName))
				return true;
			if(clazz.getName().equals(typeName))
				return true;
			clazz = clazz.getSuperclass();
		}
		return false;
	}
	
	/**
	 * 取子字符串
	 * @param str 源字符串
	 * @param beginIndex 开始位置
	 * @param endIndex 结束位置
	 * @return
	 */
	public static String sub(String str, Integer beginIndex, Integer endIndex)
	{
		return str.substring(beginIndex, endIndex);
	}
	
	/**
	 * 取字符串头
	 * @param str 源字符串
	 * @param count 取头部的长度
	 * @return
	 */
	public static String left(String str, Integer count)
	{
		return str.substring(0, count);
	}
	
	/**
	 * 取字符串尾
	 * @param str 源字符串
	 * @param count 取尾部的长度
	 * @return 
	 */
	public static String rigth(String str, Integer count)
	{
		return str.substring(str.length()-count, str.length());
	}
	
	/**
	 * 字符串替换
	 * @param str 源字符串
	 * @param target 目标子串
	 * @param replacement 替换子串
	 * @return 替换结果
	 */
	public static String replace(String str, String target, String replacement)
	{
		return str.replace(target, replacement);
	}
	
	public static String lcase(String str) {
		if(null == str)
			return null;
		return str.toLowerCase();
	}
	
	public static String ucase(String str) {
		if(null == str)
			return null;
		return str.toUpperCase();
	}
	
	/**
	 * 用正则表达式替换子字符串
	 * @param str 源字符串
	 * @param regex 正则表达式
	 * @param replacement 替换子串
	 * @return
	 */
	public static String replaceAll(String str, String regex, String replacement)
	{
		return str.replaceAll(regex, replacement);
	}
	
	public static Boolean contains(String str, String subStr) {
		if(null == str || null == subStr)
			return false;
		return str.contains(subStr);
	}
	
	public static Boolean startsWith(String str, String prefix) {
		if(null == str || null == prefix)
			return false;
		return str.startsWith(prefix);
	}
	
	public static Boolean endsWith(String str, String suffix) {
		if(null == str || null == suffix)
			return false;
		return str.endsWith(suffix);
	}
	
	public static String join(String spliter, Object ... values) {
		StringBuilder sb = new StringBuilder();
		for(Object value : values) {
			if(sb.length()>0)
				sb.append(spliter);
			sb.append(value);
		}
		return sb.toString();
	}
	
	public static String[] split(String value, String spliter) {
		return value.split(spliter);
	}
	
	/**
	 * 对指定模板进行变量替换
	 * @param template
	 * @param vars
	 * @return
	 */
	public static String replaceVars(String template, Object vars)
	{
		if(vars==null || template == null)
			return null;
		return AdvanceVarReplacer.replace(template, new CombinedVars(new AutomaticVars(vars), ProcEngine.instance()));
	}
	
	/**
	 * 功能：进行简单的字符串转换 例子： 调用 TransformStr("123-456", "(\\d{3})\-(\\d{3})",
	 * "@{2}-@{1}"); 返回结果为：456-123 备注： 如果字符串没有匹配模板，则返回源字符串
	 * 
	 * @param str
	 *            源字符串
	 * @param patternStr
	 *            匹配模板字符串
	 * @param formatStr
	 *            格式字符串
	 * @return 转换后的字符串
	 */
	public static String transform(String str, String patternStr,
			String formatStr) {
		return StrUtil.transform(str, patternStr, formatStr);
	}
	
	@SuppressWarnings("deprecation")
	public static String urlEncode(String str, String charset) {
		try {
			if(null == str)
				return null;
			if(null == charset)
				return java.net.URLEncoder.encode(str);
			return java.net.URLEncoder.encode(str, charset);
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}
	
	@SuppressWarnings("deprecation")
	public static String urlDecode(String str, String charset) {
		try {
			if(null == str)
				return null;
			if(null == charset)
				return java.net.URLDecoder.decode(str);
			return java.net.URLDecoder.decode(str, charset);
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}
	
	public static Number number(Object value) {
		return TypeCaster.toNumber(value);
	}
	
	public static String string(Object value) {
		if(null == value)
			return null;
		return value.toString();
	}
	
	public static Boolean isNumber(Object value) {
		return TypeCaster.isNumber(value);
	}
	
	public static String explain(Object value) {
		return StrUtil.toString(value);
	}
	
	public static Boolean bool(Object value) {
		return TypeCaster.toBoolean(value);
	}
	
	public static Date toDate(Object value, String pattern) {
		if(null != pattern && value instanceof String)
			return TypeCaster.stringToDate(value.toString(), pattern);
		else
			return (Date)TypeCaster.cast(Date.class, value);
	}
	
	public static Object cast(Object value, String type, Object def) {
		if(null == type)
			return def;
		if(type.indexOf(".")<0)
			type = "Java.lang." + type;
		try {
			Class<?> c = Thread.currentThread().getContextClassLoader().loadClass(type);
			Object v = TypeCaster.cast(c, value);
			return v;
		}
		catch(Throwable e) {
			return def;
		}
	}
	
	public static Object getVar(Object value, String field, Object def) {
		if(null == value || null == field)
			return def;
		IVars vars = new AutomaticVars(value);
		Object o = vars.get(field);
		if(null == o)
			o = def;
		return o;
	}
	
	public static Boolean not(Object value) {
		return !bool(value);
	}
	
	public static Boolean and(Object ...values) {
		for(int i=0; i<values.length; i++)
			if(!bool(values[i]))
				return false;
		return true;
	}
	
	public static Boolean or(Object ...values) {
		for(int i=0; i<values.length; i++)
			if(bool(values[i]))
				return true;
		return false;
	}
	
	public static String format(String format, Object...args) {
		return String.format(format, args);
	}
	
	/**
	 * 判断是否匹配给定正则表达式
	 * @param s
	 * @param pat
	 * @return
	 */
	public static Boolean match(String s, String pat) {
		if(null == s)
			return null;
		return s.matches(pat);
	}
	
	/**
	 * 通过正则表达式提取字符串中的变量并复制到指定变量表
	 * @param s 要匹配的内容
	 * @param pat 正则表达式
	 * @param vars 可写的变量表
	 * @param mapString group到变量名的映射关系，形式："1=var1,2=var2,5=var3"
	 * @return 提取成功返回true，匹配不成功返回false
	 */
	public static Boolean extract(String s, String pat, IWritableVars vars, String mapString) {
		Pattern pattern = Pattern.compile(pat);
		Matcher matcher = pattern.matcher(s);
		if(matcher.matches()) {
			String[] mapList = mapString.split("[,;]");
			for(int i=0; i<mapList.length; i++) {
				String map = mapList[i].trim();
				int p = map.indexOf('=');
				int group = Integer.valueOf(map.substring(0, p));
				map = map.substring(p+1);
				String v = matcher.group(group);
				vars.put(map, v);
			}
			return true;
		}
		return false;
	}
	
	/**
	 * 变量映射<p>
	 * 根据var的值判断是否等于第2，4，6...2n个参数，返回第2n+1个参数的值
	 * 当指定map参数为基数个时，则最后一个参数表示默认值
	 * @param var 变量值
	 * @param map 映射列表
	 * @return
	 */
	public static Object map(Object var, Object... map)
	{
		if(null == var)
			return null;
		Object result = null;
		for(int i=0; i<map.length-1; i+=2)
		{
			if(var.equals(map[i]))
				result = map[i+1];
		}
		//是否包含默认值
		if(map.length % 2 == 1 && result == null) {
			result = map[map.length-1];
		}
		return result;
	}
	
	@SuppressWarnings("unchecked")
	public static Integer range(Object var, Object... levels) {
		if(var instanceof Comparable<?>) {
			for(int i = 0; i < levels.length; i++) {
				if(((Comparable<Object>)var).compareTo(levels[i]) < 0) {
					return i;
				}
			}
			return levels.length;
		}
		return null;
	}
	
	public static Integer compare(Object o1, Object o2) {
		return TypeCaster.compare(o1, o2);
	}
	
	public static Object max(Object... values) {
		Object m = null;
		for(Object value : values) {
			if(m == null)
				m = value;
			else if(TypeCaster.compare(value, m)>0)
				m = value;
		}
		return m;
	}
	
	public static Object maxOf(Iterable<?> values, String field) {
		if(null == values)
			return null;
		Object m = null;
		Object mv = null;
		for(Object value : values) {
			Object v = value;
			if(null != field)
				v = getVar(value, field, null);
			if(m == null) {
				mv = v;
				m = value;
			}
			else if(TypeCaster.compare(v, mv)>0) {
				mv = v;
				m = value;
			}
		}
		return m;
	}
	
	public static Object maxs(Object... values) {
		return max(values);
	}
	
	public static Object min(Object... values) {
		Object m = null;
		for(Object value : values) {
			if(m == null)
				m = value;
			else if(TypeCaster.compare(value, m)<0)
				m = value;
		}
		return m;
	}
	
	public static Object minOf(Iterable<?> values, String field) {
		Object m = null;
		Object mv = null;
		for(Object value : values) {
			Object v = value;
			if(null != field)
				v = getVar(value, field, null);
			if(m == null) {
				mv = v;
				m = value;
			}
			else if(TypeCaster.compare(v, mv)<0) {
				mv = v;
				m = value;
			}
		}
		return m;
	}
	
	public static Object mins(Object... values) {
		return min(values);
	}
	
	public static Double sum(Double ... values) {
		double sum = 0;
		for(Double d : values) {
			if(null != d)
				sum += d;
		}
		return sum;
	}
	
	public static Double sumOf(Iterable<?> values, String field) {
		double sum = 0;
		for(Object value : values) {
			Object v = value;
			if(null != field)
				v = getVar(value, field, null);
			if(null != v) {
				Number d = TypeCaster.toNumber(v);
				if(null != d)
					sum += d.doubleValue();
			}
		}
		return sum;
	}
	
	public static Double sums(Double ... values) {
		return sum(values);
	}
	
	public static Integer count(Object ... values) {
		if(values.length==1 && values[0] instanceof Iterable<?>)
			return countOf((Iterable<?>)values[0]);
		return values.length;
	}
	
	public static Integer countOf(Iterable<?> values) {
		if(null == values)
			return 0;
		if(values instanceof Collection<?>)
			return ((Collection<?>)values).size();
		int c = 0;
		for(Object v : values) {
			if(null != v)
				c++;
		}
		return c;
	}
	
	public static Double avg(Double ... values) {
		return sum(values) / count((Object[])values);
	}
	
	public static Object single(Object... values) {
		return values[0];
	}
	
	public static Object singleOf(Iterable<?> values) {
		return values.iterator().next();
	}
	
	@SuppressWarnings("unchecked")
	public static Object[] array(Object... values) {
		List<Object> list = new ArrayList<Object>();
		for(Object value : values) {
			if(value instanceof Iterable<?>) {
				for(Object v : (Iterable<Object>)value) {
					list.add(v);
				}
			}
			else
				list.add(value);
		}
		return list.toArray();
	}
	
	public static Map<String, String> str2map(String str, String splitter, String separator) {
		if(null == str)
			return null;
		if(null == splitter)
			splitter = "\r";
		if(null == separator)
			separator = "=";
		return StrUtil.str2map(str, splitter, separator);
	}
	
	/**
	 * 判断指定值v是否在其后的参数列表中存在
	 * @param v
	 * @param list
	 * @return true表示存在，false表示不存在
	 */
	public static Boolean in(Object v, Object... list) {
		if(null == v)
			return null;
		for(Object i : list)
			if(v.equals(i))
				return true;
		return false;
	}
	
	/**
	 * 空转换<p>
	 * 判断变量var是否为null，如果为null 则返回value否则返回var
	 * @param var 变量
	 * @param value
	 * @return
	 */
	public static Object ifNull(Object var, Object value)
	{
		if(null == var)
			return value;
		return var;
	}
	
	/**
	 * 真值判断转换<p>
	 * 判断变量var是否等于"0"，"false"或"no" 如果等于返回value2否则返回value1
	 * @param var 变量
	 * @param value1
	 * @param value2
	 * @return
	 */
	public static Object iif(Object var, Object value1, Object value2)
	{
		if(TypeCaster.toBoolean(var))
			return value1;
		else
			return value2;
	}
	
	public static Object NULL()
	{
		return null;
	}
	
	public static Boolean isNull(Object v) {
		return null == v;
	}
	
	public static Boolean isNotNull(Object v) {
		return null != v;
	}
	
	/**
	 * 取得系统临时路径
	 * @return
	 */
	public static Object systemTempPath()
	{
		return System.getProperty("java.io.tmpdir");
	}
	
	/**
	 * 取得当前工作路径
	 * @return
	 */
	public static Object currentPath()
	{
		return System.getProperty("user.dir");
	}
	
	/**
	 * 加载指定资源
	 * @return
	 */
	public static Object include(String resPath) 
	{
		return TextFile.loadResource(resPath);
	}
	
	/**
	 * 取得默认Locale
	 * @return
	 */
	public static Object LOCALE()
	{
		return java.util.Locale.getDefault().toString();
	}
	
	/**
	 * 判断当前操作系统是否为windows
	 * @return
	 */
	public static Boolean IS_WINDOWS(){
		return System.getProperty("os.name").toUpperCase().indexOf("WINDOWS")>=0;
	}
	
	/**
	 * 返回当前shell的默认扩展名
	 * @return
	 */
	public static Object SHELL_EXT() {
		if(IS_WINDOWS())
			return ".bat";
		else
			return ".sh";
	}
	
	
	public static Object print(Object o) {
		System.out.print(explain(o));
		return o;
	}
	
	public static Object println(Object o) {
		System.out.println(explain(o));
		return o;
	}
	
	public static Object eval(String expr, IVars vars) {
		if(null == vars)
			vars = getVars();
		IEvaluator eval = Evaluator.build(expr);
		if(null != eval)
			return eval.eval(vars);
		return null;
	}
}
