package com.hp.itis.core2.procengine;

import com.hp.itis.core2.event.IEventDispatcher;
import com.hp.itis.core2.procengine.module.IControllableModule;

public interface IEventProducer extends IControllableModule {
	void setEventTarget(IEventDispatcher target);
}
