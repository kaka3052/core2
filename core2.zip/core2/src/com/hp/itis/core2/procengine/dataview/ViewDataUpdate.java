package com.hp.itis.core2.procengine.dataview;

public class ViewDataUpdate<T> extends ViewDataEvent<T> implements IViewDataEvent<T> {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8875601334110513230L;
	private T oldData;
	
	public ViewDataUpdate(T data, T oldData) {
		super(data.getClass().getSimpleName(), data);
		this.oldData = oldData;
	}
	
	public ViewDataUpdate(String type, T data, T oldData) {
		super(type, data);
		this.oldData = oldData;
	}

	public T getOldData() {
		return oldData;
	}

	public void setOldData(T oldData) {
		this.oldData = oldData;
	}
	
	
}
