package com.hp.itis.core2.procengine.processes;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.misc.CodeMapper;
import com.hp.itis.core2.misc.CodeMapper.CodeResource;
import com.hp.itis.core2.misc.CodeMapper.ResourcePattern;
import com.hp.itis.core2.procengine.task.IProcess;
import com.hp.itis.core2.procengine.task.ISession;
import com.hp.itis.core2.vars.AdvanceVarReplacer;
import com.hp.itis.core2.vars.Evaluator;
import com.hp.itis.core2.vars.ExprEvaluator;
import com.hp.itis.core2.vars.GetterVars;
import com.hp.itis.core2.vars.IEvaluator;
import com.hp.itis.core2.vars.IVars;

abstract public class DataProcess implements IProcess {
	
	public static class ProcContext extends GetterVars {
		public ProcContext(final DataProcess process) {
			super(new IVars(){
				@Override
				public Object get(String key) {
					Object v = process.session().vars().get(key);
					if(null == v)
						return process.evalValue(process.params.get(key));
					return null;
				}
			});
		}
	}
	
	protected CommData params;
	protected ProcContext context = new ProcContext(this);
	private ThreadLocal<ISession> currentSession = new ThreadLocal<ISession>();
	protected CodeResource res = CodeMapper.instance().getResource(this.getClass());
	private IEvaluator conditionExpr = null;
	private String value = null;
	private List<Method> executors = new ArrayList<Method>();
	
	protected ISession session() {
		return currentSession.get();
	}
	
	@Override
	public boolean execute(ISession session) throws Exception {
		if(null != conditionExpr)
			if(!TypeCaster.toBoolean(conditionExpr.eval(session.vars()))) {
				session.log().debug("The process execution will be ignored because of that condition evaluation returns false.");
				return true;
			}
		currentSession.set(session);
		if(executors.size()>0 && null != session.value()) {
			loop1:
			for(Method m : executors) {
				Class<?>[] pTypes = m.getParameterTypes();
				Object[] pValues = new Object[pTypes.length];
				for(int i=0; i<pTypes.length; i++) {
					Class<?> pt = pTypes[i];
					Object o = session.value(pt);
					if(null == o)
						continue loop1;
					pValues[i] = o;
				}
				Object r = null;
				try {
					r = m.invoke(this, pValues);
				}
				catch(InvocationTargetException e) {
					if(e instanceof Exception)
						throw (Exception)(e.getTargetException());
					else
						throw e;
				}
				if(m.getReturnType().getSimpleName().equalsIgnoreCase("void"))
					return true;
				if(r==null)
					return false;
				if(r instanceof Boolean)
					return (Boolean)r;
				session.value(r);
				return true;
			}
		}
		return execute();
	}
	
	abstract protected boolean execute() throws Exception;

	@Override
	public void init(CommData params) throws Exception {
		Method[] methods = getClass().getMethods();
		for(int i=0; i<methods.length; i++) {
			Method m = methods[i];
			if("execute".equals(m.getName())) {
				Class<?>[] pTypes = m.getParameterTypes();
				if(pTypes.length == 0)
					continue;
				Class<?> pType = pTypes[0];
				if(pType.isAssignableFrom(ISession.class))
					continue;
				executors.add(m);
			}
		}
		init(params, null);
	}
	
	public void init(CommData params, ISession session) throws Exception {
		this.params = params;
		setup();
	}
	
	protected String resGet(Object code) {
		return res.get(code);
	}
	
	protected String resFormat(ResourcePattern pattern) {
		return res.format(pattern);
	}
	
	protected String resFormat(Object code, Object... args) {
		return res.format(code, args);
	}
	
	protected void value(Object v) {
		session().value(v);
	}
	
	protected Object value() {
		if(null == value)
			return session().value();
		return evalValue(value);
	}
	
	protected Object evalValue(Object expr) {
		if(null == expr)
			return null;
		Object v = null;
		if(expr instanceof String) {
			String exprStr = (String)expr;
			if(exprStr.indexOf("#[")>=0) {
				v = (new AdvanceVarReplacer(exprStr, '#', '[')).replace(session().vars());
			}
			else if((exprStr.startsWith("[") && exprStr.endsWith("]")) || 
						exprStr.startsWith("{") && exprStr.endsWith("}")) {
				exprStr = exprStr.substring(1, exprStr.length()-1);
				if((exprStr.startsWith("[") && exprStr.endsWith("]")) || 
						exprStr.startsWith("{") && exprStr.endsWith("}"))
					v = exprStr;
				else {
					v = session().vars().get(exprStr);
					if(null == v) {
						IEvaluator eval = Evaluator.build(exprStr);
						v = eval.eval(session().vars());
					}
				}
			}
			else
				v = expr;
		}
		else
			v = expr;
		return v;
	}
	
	public void destroy() {
		
	}
	
	abstract protected void setup() throws Exception;

	public void setCondition(String value) {
		if(null != value)
			this.conditionExpr =ExprEvaluator.build(value);
	}

	public void setValue(String value) {
		this.value = value;
	}
}
