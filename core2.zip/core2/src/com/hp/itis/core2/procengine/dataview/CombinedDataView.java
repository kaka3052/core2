package com.hp.itis.core2.procengine.dataview;

import java.util.ArrayList;
import java.util.List;

public class CombinedDataView<T> extends EventView implements IEventView {

	private List<IDataView> views = new ArrayList<IDataView>();
	
	public CombinedDataView(IDataView... views) {
		super();
		for(IDataView view : views) {
			if(null != view)
				this.views.add(view);
		}
	}
	
	public void addView(IDataView view) {
		if(null != view)
			views.add(view);
	}
	
	@Override
	public boolean accept(Object data) {
		for(IDataView view : views) {
			if(!view.accept(data))
				return false;
		}
		return true;
	}

}
