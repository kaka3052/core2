package com.hp.itis.core2.procengine.processes;

public class SetProc extends SetValuesProc {

}
