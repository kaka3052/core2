package com.hp.itis.core2.procengine.module;

import java.io.File;
import java.util.concurrent.TimeUnit;

import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventDispatcher;
import com.hp.itis.core2.pqueue.PersistentDelayQueue;
import com.hp.itis.core2.pqueue.PersistentFilter;
import com.hp.itis.core2.pqueue.Scheduled;
import com.hp.itis.core2.procengine.IEventProducer;
import com.hp.itis.core2.procengine.ProcEngine;


public class EventScheduler extends ActiveModule implements IEventProducer {

	private PersistentDelayQueue<IEvent> scheduleList;
	private IEventDispatcher target;
	private boolean enable = false;
	private boolean persistent;
	private boolean activated = false;

	public EventScheduler() throws Exception {
		persistent = ProcEngine.instance().context().get("core.scheduler.queuePersistent", true);
	}
	
	@Override
	public void run() {
		Scheduled<IEvent> se = null;
		try {
			se = scheduleList.poll(1, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
		}
		if(null != se) {
			long d = se.getDelay(TimeUnit.MILLISECONDS);
			if(d>-1000)
				log().debug(20002, se.element.toString(), -d);
			else
				log().debug(20003, se.element.toString(), -d/1000);
			target.dispatch(se.element);
		}
	}

	public void schedule(IEvent event, long delay) {
		if(!enable || null == event)
			return;
		if(!activated) {
			try {
				start();
			} catch (Exception e) {
				log().error(e, e);
			}
		}
		Scheduled<IEvent> se = new Scheduled<IEvent>(event, System.currentTimeMillis() + delay);
		log().debug(20001, event.toString(), delay, scheduleList.size());
		scheduleList.add(se);
	}
	
	public void start() throws Exception {
		if(persistent) {
			File queueFile = ProcEngine.instance().context().getDataFile(this.name() + ".queue");
			scheduleList = new PersistentDelayQueue<IEvent>(queueFile);
			PersistentFilter filter = (PersistentFilter)ProcEngine.instance().getBean(PersistentFilter.class);
			((PersistentDelayQueue<IEvent>)scheduleList).setFilter(filter);
		}
		else
			scheduleList = new PersistentDelayQueue<IEvent>((String)null);
		super.activate();
		activated = true;
	}

	@Override
	public void setEventTarget(IEventDispatcher target) {
		this.target = target;
	}
	
	@Override
	protected synchronized void activate() {
		enable = true;
	}

	@Override
	protected synchronized void deactivate() {
		enable = false;
		if(super.isActive())
			super.deactivate();
	}

}
