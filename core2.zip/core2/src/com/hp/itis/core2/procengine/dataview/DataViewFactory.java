package com.hp.itis.core2.procengine.dataview;

public interface DataViewFactory {
	IDataView getView(String viewName);
	IDataView getView(String viewName, String userName);
	IDataView getView(String viewName, String userName, Object param);
	void dropView(IDataView view);
}
