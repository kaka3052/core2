package com.hp.itis.core2.procengine.dataview;

public class EventView implements IEventView {
	
	private IDataView dataView;

	public IDataView getDataView() {
		return dataView;
	}

	public void setDataView(IDataView dataView) {
		this.dataView = dataView;
	}
	
	public EventView() {
		
	}

	public EventView(IDataView dataView) {
		this.dataView = dataView;
	}
	
	@Override
	public boolean accept(Object data) {
		return dataView.accept(data);
	}
	
	public IViewDataEvent<?> accept(IViewDataEvent<?> event) {
		return accept(this, event);
	}
	
	public static <E> IViewDataEvent<E> accept(IDataView dataView, IViewDataEvent<E> event) {
		if(null == dataView)
			return null;
		if(event instanceof ViewDataUpdate<?>) {
			ViewDataUpdate<E> updateEvent = (ViewDataUpdate<E>)event;
			if(dataView.accept(updateEvent.getOldData())) {
				if(dataView.accept(updateEvent.getData()))
					return event;
				else
					return new ViewDataRemove<E>(updateEvent.type(), updateEvent.getOldData());
			}
			else {
				if(dataView.accept(updateEvent.getData()))
					return new ViewDataAdd<E>(updateEvent.type(), updateEvent.getData());
			}
			return null;
		}
		else {
			if(dataView.accept(event.getData()))
				return event;
			else
				return null;
		}
	}

}
