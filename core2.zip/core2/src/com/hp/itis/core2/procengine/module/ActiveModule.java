package com.hp.itis.core2.procengine.module;

import com.hp.itis.core2.task.DurableTask;

public abstract class ActiveModule extends ControllableModule implements IActiveModule{

	protected DurableTask task=null; 
	protected volatile long interval=0;
	
	private class ActiveModuleTask extends DurableTask {

		public String name() {
			return module().name();
		}
		
		@Override
		public void run() {
			module().run();
		}
		
		@Override
		public long interval() {
			return module().interval();
		}
	}
	
	public long interval() {
		return interval;
	}
	
	public abstract void run();
	
	protected IActiveModule module() {
		return this;
	}
	
	@Override
	protected void activate() {
		synchronized(this) {
			if(task==null)
				task = new ActiveModuleTask();
		}
		task.resume();
	}

	@Override
	protected void deactivate() {
		task.cancel();
		task = null;
	}

}
