package com.hp.itis.core2.procengine.module;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;
import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.misc.ExClassLoader;
import com.hp.itis.core2.misc.PLog;
import com.hp.itis.core2.misc.WrappedLog;
import com.hp.itis.core2.pqueue.PersistentFilter;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.VarFunLib;
import com.hp.itis.core2.procengine.bean.BeanBuilder;
import com.hp.itis.core2.procengine.bean.IBeanFactory;
import com.hp.itis.core2.procengine.module.IConfigProvider.ConfigVisitor;
import com.hp.itis.core2.vars.AdvanceVarReplacer;
import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.CommDataVars;
import com.hp.itis.core2.vars.EnvVars;
import com.hp.itis.core2.vars.GetterVars;
import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.MethodVars;
import com.hp.itis.core2.vars.SysPropertyVars;

public class EngineContext extends GetterVars implements IEngineContext {
	private PLog log = new WrappedLog(this.getClass().getSimpleName());
	private CommData data = new CommDataImpl(new ConcurrentHashMap<String, Object>());
	private Map<String, Object> beans = new LinkedHashMap<String, Object>();
	private List<IBeanFactory> factorys = new ArrayList<IBeanFactory>();
	private BeanBuilder beanBuilder = new BeanBuilder(this);
	private IVars funVars;
	private File dataDir;
	private File tempDir;
	private ExClassLoader classLoader;
	
	public EngineContext() {
		super(new CombinedVars());
		funVars = new MethodVars(VarFunLib.class);
		((CombinedVars)vars).add(new CommDataVars(data),
				new EnvVars(), new SysPropertyVars(), funVars);
		put("engine.id", "default");
		put("engine.instance", java.util.UUID.randomUUID().toString());
	}
	
	public String engineId() {
		return getString("engine.id");
	}
	
	public String instanceId() {
		return getString("engine.instance");
	}
	
	public File getDataFile(String fileName) {
		File file = new File(fileName);
		if(file.isAbsolute())
			return file;
		if(!dataDir.exists())
			dataDir.mkdirs();
		return new File(dataDir.getPath() + "/" + fileName);
	}
	
	public File getTempFile(String fileName) {
		File file = new File(fileName);
		if(file.isAbsolute())
			return file;
		if(!tempDir.exists())
			tempDir.mkdirs();
		return new File(tempDir.getPath() + "/" + fileName);
	}
	
	public void loadConfig(IConfigProvider conf) {
		addVars(conf);
		initClassLoader(conf);
		initPackages(conf);
		initWorkingPath();
		initPersistentFilter();
		beanBuilder.setVars(this);
		initBeans(conf);
	}
	
	protected void initPackages(IConfigProvider conf) {
		String base = ProcEngine.class.getPackage().getName();
		beanBuilder.importClass(base + ".triggers.*");
		beanBuilder.importClass(base + ".services.*");
		beanBuilder.importClass(base + ".processes.*");
		beanBuilder.importClass(base + ".adapter.*");
		String s = getString("core.packages");
		if(null != s) {
			String[]sl = s.split(",");
			for(int i=0; i<sl.length; i++) {
				String ss = sl[i];
				ss = ss.trim();
				if(ss.endsWith("."))
					ss += "*";
				else if(!ss.endsWith(".*"))
					ss += ".*";
				beanBuilder.importClass(ss);
			}
		}
		CommData imports = (CommData)conf.get(IConfigProvider.CAT_IMPORT);
		if(null != imports) {
			for(Object o : imports) {
				String className = (String)o;
				if(null != className) {
					beanBuilder.importClass(className);
					log.debug(20002, className);
				}
			}
		}
	}
	
	protected void initClassLoader(IConfigProvider conf) {
		classLoader = new ExClassLoader(Thread.currentThread().getContextClassLoader());
		CommData classpath = (CommData)conf.get(IConfigProvider.CAT_CLASSPATH);
		if(null != classpath) {
			for(Object o : classpath) {
				String path = o.toString();
				if(null != path) {
					classLoader.addPath(path);
					log.debug(20001, path);
				}
			}
		}
		for(URL url : classLoader.getURLs()) {
			log.debug(20005, url.toString());
		}
		Thread.currentThread().setContextClassLoader(classLoader);
	}
	
	protected void initWorkingPath() {
		dataDir = new File(get("core.path.data", getString("user.dir") + "/var") + "/" + engineId());
		try {
			dataDir = dataDir.getCanonicalFile();
			log.debug(20003, dataDir.getPath());
		} catch (IOException e) {}
		tempDir = new File(get("core.path.temp", getString("java.io.tmpdir")) + "/" + engineId() + "/" + instanceId());
		try {
			tempDir = tempDir.getCanonicalFile();
			tempDir.deleteOnExit();
			log.debug(20004, tempDir.getPath());
		} catch (IOException e) {}
	}
	
	protected void initPersistentFilter() {
		String persistentFilter = ProcEngine.instance().context().getString("core.persistentFilter");
		if(null != persistentFilter && persistentFilter.length()>0) {
			String[] events = persistentFilter.split(",");
			final Set<String> persistentEvents = new HashSet<String>();
			for(int i=0; i<events.length; i++)
				persistentEvents.add(events[i]);
			PersistentFilter persistentEventsFilter = new PersistentFilter() {
				
				@Override
				public boolean accept(Serializable element) {
					if(element instanceof IEvent) {
						IEvent event = (IEvent)element;
						return persistentEvents.contains(event.type());
					}
					return false;
				}
			};
			beans.put("persistentEventsFilter", persistentEventsFilter);
		}
	}
	
	protected void initBeans(IConfigProvider conf) {
		initBeans(IConfigProvider.CAT_FACTORY, conf);
		initBeans(IConfigProvider.CAT_BEAN, conf);
		initBeans(IConfigProvider.CAT_SERVICE, conf);
		initBeans(IConfigProvider.CAT_FILTER, conf);
		initBeans(IConfigProvider.CAT_TASK, conf);
		initBeans(IConfigProvider.CAT_MODULE, conf);
		initBeans(IConfigProvider.CAT_TRIGGER, conf);
	}
	
	protected void initBeans(String cat, IConfigProvider conf) {
		conf.visit(cat, new ConfigVisitor() {

			@Override
			public void accept(CommData conf) {
				String name = conf.getString("name");
				if(null == name || beans.containsKey(name))
					return;
				try {
					Object o = createObject(conf);
					beans.put(name, o);
					if(o instanceof IBeanFactory) {
						factorys.add((IBeanFactory)o);
					}
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			}
			
		});
	}
	
	public Object createObject(Class<?> c, CommData params, Object... args) throws Exception {
		return beanBuilder.createObject(c, params, args);
	}
	
	@Override
	public Class<?> getClass(String className) throws ClassNotFoundException {
		return beanBuilder.getClass(className);
	}
	
	public Object createObject(String className, CommData params, Object... args) throws Exception {
		return beanBuilder.createObject(className, params, args);
	}
	
	
	public Object createObject(CommData params) throws Exception {
		return beanBuilder.createObject(params);
	}
	
	@Override
	public Object createObject(Class<?> c, Object... args) throws Exception {
		return beanBuilder.createObject(c, args);
	}

	@Override
	public Object createObject(String className, Object... args)
			throws Exception {
		return beanBuilder.createObject(className, args);
	}
	
	@Override
	public void buildObject(Object o, CommData params) throws Exception {
		beanBuilder.buildObject(o, params);
	}
	
	public CommData updateParams(CommData params) {
		return updateParams(params, this);
	}
	
	public CommData updateParams(CommData params, IVars vars) {
		CommData tParams = params.clone();
		for(String key : tParams.keySet()) {
			Object o = tParams.get(key);
			if(o instanceof String) {
				String s = o.toString();
				if(s.indexOf('$')>=0) {
					AdvanceVarReplacer replacer = new AdvanceVarReplacer(o.toString(), '$', '[');
					o = replacer.replace(vars);
					tParams.put(key, o);
				}
			}
		}
		return tParams;
	}
	
	@Override
	public Object getBean(String name) {
		Object bean = beans.get(name);
		if(null == bean) {
			for(IBeanFactory factory :factorys) {
				bean = factory.getBean(name);
				if(null != bean)
					break;
			}
		}
		return bean;
	}

	@Override
	public Object getBean(String name, Class<?> c) {
		Object bean = getBean(name);
		if(c.isInstance(bean))
			return bean;
		return null;
	}

	@Override
	public Object getBean(Class<?> c) {
		Object bean = null;
		for(Object b : beans.values()) {
			if(c.isInstance(b)) {
				bean = b;
				break;
			}
		}
		if(null == bean)
			for(IBeanFactory factory :factorys) {
				bean = factory.getBean(c);
				if(null != bean)
					break;
			}
		return bean;
	}

	@Override
	public Collection<?> getBeans(Class<?> c) {
		Set<Object> result = new LinkedHashSet<Object>();
		for(Object bean : beans.values()) {
			if(c.isInstance(bean))
				result.add(bean);
		}
		for(IBeanFactory factory :factorys) {
			result.addAll(factory.getBeans(c));
		}
		return result;
	}
	
	public void put(CommData vars) {
		this.data.put(vars);
	}
	
	public Object get(String key) {
		Object v = getBean(key);
		if(null == v)
			v = vars.get(key);
		return v;
	}
	
	public Object get(String key, Object def) {
		Object r = get(key);
		if(r != null && def != null){
			try {
				return TypeCaster.cast(def.getClass(), r);
			}
			catch(Exception e) {
			}
		}
		return def;
	}
	
	public void addVars(IVars vars) {
		((CombinedVars)this.vars).add(vars, true);
	}
	
	public IVars getFunVars() {
		return funVars;
	}

	@Override
	public void put(String key, Object value) {
		data.put(key, value);
	}

	@Override
	public void addBeanFactory(IBeanFactory factory) {
		factorys.add(factory);
	}

	@Override
	public void removeBeanFactory(IBeanFactory factory) {
		factorys.remove(factory);
	}

	@Override
	public ClassLoader getClassLoader() {
		return classLoader;
	}


}
