package com.hp.itis.core2.procengine.task;

import java.util.ArrayList;
import java.util.List;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.FieldMap;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.module.EventConsumer;
import com.hp.itis.core2.procengine.module.SessionFactory;

public class Task extends EventConsumer implements ITask{
	
	private List<ProcessWrapper> processes = new ArrayList<ProcessWrapper>();
	protected CommData params;
	protected Class<?> profileClass = null;
	protected ITaskProfile profile = null;

	@Override
	public void init(CommData params) throws Exception {
		super.init(params);
		this.params = params;
		profile = createProfile();
	}
	
	protected ITaskProfile createProfile() throws Exception {
		if(null == profileClass)
			profileClass = DefaultTaskProfile.class;
		return (ITaskProfile)ProcEngine.instance().createObject(profileClass, params);
	}

	@Override
	public void onEvent(IEvent event) {
		ISession session;
		session = SessionFactory.instance.createSession(event);
		try {
			execute(session);
		} catch (Exception e) {
			log().error(e, e);
		}
		finally {
			SessionFactory.instance.freeSession(session);
		}
	}
	
	@Override
	public boolean execute(ISession session) throws Exception {
		boolean falling = false;
		boolean result = true;
		boolean passing = false;
		Throwable lastError = null;
		taskBegin(session, this);
		for(int i=0; i<processes.size(); i++) {
			if(session.finished())
				break;;
			ProcessWrapper p = processes.get(i);
			int invokeMode = p.invokeMode();
			passing = p.passing();
			if(falling) {
				if(invokeMode == ProcessWrapper.IM_ALWAYS)
					falling = false;
				else
					continue;
			}
			else if(!((result && (invokeMode==ProcessWrapper.IM_ON_SUCCESS)) || 
					(!result &&  (invokeMode==ProcessWrapper.IM_ON_FAIL)) ||
					(invokeMode==ProcessWrapper.IM_CONTINUE) ||
					(invokeMode==ProcessWrapper.IM_ALWAYS))) {
				falling = true;
				continue;
			}
			((Session)session).procStartTime = System.currentTimeMillis();
			procBegin(session, p);
			if(passing) {
				p.execute(session);
				passing = false;
			}
			else
				result = p.execute(session);
			session.report(result);
			if(null != session.lastError() && lastError != session.lastError()) {
				lastError = session.lastError();
				procError(session, p, session.lastError());
			}
			procEnd(session, p);
		}
		taskEnd(session, this);
		return session.result();
	}
	
	public void setProfile(String value) throws ClassNotFoundException {
		if(value.indexOf('.')<0) {
			value = this.getClass().getPackage().getName() + "." + value + "Profile";
		}
		profileClass = ProcEngine.instance().getClass(value);
	}
	
	@FieldMap("Process")
	public void setProcess(CommData cd) throws Exception {
		for(Object o : cd) {
			if(o instanceof CommData) {
				ProcessWrapper proc = (ProcessWrapper)ProcEngine.instance().createObject(ProcessWrapper.class, (CommData)o);
				proc.parent(this);
				processes.add(proc);
			}
		}
	}

	protected void procBegin(ISession session, IProcess process) {
		((Session)session).currentModule = (ProcessWrapper)process;
		if(null != profile) 
			profile.procBegin(session, process);
		if(hasListener(TaskEvent.PROC_BEGIN)) 
			dispatch(new TaskEvent(TaskEvent.PROC_BEGIN, session, (ProcessWrapper)process));
	}

	protected void procEnd(ISession session, IProcess process) {
		if(null != profile) 
			profile.procEnd(session, process);
		if(hasListener(TaskEvent.PROC_END)) 
			dispatch(new TaskEvent(TaskEvent.PROC_END, session, (ProcessWrapper)process));
		((Session)session).currentModule = this;
	}

	protected void procError(ISession session, IProcess process, Throwable e) {
		if(null != profile)
			profile.procError(session, process, e);
		if(hasListener(TaskEvent.PROC_ERROR)) 
			dispatch(new TaskEvent(TaskEvent.PROC_END, session, (ProcessWrapper)process, e));
	}

	protected void taskBegin(ISession session, ITask task) {
		((Session)session).currentModule = this;
		if(null != profile)
			profile.taskBegin(session, task);
		if(hasListener(TaskEvent.TASK_BEGIN)) 
			dispatch(new TaskEvent(TaskEvent.TASK_BEGIN, session, this));
	}

	protected void taskEnd(ISession session, ITask task) {
		session.end();
		if(null != profile)
			profile.taskEnd(session, task);
		if(hasListener(TaskEvent.TASK_END)) 
			dispatch(new TaskEvent(TaskEvent.TASK_END, session, this));
		((Session)session).currentModule = null;
	}

	@Override
	public void destroy() {
		for(IProcess p : processes)
			p.destroy();
	}

}
