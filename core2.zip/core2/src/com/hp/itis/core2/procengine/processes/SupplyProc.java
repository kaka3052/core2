package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.procengine.ProcEngine;

public class SupplyProc extends DataProcess {
	
	private Object value;

	@Override
	protected boolean execute() throws Exception {
		Object v = evalValue(value);
		if(null == v)
			v = value();
		if(null == v)
			v = session().result();
		ProcEngine.instance().supply(session().event(), v);
		return true;
	}

	@Override
	protected void setup() throws Exception {
	}
	
	public void setResult(Object v) {
		value = v;
	}

}
