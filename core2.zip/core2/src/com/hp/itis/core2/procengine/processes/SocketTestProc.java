package com.hp.itis.core2.procengine.processes;

import java.net.Socket;

public class SocketTestProc extends SocketSendProc {

	@Override
	protected boolean execute() throws Exception {
		try {
			Socket socket = connect();
			boolean r = socket.isConnected();
			socket.close();
			return r;
		} catch (Exception e) {
			return false;
		}			
	}
}
