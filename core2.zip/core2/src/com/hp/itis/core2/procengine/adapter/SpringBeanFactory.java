package com.hp.itis.core2.procengine.adapter;

import java.util.Collection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.hp.itis.core2.procengine.bean.IBeanFactory;

public class SpringBeanFactory implements IBeanFactory {

	protected ApplicationContext springContext;
	
	public SpringBeanFactory() {
		
	}
	
	public SpringBeanFactory(String confPath) {
		setConfig(confPath);
	}
	
	public SpringBeanFactory(ApplicationContext springContext) {
		this.springContext = springContext;
	}
	
	public void setConfig(String v) {
		String confs[] = v.split("[,;]");
		if(null == Thread.currentThread().getContextClassLoader().getResource(confs[0]))
			springContext = new FileSystemXmlApplicationContext(confs);
		else
			springContext = new ClassPathXmlApplicationContext(confs);
	}
	
	@Override
	public Object getBean(String name) {
		try {
			if(springContext.containsBean(name))
				return springContext.getBean(name);
		}
		catch(Throwable e) {}
		return null;
	}

	@Override
	public Object getBean(String name, Class<?> c) {
		try {
			return springContext.getBean(name, c);
		}
		catch(Throwable e) {}
		return null;
	}

	@Override
	public Object getBean(Class<?> c) {
		Collection<?> s = getBeans(c);
		if(s.size()>0)
			return s.iterator().next();
		return null;
	}

	@Override
	public Collection<?> getBeans(Class<?> c) {
		return springContext.getBeansOfType(c).values();
	}

}
