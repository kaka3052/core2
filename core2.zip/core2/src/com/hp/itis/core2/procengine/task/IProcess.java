package com.hp.itis.core2.procengine.task;

import com.hp.itis.core2.commdata.CommData;

public interface IProcess {
	void init(CommData params) throws Exception;
	boolean execute(ISession session) throws Exception;
	void destroy();
}
