package com.hp.itis.core2.procengine.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.db.DbOperator;
import com.hp.itis.core2.db.SqlPreparation;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.module.Service;
import com.hp.itis.core2.vars.IVars;

public class DbService extends Service {
	
	private DbOperator dbOperator;
	private DataSource dataSource;
	
	public DbService() {
		dbOperator = new DbOperator();
	}
	
	public void setConnPool(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	@Override
	public void start() throws Exception {
		if(null == dataSource)
			dataSource = (DataSource)ProcEngine.instance().getBean(DataSource.class);
	}

	@Override
	public void stop() throws Exception {
		// TODO Auto-generated method stub
		
	}

	public void close(Connection conn) {
		dbOperator.close(conn);
	}

	public void close(ResultSet rs) {
		dbOperator.close(rs);
	}
	
	public boolean execute(Connection conn, String sql, IVars v)
			throws SQLException {
		return dbOperator.execute(conn, sql, v);
	}

	public boolean execute(Connection conn, String sql, Object... v)
			throws SQLException {
		return dbOperator.execute(conn, sql, v);
	}

	public boolean execute(PreparedStatement s) throws SQLException {
		return dbOperator.execute(s);
	}

	public boolean execute(SqlPreparation p) throws SQLException {
		return dbOperator.execute(p);
	}

	public boolean execute(String sql, IVars v) throws SQLException {
		return dbOperator.execute(sql, v);
	}

	public boolean execute(String sql, Object... v) throws SQLException {
		return dbOperator.execute(sql, v);
	}

	public ResultSet getConnectedRs(Connection conn, ResultSet rs) {
		return dbOperator.getConnectedRs(conn, rs);
	}

	public Connection getConnection() throws SQLException {
		return dbOperator.getConnection();
	}

	public SqlPreparation prepareSql(Connection conn, String sql,
			Object params, int resultSetType, int resultSetConcurrency)
			throws SQLException {
		return dbOperator.prepareSql(conn, sql, params, resultSetType,
				resultSetConcurrency);
	}

	public SqlPreparation prepareSql(Connection conn, String sql, Object params)
			throws SQLException {
		return dbOperator.prepareSql(conn, sql, params);
	}

	public PreparedStatement prepareStatement(Connection conn, String sql,
			int resultSetType, int resultSetConcurrency, Object... v)
			throws SQLException {
		return dbOperator.prepareStatement(conn, sql, resultSetType,
				resultSetConcurrency, v);
	}

	public PreparedStatement prepareStatement(Connection conn, String sql,
			Object... v) throws SQLException {
		return dbOperator.prepareStatement(conn, sql, v);
	}

	public ResultSet query(Connection conn, String sql, IVars v)
			throws SQLException {
		return dbOperator.query(conn, sql, v);
	}

	public ResultSet query(Connection conn, String sql, Object... v)
			throws SQLException {
		return dbOperator.query(conn, sql, v);
	}

	public ResultSet query(SqlPreparation p) throws SQLException {
		return dbOperator.query(p);
	}

	public ResultSet query(String sql, IVars v) throws SQLException {
		return dbOperator.query(sql, v);
	}

	public ResultSet query(String sql, Object... v) throws SQLException {
		return dbOperator.query(sql, v);
	}

	public CommData queryCommData(Connection conn, String sql, IVars v)
			throws SQLException {
		return dbOperator.queryCommData(conn, sql, v);
	}

	public CommData queryCommData(Connection conn, String sql, Object... v)
			throws SQLException {
		return dbOperator.queryCommData(conn, sql, v);
	}

	public CommData queryCommData(Connection conn, String sql, String keyName,
			IVars v) throws SQLException {
		return dbOperator.queryCommData(conn, sql, keyName, v);
	}

	public CommData queryCommData(PreparedStatement s, String keyName)
			throws SQLException {
		return dbOperator.queryCommData(s, keyName);
	}

	public CommData queryCommData(SqlPreparation p, String keyName)
			throws SQLException {
		return dbOperator.queryCommData(p, keyName);
	}

	public CommData queryCommData(String sql, IVars v) throws SQLException {
		return dbOperator.queryCommData(sql, v);
	}

	public CommData queryCommData(String sql, Object... v) throws SQLException {
		return dbOperator.queryCommData(sql, v);
	}

	public CommData queryCommData(String sql, String keyName, IVars v)
			throws SQLException {
		return dbOperator.queryCommData(sql, keyName, v);
	}

	public void setDataSource(DataSource dataSource) {
		dbOperator.setDataSource(dataSource);
	}

	public void test() throws SQLException {
		dbOperator.test();
	}

}
