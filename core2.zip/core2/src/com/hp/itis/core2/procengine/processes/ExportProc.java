package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.procengine.module.CommEvent;

public class ExportProc extends DataProcess {

	@Override
	protected boolean execute() throws Exception {
		for(String key : params.keySet()) {
			String value = params.getString(key);
			if(session().event() instanceof CommEvent) {
				CommEvent event = (CommEvent)(session().event());
				event.put(key, evalValue(value));
			}
		}
		return true;
	}

	@Override
	protected void setup() throws Exception {
	}

}
