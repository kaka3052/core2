package com.hp.itis.core2.procengine.processes;

import org.apache.commons.logging.LogFactory;

import com.hp.itis.core2.misc.PLog;
import com.hp.itis.core2.misc.WrappedLog;
import com.hp.itis.core2.vars.AdvanceVarReplacer;
import com.hp.itis.core2.vars.IVarReplacer;

public class LogProc extends DataProcess {

	private IVarReplacer logPattern;
	private String level = "info";
	private PLog logger;

	@Override
	protected void setup() throws Exception {
		
	}

	public void setLog(String log) {
		logPattern = new AdvanceVarReplacer(log, '#', '[');
	}
	
	public void setLevel(String level) {
		this.level = level;
	}
	
	protected String getLog() {
		String log;
		if(null == logPattern) {
			Object v = value();
			if(null == v)
				v = session().deriveValue();
			log = String.valueOf(v);
		}
		else
			log = logPattern.replace(session().vars());
		return log;
	}

	@Override
	public boolean execute() throws Exception {
		PLog logger;
		if(null != this.logger)
			logger = this.logger;
		else
			logger = session().log();
		if("trace".equalsIgnoreCase(level))
			logger.trace(getLog());
		else if("debug".equalsIgnoreCase(level))
			logger.debug(getLog());
		else if("info".equalsIgnoreCase(level))
			logger.info(getLog());
		else if("warn".equalsIgnoreCase(level))
			logger.warn(getLog());
		else if("error".equalsIgnoreCase(level))
			logger.error(getLog());
		else if("fatal".equalsIgnoreCase(level))
			logger.fatal(getLog());
		return session().result();
	}
	
	public void setTarget(String target) {
		logger = new WrappedLog(LogFactory.getLog(target));
	}
}
