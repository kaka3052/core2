package com.hp.itis.core2.procengine.triggers;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventListener;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.executor.ConcExecutor;
import com.hp.itis.core2.procengine.executor.IExecutable;
import com.hp.itis.core2.procengine.executor.IExecutor;
import com.hp.itis.core2.procengine.module.IActiveModule;
import com.hp.itis.core2.procengine.module.WrappedActiveModule;

public class SocketTrigger extends AsynTrigger implements IActiveModule, IExecutable, IEventListener {

    private Selector selector = null;
    private ServerSocketChannel server = null;
    //private SocketChannel socket = null;
    private int port = 6465;
    private int maxConnection = 20;
    private String host;
    private boolean streamMode;
    private boolean blocking = true;
    private SelectionKey acceptKey;
    private InetSocketAddress socketAddr;
    private IExecutor executor;
    
    protected void syncRead(SocketChannel channel) throws Exception {
    	if(streamMode) {
    		trigger(channel.socket().getInputStream());
    		return;
    	}
    	ObjectInputStream ois = null;
	    try {
	    	ois = new ObjectInputStream(
	                           new BufferedInputStream(channel.socket().getInputStream()));
	        while(true) {
				Object event = ois.readObject();
				trigger(event);
	        }
	    }
	    finally {
	        if (ois != null) {
	           try {
	              ois.close();
	           } catch(Exception e) {}
	        }
	        channel.close();
	    }
    }
    
    protected void asynRead(SocketChannel channel) throws Exception {
    	channel.close();
    	throw new RuntimeException("Non-block read is not supported by " + getClass().getName());
    }
    
    protected void onData(SocketChannel channel) {
	    try {
	    	if(blocking)
	    		syncRead(channel);
	    	else
	    		asynRead(channel);
	    }
	    catch(java.io.EOFException e) {
	    	//log().debug("Socket is closed by client.");
	    } catch(java.net.SocketException e) {
	    	log().info(e);
	    } catch(IOException e) {
	        log().info(e);
	    }
	    catch(Exception e) {
	    	log().error(e, e);
	    }
    }
    
    protected SocketChannel onConnect(SelectionKey key) throws IOException {
    	ServerSocketChannel channel = (ServerSocketChannel) key.channel();
    	return (SocketChannel) channel.accept();
    }
    
	@Override
	public void execute(Object task) throws Exception {
		onData((SocketChannel)task);
	}
	
	protected WrappedActiveModule module = new WrappedActiveModule(this);
	
	@Override
	public void run() {
		try {
			if(acceptKey.selector().select() > 0 )
			{	
				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> it = readyKeys.iterator();
	
				while (it.hasNext()) {
					SelectionKey key = (SelectionKey)it.next();
					it.remove();
	                if(key.isValid()) {
						if (key.isAcceptable()) {
							SocketChannel socket = onConnect(key);
							if(null != socket) {
								socket.configureBlocking(blocking);
								if(!blocking)
									socket.register(selector, SelectionKey.OP_READ);
								else
									executor.execute(socket);
							}
						}
						if (key.isReadable()) {
							onData((SocketChannel)key.channel());
							if(!key.channel().isOpen())
								key.cancel();
						}
	                }
				}
			}
		}
		catch(Throwable e) {
			log().error(e, e);
		}
	}

	public long interval() {
		return 0;
	}

	@Override
	protected void activate() throws ModuleException {
		try {
			selector = Selector.open();
			server = ServerSocketChannel.open();
			server.configureBlocking(false);
			server.socket().bind(socketAddr);
			acceptKey = server.register(selector, SelectionKey.OP_ACCEPT );
			module.activate();
		} catch (Throwable e) {
			throw new ModuleException(this, e);
		}
	}

	@Override
	protected void deactivate() throws ModuleException{
		module.deactivate();
		try {
			server.close();
			selector.close();
		} catch (Throwable e) {
			throw new ModuleException(this, e);
		}
	}

	@Override
	protected void setup() throws ModuleException {
		try {
			InetAddress ia;
			if(null != host)
				ia = InetAddress.getByName(host);
			else
				ia = InetAddress.getLocalHost();
			socketAddr = new InetSocketAddress(ia, port);
			if(blocking) {
				executor = new ConcExecutor(this, maxConnection);
				executor.addListener(this);
			}
		} 
		catch (Throwable e) {
			throw new ModuleException(this, e);
		}
	}
	
	public void setAddress(String address) {
		String[] s = address.split(":");
		if(s.length>0) {
			host = s[0];
			if(s.length>1)
				port = Integer.valueOf(s[1]);
		}
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public boolean isBlocking() {
		return blocking;
	}

	public void setBlocking(boolean blocking) {
		this.blocking = blocking;
	}
	
	public void setMode(String mode) {
		streamMode = "stream".equalsIgnoreCase(mode);
	}

	@Override
	public void accept(IEvent event) {
		if(IExecutor.EXEC_ERROR.equals((event.type()))) {
			log().error(event.data());
		}
	}

	@Override
	public int priority() {
		return PRI_DEFAULT;
	}


}
