package com.hp.itis.core2.procengine.triggers;

import java.util.ArrayList;
import java.util.List;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventDispatcher;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.module.CommEvent;
import com.hp.itis.core2.procengine.module.ControllableModule;
import com.hp.itis.core2.procengine.module.EventBus;

abstract public class AsynTrigger extends ControllableModule implements ITrigger {

	protected IEventDispatcher target;
	protected CommData params;
	protected List<String> events = new ArrayList<String>();
	protected boolean syncEvent = false;
	
	public void init(CommData params) throws Exception {
		this.params = params;
		setup();
	}
	
	abstract protected void setup() throws ModuleException;
	
	@Override
	abstract protected void activate() throws ModuleException;

	@Override
	abstract protected void deactivate() throws ModuleException;

	@Override
	public void setEventTarget(IEventDispatcher target) {
		this.target = target;
	}
	
	public void setEvent(String v) {
		String[] tasks = v.split(",");
		for(int i=0; i< tasks.length ;i++)
			events.add(tasks[i].trim());
	}
	
	public void setSyncEvent(boolean v) {
		syncEvent = v;
	}
	
	protected void trigger() {
		trigger(null);
	}
	
	protected void trigger(Object data) {
		if(events.size()>0) {
			for(String event : events)
				sendEvent(event, data);
		}
		else
			sendEvent(null, data);
	}
	
	protected void sendEvent(String t, Object data) {
		if(null != t && !target.hasListener(t))
			return;
		IEvent event = EventBus.createEvent(data, t, syncEvent);
		if(event instanceof CommEvent) {
			CommEvent commEvent = (CommEvent)event;
			CommData params = ProcEngine.instance().updateParams(this.params);
			for(String key : params.keySet()) {
				commEvent.put(key, params.get(key));
			}
		}
		target.dispatch(event);
	}
}
