package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.commdata.TypeCaster;

public class SetResultProc extends DataProcess {

	@Override
	protected boolean execute() throws Exception {
		return TypeCaster.toBoolean(value());
	}

	@Override
	protected void setup() throws Exception {
	}

}
