package com.hp.itis.core2.procengine.triggers;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.snmp4j.CommandResponderEvent;
import org.snmp4j.PDU;
import org.snmp4j.smi.Counter64;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.Null;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.TimeTicks;
import org.snmp4j.smi.UnsignedInteger32;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.FieldMap;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventListener;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.services.SnmpTrapService;

public class SnmpTrapTrigger extends AsynTrigger implements IEventListener {
	
	public static class SnmpTrapEntry {
		private Pattern ipFilter;
		private String oidFilter;
		private String charset = Charset.defaultCharset().name();
		private SnmpTrapTrigger trigger;
		
		private List<String> events = new ArrayList<String>();
		
		public void setIpFilter(String v) {
			ipFilter = Pattern.compile(v);
		}
		
		public void setOidFilter(String v) {
			oidFilter = v;
		}

		public void setCharset(String charset) {
			this.charset = charset;
		}

		public void setTrigger(SnmpTrapTrigger trigger) {
			this.trigger = trigger;
		}

		public void setEvent(String v) {
			String[] tasks = v.split(",");
			for(int i=0; i< tasks.length ;i++)
				events.add(tasks[i].trim());
		}
		

		public void processPdu(CommandResponderEvent trap) {
	        if (trap == null) {
	            return;
	        }
			if(null != ipFilter) {
				if(!ipFilter.matcher(trap.getPeerAddress().toString()).find())
					return;
			}
			
			if(null != oidFilter) {
				String oid = ((VariableBinding)trap.getPDU().getVariableBindings().get(0)).getOid().toString();
				if(!oid.startsWith(oidFilter))
					return;
			}
			sendEvents(parseTrap(trap));
		}
		
		private Map<String, Object> parseTrap(CommandResponderEvent trap)
		{
		    PDU pdu = trap.getPDU();
	        List<?> variables = pdu.getVariableBindings();
	        Map<String, Object> data =  new LinkedHashMap<String, Object>();
	        for(Object o : variables) {
	            VariableBinding binding = (VariableBinding)o;
	            data.put(binding.getOid().toString(), convertVar(binding.getVariable()));
	        }
	        
		   return data;
		}
		
		public Object convertVar(Variable var) {
			if(var instanceof TimeTicks)
				return ((TimeTicks)var).toMilliseconds();
			else if(var instanceof UnsignedInteger32 || var instanceof Counter64)
				return var.toLong();
			else if(var instanceof Integer32)
				return var.toInt();
			else if(var instanceof Null)
				return null;
			else if(var instanceof OctetString) {
				byte[] bytes = ((OctetString)var).toByteArray();
				if(null == charset || "".equals(charset))
					return bytes;
				else {
					try {
						return new String(bytes, charset);
					} catch (UnsupportedEncodingException e) {
						return ((OctetString)var).toASCII(' ');
					}
				}
			}
			else 
				return var.toString();
		}

		protected void sendEvents(Object obj) {
			for(String event : events)
				trigger.sendEvent(event, obj);
		}

	}
	
	private SnmpTrapService snmpTrapService;
	private CommData entryConf;
	private List<SnmpTrapEntry> entries = new ArrayList<SnmpTrapEntry>();

	public void setSnmpTrapService(SnmpTrapService snmpTrapService) {
		this.snmpTrapService = snmpTrapService;
	}

	@Override
	protected void activate() throws ModuleException {
		snmpTrapService.addListener(SnmpTrapService.SNMP_TRAP_EVENT, this);
	}

	@Override
	protected void deactivate() throws ModuleException {
		snmpTrapService.removeListener(SnmpTrapService.SNMP_TRAP_EVENT, this);
	}

	@Override
	protected void setup() throws ModuleException 
	{
		for(Object o : entryConf) {
			if(o instanceof CommData) {
				CommData p = (CommData)o;
				for(String key : params.keySet()) {
					if(!"name".equals(key) && !"class".equals(key) && null == p.get(key))
						p.put(key, params.get(key));
				}
				SnmpTrapEntry entry = null;
				try {
					if(null != p.get("class"))
						entry = (SnmpTrapEntry) ProcEngine.instance().createObject(p);
					else
						entry = (SnmpTrapEntry) ProcEngine.instance().createObject(SnmpTrapEntry.class, p);
				}
				catch(Exception e) {
					throw new ModuleException(this, e);
				}
				if(null != entry) {
					entry.setTrigger(this);
					entries.add(entry);
				}
			}
		}
	}

	@Override
	public void accept(IEvent event) {
		for(SnmpTrapEntry entry : entries)
			entry.processPdu((CommandResponderEvent)event.data());
	}

	@Override
	public int priority() {
		return 0;
	}
	
	public void sendEvent(String t, Object data) {
		super.sendEvent(t, data);
	}

	@FieldMap("Entry")
	public void setEntry(CommData conf) throws Exception {
		entryConf = conf;
	}

}
