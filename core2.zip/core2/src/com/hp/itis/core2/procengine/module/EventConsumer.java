package com.hp.itis.core2.procengine.module;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Pattern;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.event.EventListener;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.procengine.IEventConsumer;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.executor.Executor;
import com.hp.itis.core2.procengine.executor.IExecutable;
import com.hp.itis.core2.procengine.executor.IExecutor;
import com.hp.itis.core2.vars.ExprEvaluator;
import com.hp.itis.core2.vars.IEvaluator;

abstract public class EventConsumer extends ControllableModule implements IEventConsumer, IExecutable {

	protected IExecutor executor;
	protected Set<String> events = new LinkedHashSet<String>();
	protected Pattern eventFilter = null;
	protected IEvaluator condition = null;
	protected int priority = defPriority();
	
	protected int defPriority() {
		return PRI_DEFAULT;
	}

	public void init(CommData params) throws Exception {
		if(null != name())
			events.add(name());
		executor =  (IExecutor)ProcEngine.instance().createObject(Executor.class, params);
		executor.setExecutable(this);
		executor.addListener(new EventListener(){

			@Override
			public void accept(IEvent event) {
				dispatch(event);
				if(IExecutor.EXEC_ERROR.equals(event.type())) {
					log().error(event.data(), (Throwable)(event.data()));
				}
				else if(IExecutor.EXEC_DONE.equals(event.type())) {
					
				}
			}
			
		});
	}
	
	@Override
	public void accept(IEvent event) {		
		try {
			if(!isEnable())
				return;
			if(null != eventFilter && !eventFilter.matcher(event.type()).find())
				return;
			if(null != condition && !TypeCaster.toBoolean(condition.eval(new EventVars(event))))
				return;
			executor.execute(event);
		} catch (Exception e) {
			log().error(e, e);
		}
	}

	@Override
	protected void activate() throws ModuleException {
		executor.setActive(true);
	}
	@Override
	protected void deactivate() throws ModuleException {
		executor.setActive(false);
	}
	
	public void setEvent(String v) {
		String[] ll = v.split(",");
		for(int i=0; i<ll.length; i++)
			events.add(ll[i].trim());
	}
	
	public void setPriority(String v) {
		if("high".equals(v))
			priority = PRI_HIGH;
		else if("higher".equals(v))
			priority = PRI_HIGHER;
		else if("lower".equals(v))
			priority = PRI_LOWER;
		else if("low".equals(v))
			priority = PRI_LOW;
		else
			priority = TypeCaster.cast(v, PRI_DEFAULT);
	}
	
	public void setEventFilter(String v) {
		eventFilter = Pattern.compile(v);
	}

	@Override
	public Set<String> events() {
		return events;
	}

	@Override
	public void execute(Object task) {
		IEvent event = (IEvent)task;
		if(event.sync()) {
			synchronized(event) {
				onEvent(event);
			}
		}
		else
			onEvent(event);
	}
	
	@Override
	public int priority() {
		return priority;
	}
	
	public void setCondition(String value) {
		if(null != value)
			this.condition = ExprEvaluator.build(value);
	}
	
	public abstract void onEvent(IEvent event);


}
