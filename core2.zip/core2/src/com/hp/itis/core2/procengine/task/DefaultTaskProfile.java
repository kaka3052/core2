package com.hp.itis.core2.procengine.task;

public class DefaultTaskProfile implements ITaskProfile {

	@Override
	public void procBegin(ISession session, IProcess process) {
	}

	@Override
	public void procEnd(ISession session, IProcess process) {
		session.log().debug(30001, String.valueOf(session.result()), session.procDuration());
	}

	@Override
	public void procError(ISession session, IProcess process, Throwable e) {
		session.log().error(e, e);
	}

	@Override
	public void taskBegin(ISession session, ITask task) {
		session.log().debug(20001);
	}

	@Override
	public void taskEnd(ISession session, ITask task) {
		session.log().debug(20002, String.valueOf(session.result()), session.duration());
	}

}
