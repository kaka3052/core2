package com.hp.itis.core2.procengine.processes;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.Charset;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Node;

import com.hp.itis.core2.file.TextFile;

public class XsltConvertProc extends DataProcess {

	private String xslt;
	private String outputMode;
	private String outputFile = "result.data";
	private String charset = Charset.defaultCharset().name();
	
	public void setXslt(String xslt) {
		this.xslt = xslt;
	}
	
	public void setCharset(String charset) {
		this.charset = charset;
	}
	
	public String getOutputMode() {
		return outputMode;
	}

	public void setOutputMode(String outputMode) {
		this.outputMode = outputMode;
	}

	public String getOutputFile() {
		return outputFile;
	}

	public void setOutputFile(String outputFile) {
		this.outputFile = outputFile;
	}

	@Override
	protected boolean execute() throws Exception {
		return false;
	}

	@Override
	protected void setup() throws Exception {
		
	}
	
	public boolean execute(Node xml) throws Exception {
		String om = outputMode;
		if(null == om)
			om = "dom";
		Object r = transform(new DOMSource(xml), om);
		value(r);
		return true;
	}
	
	public boolean execute(String xml) throws Exception {
		String om = outputMode;
		if(null == om)
			om = "text";
		Object r = transform(new StreamSource(new ByteArrayInputStream(xml.getBytes(charset))), om);
		value(r);
		return true;
	}
	
	public boolean execute(File file) throws Exception {
		String om = outputMode;
		if(null == om)
			om = "file";
		Object r = transform(new StreamSource(new FileInputStream(file)), om);
		value(r);
		return true;
	}
	
	private Object transform(Source source, String mode) throws Exception {
		Source xsltSource = new StreamSource(TextFile.getResource(xslt));
		if("text".equals(mode)) {
		    ByteArrayOutputStream oStream = new ByteArrayOutputStream();
		    Result result = new StreamResult(oStream);
		    TransformerFactory transFact = TransformerFactory.newInstance();
		    Transformer trans = transFact.newTransformer(xsltSource);
		    trans.transform(source, result);
		    return new String(oStream.toByteArray(), charset);
		}
		else if("file".equals(mode)) {
			File file = session().getSessionFile(outputFile);
			FileOutputStream oStream = new FileOutputStream(file);
		    Result result = new StreamResult(oStream);
		    TransformerFactory transFact = TransformerFactory.newInstance();
		    Transformer trans = transFact.newTransformer(xsltSource);
		    trans.transform(source, result);
		    return file;
		}
		else {
		    DOMResult result = new DOMResult();
		    TransformerFactory transFact = TransformerFactory.newInstance();
		    Transformer trans = transFact.newTransformer(xsltSource);
		    trans.transform(source, result);
		    return result.getNode();
		}
	}
}
