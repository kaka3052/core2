package com.hp.itis.core2.procengine.module;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class JobContainer implements IJobContainer {
	
	private Map<String, IJob> jobs = Collections.synchronizedMap(new LinkedHashMap<String, IJob>());

	@Override
	public void clear() {
		jobs.clear();
	}

	@Override
	public void remove(IJob job) {
		jobs.remove(job.jobId());
	}
	
	@Override
	public void remove(String jobId) {
		jobs.remove(jobId);
	}

	@Override
	public void update(IJob job) {
		jobs.put(job.jobId(), job);
	}

	@Override
	public Iterator<IJob> iterator() {
		return jobs.values().iterator();
	}

	@Override
	public IJob getJob(String jobId) {
		return jobs.get(jobId);
	}

	@Override
	public void reload() {
		clear();
		init();
	}

	@Override
	public void init() {
		
	}
}
