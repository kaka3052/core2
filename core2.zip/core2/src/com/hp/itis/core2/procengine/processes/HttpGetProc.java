package com.hp.itis.core2.procengine.processes;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import com.hp.itis.core2.file.FileOperate;
import com.hp.itis.core2.file.TextFile;
import com.hp.itis.core2.misc.StrUtil;

public class HttpGetProc extends DataProcess {

	protected String url;
	protected Proxy proxy;
	protected String method = "GET";
	protected int timeout = 0;
	protected String resultKey;
	protected String outputFile = "response.data";
	protected Object request;
	protected String requestFile;
	protected String contentAs;
	protected String charset;

	@Override
	protected boolean execute() throws Exception {
		String url = evalValue(this.url).toString();
		if ("GET".equalsIgnoreCase(method)) {
			String qs = buildQueryString();
			if (null != qs && qs.length() > 0) {
				if (url.indexOf('?') > 0)
					url = url + '&' + qs;
				else
					url = url + '?' + qs;
			}
		}
		URL httpUrl = new URL(url);
		HttpURLConnection connection;
		if (null != proxy)
			connection = (HttpURLConnection) (httpUrl.openConnection(proxy));
		else
			connection = (HttpURLConnection) (httpUrl.openConnection());
		if (null != method)
			connection.setRequestMethod(method);
		if (timeout > 0)
			connection.setConnectTimeout(timeout);
		for (String key : params.keySet()) {
			String name = getHeaderName(key);
			if (null != name) {
				Object value = evalValue(params.get(key));
				connection.setRequestProperty(name, value.toString());
			}
		}
		try {
			InputStream requestIs = getRequestStream();
			if (null != requestIs) {
				connection.setDoOutput(true);
				FileOperate.copyStream(requestIs, connection.getOutputStream());
			} else if ("POST".equalsIgnoreCase(method)) {
				String qs = buildQueryString();
				if (null != qs && qs.length() > 0) {
					byte[] bs;
					if (null != charset)
						bs = qs.toString().getBytes(charset);
					else
						bs = qs.toString().getBytes();
					requestIs = new ByteArrayInputStream(bs);
					connection.setRequestProperty("Content-Type",
							"application/x-www-form-urlencoded");
					connection.setRequestProperty("Content-Length",
							String.valueOf(bs.length));
					connection.setDoOutput(true);
					FileOperate.copyStream(requestIs,
							connection.getOutputStream());
				}
			}
			boolean result = connection.getResponseCode() == HttpURLConnection.HTTP_OK;
			session().log().debug(
					connection.getResponseCode() + " "
							+ connection.getResponseMessage());
			if (!result) {
				session().report(
						new Exception(connection.getResponseCode() + " "
								+ connection.getResponseMessage()));
				return result;
			}
			String contentType = connection.getContentType();
			if (null == contentType)
				contentType = charset;
			String contentAs = this.contentAs;
			if (null != contentType) {
				if (null == contentAs && null != contentType) {
					if (contentType.contains("xml"))
						contentAs = "xml";
					else if (contentType.contains("text"))
						contentAs = "text";
				}
			}
			if ((null == contentAs) && (null != outputFile))
				contentAs = "file";
			InputStream is = (InputStream) connection.getContent();
			Object content = null;
			if ("file".equals(contentAs)) {
				File file = session().getSessionFile(outputFile);
				OutputStream os = new FileOutputStream(file);
				result = FileOperate.copyStream(is, os) > 0;
				content = file;
			} else if ("text".equals(contentAs)) {
				content = TextFile.load(is, connection.getContentEncoding());
			} else if ("xml".equals(contentAs)) {
				DocumentBuilderFactory dbf = DocumentBuilderFactory
						.newInstance();
				DocumentBuilder db = dbf.newDocumentBuilder();
				content = db.parse(is);
			} else {
				content = is;
			}
			if (null != content) {
				if (null != resultKey)
					session().values().put(resultKey, content);
				else
					value(content);
			}
			return result;
		} finally {
			if (null != connection)
				connection.disconnect();
		}
	}

	private String getQueryName(String key) {
		if (null == key)
			return null;
		if (key.startsWith("$"))
			return key.substring(1);
		if (!key.startsWith(":"))
			return key;
		return null;
	}

	private String getHeaderName(String key) {
		if (null == key)
			return null;
		if (key.startsWith(":"))
			return key.substring(1);
		if (key.length() > 0) {
			char lc = key.charAt(0);
			if (lc >= 'A' && lc <= 'Z')
				return key;
		}
		return null;
	}

	private String buildQueryString() throws UnsupportedEncodingException {
		StringBuilder sb = new StringBuilder();
		for (String key : params.keySet()) {
			String name = getQueryName(key);
			if (null == name)
				continue;
			Object value = this.evalValue(params.get(key));
			if (null != charset)
				value = URLEncoder.encode(value.toString(), charset);
			else
				value = URLEncoder.encode(value.toString(), charset);
			if (sb.length() > 0)
				sb.append('&');
			else {
				sb.append(name);
				sb.append('=');
				sb.append(value);
			}
		}
		return sb.toString();
	}

	private InputStream getRequestStream() throws Exception {
		if (null != request) {
			if (request instanceof InputStream)
				return (InputStream) request;
			else if (request instanceof File)
				return new FileInputStream((File) request);
			else {
				if (null != charset)
					return new ByteArrayInputStream(request.toString()
							.getBytes(charset));
				else
					return new ByteArrayInputStream(request.toString()
							.getBytes());
			}
		} else if (null != requestFile) {
			return new FileInputStream(session().getSessionFile(requestFile));
		}
		return null;
	}

	@Override
	protected void setup() throws Exception {
	}

	public void setUrl(String url) throws MalformedURLException {
		this.url = url;
	}

	public void setProxy(String proxy) {
		try {
			Proxy.Type proxyType = Proxy.Type.HTTP;
			Matcher m = Pattern.compile("((.+?)://)?(.*?)(:(\\d+))").matcher(
					proxy);
			if (!m.find())
				throw new Exception();
			String protocal = m.group(2);
			if (null != protocal)
				proxyType = Proxy.Type.valueOf(protocal.toUpperCase());
			String host = m.group(3);
			int port = Integer.valueOf(m.group(5));
			this.proxy = new Proxy(proxyType, new InetSocketAddress(host, port));
		} catch (Throwable e) {
			throw new RuntimeException("Illegel proxy setting: " + proxy);
		}
	}

	public void setMethod(String v) {
		method = v.toUpperCase();
	}

	public void setTimeout(String v) {
		timeout = (int) StrUtil.str2Millisec(v);
	}

	public void setResultkey(String v) {
		this.resultKey = v;
	}

	public void setOutputFile(String v) {
		outputFile = v;
	}

	public void setRequest(Object v) {
		request = v;
	}

	public void setRequestFile(String v) {
		requestFile = v;
	}

	public void setCharset(String v) {
		charset = v;
	}

	public void setContentAs(String contentAs) {
		this.contentAs = contentAs;
	}

}
