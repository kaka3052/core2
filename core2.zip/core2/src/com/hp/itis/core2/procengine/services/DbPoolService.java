package com.hp.itis.core2.procengine.services;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.db.SimpleDbConnPool;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.module.Service;

public class DbPoolService extends Service implements DataSource {
	
	private SimpleDbConnPool instance;
	
	public void init(CommData params) {
		instance = new SimpleDbConnPool(
				params.getString("driver"),
				params.getString("url"),
				params.getString("user"),
				params.getString("password")
				);
	}

	@Override
	public Connection getConnection() throws SQLException {
		return instance.getConnection();
	}

	@Override
	public void start() throws ModuleException {
	}

	@Override
	public void stop() throws ModuleException {
		instance.close();
	}

	@Override
	public Connection getConnection(String username, String password)
			throws SQLException {
		return instance.getConnection(username, password);
	}

	@Override
	public PrintWriter getLogWriter() throws SQLException {
		return instance.getLogWriter();
	}

	@Override
	public int getLoginTimeout() throws SQLException {
		return instance.getLoginTimeout();
	}

	@Override
	public void setLogWriter(PrintWriter out) throws SQLException {
		instance.setLogWriter(out);
	}

	@Override
	public void setLoginTimeout(int seconds) throws SQLException {
		instance.setLoginTimeout(seconds);
	}

	@Override
	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		return instance.isWrapperFor(iface);
	}

	@Override
	public <T> T unwrap(Class<T> iface) throws SQLException {
		return instance.unwrap(iface);
	}

}
