package com.hp.itis.core2.procengine.executor;



/**
 * 异步并发执行器
 * @author changjiang
 *
 */
public class AscoExecutor extends AsynExecutor {

	IExecutor concExecutor;
	public AscoExecutor(IExecutable exec, int queueSize, boolean queuePersistent, int maxConc) throws Exception
	{
		super(exec, queueSize, queuePersistent);
		concExecutor = new ConcExecutor(exec, maxConc);
	}
	
	/**
	 * 覆盖AsynExecutor的doExecute方法为并发执行
	 */
	protected void doExecute(Object task) throws Exception
	{
		concExecutor.execute(task);
	}
	
	@Override
	public void setExecutable(IExecutable exec) {
		super.setExecutable(exec);
		concExecutor.setExecutable(exec);
	}

}
