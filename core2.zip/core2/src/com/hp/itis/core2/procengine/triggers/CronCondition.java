package com.hp.itis.core2.procengine.triggers;

import java.text.ParseException;
import java.util.Date;

import org.quartz.CronExpression;

import com.hp.itis.core2.misc.SException;

public class CronCondition extends TriggerCondition {

	private CronExpression cronExpression; 
	private Date nextValidTime;
	
	@Override
	protected Object doCheck() {
		Date now = new Date();
		if(nextValidTime.getTime()<=now.getTime()) {
			updateNext();
			return true;
		}
		return false;
	}

	@Override
	protected void setup() throws SException {
		updateNext();
	}

	public void setTest(String v) throws ParseException {
		cronExpression = new CronExpression(v);
	}
	
	private void updateNext() {
		nextValidTime = cronExpression.getNextValidTimeAfter(new Date());
	}
}
