package com.hp.itis.core2.procengine.module;

public interface IJob {
	/**
	 * return the job identifier
	 * @return
	 */
	String jobId();
	/**
	 * check job to determine if it need to execute now
	 * @return 
	 */
	boolean schedule();
	/**
	 * execute the job
	 * @return
	 */
	Object execute();
}
