package com.hp.itis.core2.procengine.executor;


public interface IExecutable {
	void execute(Object task) throws Exception;
}
