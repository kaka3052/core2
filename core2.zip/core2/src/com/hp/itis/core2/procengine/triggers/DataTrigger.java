package com.hp.itis.core2.procengine.triggers;

import java.util.ArrayList;
import java.util.List;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.FieldMap;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.module.IDataProvider;
import com.hp.itis.core2.procengine.module.IDataReceiver;
import com.sun.net.httpserver.HttpExchange;

public class DataTrigger extends AsynTrigger implements IDataReceiver {

	public static class DataEntry implements IDataReceiver {

		private DataTrigger dataTrigger;
		private List<String> events = new ArrayList<String>();
		
		@Override
		public void onData(Object data) {
			sendEvents(data);
		}
		
		public void setProvider(IDataProvider dataProvider) {
			dataProvider.setReceiver(this);
		}
		
		public void setDataTrigger(DataTrigger dataTrigger) {
			this.dataTrigger = dataTrigger;
		}
		
		protected void sendEvents(Object data) {
			for(String event : events)
				dataTrigger.sendEvent(event, data);
		}
		
		public void setEvent(String v) {
			String[] tasks = v.split(",");
			for(int i=0; i< tasks.length ;i++)
				events.add(tasks[i].trim());
		}

		protected void sendEvents(HttpExchange hex) {
			for(String event : events)
				dataTrigger.sendEvent(event, hex);
		}
		
	}
	 
	private CommData entryConf;
	private List<DataEntry> entries = new ArrayList<DataEntry>();
	
	public void setProvider(IDataProvider dataProvider) {
		dataProvider.setReceiver(this);
	}
	
	@Override
	protected void activate() throws ModuleException {
		
	}

	@Override
	protected void deactivate() throws ModuleException {
		
	}

	@Override
	protected void setup() throws ModuleException {
		for(Object o : entryConf) {
			if(o instanceof CommData) {
				CommData p = (CommData)o;
				for(String key : params.keySet()) {
					if(!"name".equals(key) && !"class".equals(key) && null == p.get(key))
						p.put(key, params.get(key));
				}
				DataEntry entry = null;
				try {
					if(null != p.get("class"))
						entry = (DataEntry) ProcEngine.instance().createObject(p);
					else
						entry = (DataEntry) ProcEngine.instance().createObject(DataEntry.class, p);
				}
				catch(Exception e) {
					throw new ModuleException(this, e);
				}
				if(null != entry) {
					entry.setDataTrigger(this);
					entries.add(entry);
				}
			}
		}
	}

	@Override
	public void onData(Object data) {
		if(isActive())
			trigger(data);
	}
	
	@FieldMap("Entry")
	public void setEntry(CommData conf) throws Exception {
		entryConf = conf;
	}

}
