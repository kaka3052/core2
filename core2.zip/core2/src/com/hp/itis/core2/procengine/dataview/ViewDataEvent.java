package com.hp.itis.core2.procengine.dataview;

import java.util.Date;

import com.hp.itis.core2.procengine.module.CommEvent;

public class ViewDataEvent<T> extends CommEvent implements IViewDataEvent<T> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5499380068518786883L;

	public ViewDataEvent(T data) {
		super(data.getClass().getSimpleName(), data);
	}
	
	public ViewDataEvent(String type, T data) {
		super(type, data);
	}
	
	@Override
	public Date arisingTime() {
		return new Date(timestamp());
	}

	@SuppressWarnings("unchecked")
	public T getData() {
		return (T)data;
	}

	public void setData(T data) {
		this.data = data;
	}

}
