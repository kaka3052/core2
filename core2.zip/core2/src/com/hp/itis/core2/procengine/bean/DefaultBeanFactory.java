package com.hp.itis.core2.procengine.bean;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.FieldMap;

public class DefaultBeanFactory implements IBeanFactory {
	
	private BeanBuilder beanBuilder;
	private List<IBeanFactory> factorys = new ArrayList<IBeanFactory>();
	private Map<String, Object> beans = new LinkedHashMap<String, Object>();
	
	@Override
	public Object getBean(String name) {
		Object bean = beans.get(name);
		if(null == bean) {
			for(IBeanFactory factory :factorys) {
				bean = factory.getBean(name);
				if(null != bean)
					break;
			}
		}
		return bean;
	}

	@Override
	public Object getBean(String name, Class<?> c) {
		Object bean = getBean(name);
		if(c.isInstance(bean))
			return bean;
		return null;
	}

	@Override
	public Object getBean(Class<?> c) {
		Object bean = null;
		for(Object b : beans.values()) {
			if(c.isInstance(b)) {
				bean = b;
				break;
			}
		}
		if(null == bean)
			for(IBeanFactory factory :factorys) {
				bean = factory.getBean(c);
				if(null != bean)
					break;
			}
		return bean;
	}

	@Override
	public Collection<?> getBeans(Class<?> c) {
		Set<Object> result = new HashSet<Object>();
		for(Object bean : beans.values()) {
			if(c.isInstance(bean))
				result.add(bean);
		}
		for(IBeanFactory factory :factorys) {
			result.addAll(factory.getBeans(c));
		}
		return result;
	}

	@FieldMap("Bean")
	public void setBean(CommData cd) throws Exception {
		for(Object o : cd) {
			if(o instanceof CommData) {
				CommData conf = (CommData)o;
				String name = conf.getString("name");
				if(null == name || beans.containsKey(name))
					return;
				o = beanBuilder.createObject(conf);
				beans.put(name, o);
				if(o instanceof IBeanFactory) {
					factorys.add((IBeanFactory)o);
				}
			}
		}
	}
	
	@FieldMap("Import")
	public void setImport(CommData cd) throws Exception {
		for(Object o : cd) {
			String className = (String)o;
			if(null != className)
				beanBuilder.importClass(className);
		}
	}
	
	public void setPackages(String packages) {
		if(null != packages) {
			String[]sl = packages.split(",");
			for(int i=0; i<sl.length; i++) {
				String ss = sl[i];
				ss = ss.trim();
				if(ss.endsWith("."))
					ss += "*";
				else if(!ss.endsWith(".*"))
					ss += ".*";
				beanBuilder.importClass(ss);
			}
		}
	}
	
}
