package com.hp.itis.core2.procengine.task;

public class DefaultFilterProfile extends DefaultTaskProfile {

	@Override
	public void taskBegin(ISession session, ITask task) {
		session.log().debug(20003);
	}

	@Override
	public void taskEnd(ISession session, ITask task) {
		session.log().debug(20004, String.valueOf(session.result()), session.duration());
	}

}
