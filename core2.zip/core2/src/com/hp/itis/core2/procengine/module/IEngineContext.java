package com.hp.itis.core2.procengine.module;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.procengine.bean.IBeanBuilder;
import com.hp.itis.core2.procengine.bean.IBeanFactory;
import com.hp.itis.core2.vars.IFunVars;
import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.IWritableVars;

public interface IEngineContext extends IBeanFactory, IWritableVars, IFunVars, IBeanBuilder {
	void addVars(IVars vars);
	IVars getFunVars();
	void addBeanFactory(IBeanFactory factory);
	void removeBeanFactory(IBeanFactory factory);
	CommData updateParams(CommData params);
	CommData updateParams(CommData params, IVars vars);
	ClassLoader getClassLoader();
}
