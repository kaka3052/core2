package com.hp.itis.core2.procengine.module;

import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventListener;
import com.hp.itis.core2.procengine.IEventProducer;

public interface IInteractiveModule extends IEventListener, IEventProducer {
	void sendEvent(IEvent event);
}
