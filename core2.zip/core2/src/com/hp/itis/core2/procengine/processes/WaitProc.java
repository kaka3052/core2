package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.event.EventCondition;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventCondition;
import com.hp.itis.core2.misc.StrUtil;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.vars.AutomaticVars;
import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.ExprEvaluator;
import com.hp.itis.core2.vars.IEvaluator;

public class WaitProc extends DataProcess {

	private long timeout = 1000;
	private IEvaluator condExpr;
	private IEventCondition eventCondition;
	
	private class WaitEventCondition extends EventCondition {
		
		public WaitEventCondition(String eventType) {
			super(eventType);
		}
		
		@Override
		public boolean filter(IEvent event) {
			if(null == condExpr)
				return true;
			CombinedVars vars = new CombinedVars(new AutomaticVars(event));
			if(null != event.data())
				vars.add(new AutomaticVars(event.data()));
			return TypeCaster.toBoolean(condExpr.eval(vars));
		}
		
	}
	
	@Override
	protected boolean execute() throws Exception {
		
		try {
			if(null != eventCondition) {
				ProcEngine.instance().waitEvent(eventCondition, timeout);
			}
			else
				Thread.sleep(timeout);
		} catch (InterruptedException e) {
		}
		return true;
	}

	@Override
	protected void setup() throws Exception {
		
	}
	
	public void setTimeout(String timeout) {
		this.timeout = StrUtil.str2Millisec(timeout);
	}
	
	public void setEvent(String event) {
		eventCondition = new WaitEventCondition(event);
	}
	
	public void setEventCondition(String condition) {
		condExpr = ExprEvaluator.build(condition);
	}
}
