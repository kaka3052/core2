package com.hp.itis.core2.procengine.triggers;

import com.hp.itis.core2.misc.SException;

public class TrueCondition extends TriggerCondition {

	@Override
	protected Object doCheck() {
		return true;
	}

	@Override
	protected void setup() throws SException {

	}

}
