package com.hp.itis.core2.procengine.services;

import java.io.IOException;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.module.Service;
import com.hp.itis.core2.vars.FilePersistentVars;
import com.hp.itis.core2.vars.IPersistentVars;

public class FileVarService extends Service implements IPersistentVars {

	private IPersistentVars vars = null;
	private String filePath = "vars.data";
	
	public void init(CommData params) throws Exception {
		try {
			vars = new FilePersistentVars(filePath);
		} catch (IOException e) {
			throw new ModuleException(this, e);
		}
	}
	
	public void setFilePath(String v) {
		filePath = v;
	}
	
	@Override
	public void load() throws Exception {
		vars.load();
	}

	@Override
	public void save() throws Exception {
		vars.save();
	}

	@Override
	public void put(String key, Object value) {
		vars.put(key, value);
	}

	@Override
	public Object get(String key) {
		return vars.get(key);
	}

	@Override
	public void start() throws ModuleException {

	}

	@Override
	public void stop() throws ModuleException {
		try {
			vars.save();
		} catch (Exception e) {
		}
	}
	
}
