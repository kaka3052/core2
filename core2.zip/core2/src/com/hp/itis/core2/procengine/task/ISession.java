package com.hp.itis.core2.procengine.task;

import java.io.File;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.misc.PLog;
import com.hp.itis.core2.procengine.module.IModule;
import com.hp.itis.core2.vars.IVars;

public interface ISession {
	
	String KEY_VALUE = "_VALUE";

	IEvent event();
	/**
	 * 取得会话ID
	 * @return
	 */
	String sessionID();

	/**
	 * 取得会话开始时间
	 */
	long startTime();

	/**
	 * 取得会话经历时长
	 */
	long duration();

	/**
	 * 取得当前过程经历时长
	 */
	long procDuration();

	/**
	 * 会话是否结束
	 */
	boolean finished();
	
	/**
	 * 阻塞当前线程等待会话结束
	 */
	void waitToFinish();

	/**
	 * 取得当前任务会话变量
	 * @return 会话变量
	 */
	CommData values();

	/**
	 * 取得当前任务Object
	 * @return Object
	 */
	Object value();
	
	Object value(Class<?> clazz);
	
	void value(Object v);

	/**
	 * 取得当前任务会话变量表
	 * @return 会话变量表
	 */
	IVars vars();

	/**
	 * 获取当前日志对象
	 * 
	 * @return 日志对象
	 */
	PLog log();

	/**
	 * 上报过程结果
	 * @param result 过程结果
	 */
	void report(boolean result);
	
	/**
	 * 上报出错结果
	 * @param result 异常
	 */
	void report(Throwable e);

	/**
	 * 任务执行结果
	 * @return
	 */
	boolean result();

	/**
	 * 结束本次任务
	 */
	void end();
	
	/**
	 * 返回最后一个异常对象
	 * @return
	 */
	Throwable lastError();
	
	/**
	 * 当前执行模块
	 * @return
	 */
	IModule currentModule();
	
	Object deriveValue();
	
	File getSessionFile(String fileName);
	
	File getSessionDir();
	
	void deleteSessionDir();
	
}
