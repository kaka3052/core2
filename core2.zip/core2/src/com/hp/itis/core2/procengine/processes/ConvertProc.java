package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.util.DataConvertor;
import com.hp.itis.core2.vars.AutomaticVars;
import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.IVars;

public class ConvertProc extends DataProcess {

	private String config;
	private IVars vars = ProcEngine.instance();
	private DataConvertor convertor ;
	private Class<?> destClass;
	private Object dest;
	
	public void setConfig(String config) {
		this.config = config;
	}
	
	public void setDestClass(String destClass) throws ClassNotFoundException {
		this.destClass = ProcEngine.instance().getClass(destClass);
	}
	
	public void setDest(Object v) {
		dest = v;
	}
	
	public void setVars(Object o) {
		IVars vars;
		if(o instanceof IVars)
			vars = (IVars)o;
		else
			vars = new AutomaticVars(o);
		this.vars = new CombinedVars(vars, ProcEngine.instance());
	}

	@Override
	protected boolean execute() throws Exception {
		Object v = null;
		if(null != convertor) {
			if(null != dest)
				v = convertor.convert(value(), dest);
			else if(null == destClass)
				v = convertor.convert(value());
			else
				v = convertor.convert(value(), destClass.newInstance());
		}
		else {
			if(null == destClass)
				v = dest;
			else
				v = DataConvertor.cast(value(), destClass);
		}
		value(v);
		return true;
	}

	@Override
	protected void setup() throws Exception {
		if(null != config)
			convertor = new DataConvertor(config, vars);
	}

}
