package com.hp.itis.core2.procengine.services;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.rmi.Naming;
import java.rmi.Remote;
import java.rmi.RemoteException;

public class RmiProxy implements InvocationHandler {
	
	public static final String KEY_BASEURI = "rim.proxy.baseuri";
	private Class<? extends Remote> remoteInterface;
	private String baseUri = null;
	private Remote remote;
	
	private RmiProxy(Class<? extends Remote> remoteInterface) {
		this.remoteInterface = remoteInterface;
	}
	
	public static Object newInstance(Class<? extends Remote> remoteInterface) {
		return newInstance(remoteInterface, null);
	}
	
	public static Object newInstance(Class<? extends Remote> remoteInterface, String baseUri) {
		RmiProxy handler = new RmiProxy(remoteInterface);
		if("".equals(baseUri))
			baseUri = null;
		if(null == baseUri) {
			String defBaseUri = System.getProperty(KEY_BASEURI);
			if(null != defBaseUri)
				baseUri = defBaseUri;
		}
		if(null != baseUri && !baseUri.endsWith("/"))
			baseUri += "/";
		handler.baseUri = baseUri;
		return Proxy.newProxyInstance(remoteInterface.getClassLoader(), new Class<?>[]{remoteInterface}, handler);
	}

	public void bind() {
		try {
			if(null == baseUri)
				remote = Naming.lookup(remoteInterface.getSimpleName());
			else
				remote = Naming.lookup(baseUri + remoteInterface.getSimpleName());
		} catch (Exception e) {
			
		}
	}
	
	public void tryBind() {
		if(null == remote)
			bind();
	}
	
	@Override
	public Object invoke(Object proxy, Method method, Object[] args)
			throws Throwable {
		try {
			return _invoke(proxy, method, args);
		} catch (Throwable e) {
			if(!(e instanceof RemoteException)) {
				remote = null;
				return _invoke(proxy, method, args);
			}
			throw e;
		}
	}
	
	private Object _invoke(Object proxy, Method method, Object[] args) throws Throwable {
		tryBind();
		if(null != remote) {
			Method rMethod = remote.getClass().getMethod(method.getName(), method.getParameterTypes());
			return rMethod.invoke(remote, args);
		}
		else
			throw new Exception("Remote service [" + remoteInterface + "] is not bound.");
	}

}
