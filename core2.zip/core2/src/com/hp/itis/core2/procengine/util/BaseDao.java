package com.hp.itis.core2.procengine.util;

import java.util.List;

import com.hp.itis.core2.commdata.CommData;

public class BaseDao<E> {

	//private CommData params;
	
	public void init(CommData params) {
		
	}
	
	public List<E> queryList(String sqlKey) {
		return null;
	}
	
	public E query(String sqlKey) {
		return null;
	}
	
	public int execute(String sqlKey, Object vars) {
		return 0;
	}
	
	public boolean update(String sqlKey, E item) {
		return execute(sqlKey, item)>0;
	}
	
}
