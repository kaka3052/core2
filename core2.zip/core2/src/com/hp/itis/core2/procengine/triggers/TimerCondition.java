package com.hp.itis.core2.procengine.triggers;

import com.hp.itis.core2.misc.StrUtil;
import com.hp.itis.core2.misc.SException;

public class TimerCondition extends TriggerCondition {

	private long interval = 1000;
	private long triggerTime; 
	
	@Override
	protected Object doCheck() {
		if(interval<0)
			return false;
		long current = System.currentTimeMillis();
		boolean result = current - triggerTime >= interval;
		if(result)
			triggerTime = current;
		return result;
	}

	@Override
	protected void setup() throws SException {

	}
	
	public void setTest(String v) {
		interval = StrUtil.str2Millisec(v);
		triggerTime = System.currentTimeMillis();
	}

}
