package com.hp.itis.core2.procengine.processes;


public class SetValuesProc extends DataProcess {

	@Override
	protected void setup() throws Exception {
	}

	@Override
	public boolean execute() throws Exception {
		for(String key : params.keySet()) {
			String value = params.getString(key);
			session().values().put(key, evalValue(value));
		}
		return true;
	}

}
