package com.hp.itis.core2.procengine.module;

import com.hp.itis.core2.event.IEventDispatcher;
import com.hp.itis.core2.misc.PLog;

public interface IModule extends IEventDispatcher {
	void name(String value);
	IModule parent();
	void parent(IModule value);
	String name();
	String fullName();
	PLog log();
}
