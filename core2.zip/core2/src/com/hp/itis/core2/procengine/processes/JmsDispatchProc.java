package com.hp.itis.core2.procengine.processes;

public class JmsDispatchProc extends JmsSendProc {
	public JmsDispatchProc() {
		this.eventName = "";
	}
}
