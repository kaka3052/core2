package com.hp.itis.core2.procengine.util;

import java.util.List;

import org.dom4j.Attribute;
import org.dom4j.Element;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;

public class ConfDigester {
	
	public static final String TAG_KEY = "__TAG";
	public static final String VALUE_KEY = "__VALUE";
	
	public static class PolicyTarget {
		public String cat;
		public String key;
		public Object value;
	}
	
	public static interface DigestPolicy {
		void buildTarget(CommData parent, CommData current, PolicyTarget target);
	}
	
	public static CommData digest(Element conf) {
		return digest(conf, null);
	}
	
	public static CommData digest(Element conf, final DigestPolicy policy) {
		if(null == conf)
			return null;
		CommData data = newData();
		parse(conf, data, new DigestPolicy() {
			@Override
			public void buildTarget(CommData parent, CommData current, PolicyTarget target) {
				target.key = current.getString("name");
				if(null != target.key && !"param".equalsIgnoreCase(current.getString(TAG_KEY)))
					target.cat = current.getString(TAG_KEY);
				if(null == target.key)
					target.key = current.getString(TAG_KEY);
				target.value = current.get("value");
				if(null == target.value)
					target.value = current.get(VALUE_KEY);
				if(null == target.value)
					target.value = current;
				if(null != policy)
					policy.buildTarget(parent, current, target);
			}

		});
		data.put(TAG_KEY, null);
		return data;
	}
	
	@SuppressWarnings("unchecked")
	private static void parse(Element conf, CommData data, DigestPolicy policy) {
		data.put(TAG_KEY, conf.getName());
		if(conf.isTextOnly())
			data.put(VALUE_KEY, conf.getText());
		for(Attribute attr : (List<Attribute>)conf.attributes()) {
			data.put(attr.getName(), attr.getText());
		}
		for(Element item:(List<Element>)conf.elements()) {
			CommData c = newData();
			parse(item, c, policy);
			PolicyTarget target = new PolicyTarget();
			policy.buildTarget(data, c, target);
			c.put(TAG_KEY, null);
			c.put(VALUE_KEY, null);
			CommData cl;
			if(null == target.cat)
				cl = data;
			else {
				cl = data.getChild(target.cat);
				if(null == cl)
					cl = data.add(target.cat);
			}
			if(null == target.key) 
				cl.push(target.value);
			else
				cl.put(target.key, target.value);
		}
	}

	private static CommData newData() {
		return new CommDataImpl();
	}
	
}
