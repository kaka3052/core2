package com.hp.itis.core2.procengine.dataview;

public interface IEventView extends IDataView {
	IViewDataEvent<?> accept(IViewDataEvent<?> event);
}
