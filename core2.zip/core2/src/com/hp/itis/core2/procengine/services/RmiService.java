package com.hp.itis.core2.procengine.services;

import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.module.Service;

public class RmiService extends Service {
	
	public static final int DEF_SVR_PORT = 1099;
	
	private String host;
	private int port = DEF_SVR_PORT;
	private Registry reg;
	private CommData params;

	public void setPort(int port) {
		this.port = port;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}
	
	public void setRegistry(CommData params) {
		this.params = params;
	}
	
	protected void initReg() throws RemoteException {
		if(null == host) {
			try {
				reg = LocateRegistry.getRegistry(port);
				try {
					reg.lookup("");
				} catch (NotBoundException e) {
				}
			} catch (RemoteException e) {
				reg = LocateRegistry.createRegistry(port);
			}
		}
		else {
			reg = LocateRegistry.getRegistry(host, port);
		}
	}

	@Override
	public void start() throws Exception {
		initReg();
		for(String key : params.keySet()) {
			String name = params.get(key, "");
			Object service = ProcEngine.instance().get(name);
			if(null == service)
				throw new Exception("Can not find service named '" + name + "' in context.");
			if(!(service instanceof Remote))
				throw new Exception("The service '" + name + "' is not a Remote object.");
			reg.rebind(key, (Remote)service);
		}
	}

	@Override
	public void stop() throws Exception {
		for(String key : params.keySet()) {
			reg.unbind(key);
		}
	}

}
