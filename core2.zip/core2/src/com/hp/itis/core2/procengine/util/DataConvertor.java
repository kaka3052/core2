package com.hp.itis.core2.procengine.util;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.file.TextFile;
import com.hp.itis.core2.procengine.VarFunLib;
import com.hp.itis.core2.procengine.bean.BeanBuilder;
import com.hp.itis.core2.procengine.bean.IBeanBuilder;
import com.hp.itis.core2.procengine.util.ConfDigester.DigestPolicy;
import com.hp.itis.core2.procengine.util.ConfDigester.PolicyTarget;
import com.hp.itis.core2.vars.AdvanceVarReplacer;
import com.hp.itis.core2.vars.AutomaticVars;
import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.Evaluator;
import com.hp.itis.core2.vars.ExprEvaluator;
import com.hp.itis.core2.vars.IEnumerableVars;
import com.hp.itis.core2.vars.IEvaluator;
import com.hp.itis.core2.vars.IFunVars;
import com.hp.itis.core2.vars.IVarReplacer;
import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.IWritableVars;
import com.hp.itis.core2.vars.MapVars;
import com.hp.itis.core2.vars.MethodVars;
import com.hp.itis.core2.vars.ValuesVars;

public class DataConvertor implements IFunVars {

	private IVars vars = null;
	private static IBeanBuilder beanBuilder = new BeanBuilder();
	private IEvaluator selectExpr;
	private Map<String, List<Rule>> rules = new HashMap<String, List<Rule>>();
	private CommData maps;

	public static class DestSetVars extends AutomaticVars {
		private Set<String> set = new HashSet<String>();
		private Map<String, Object> temp = null;
		private Object obj;

		public DestSetVars(Object o) {
			super(o);
			obj = o;
		}

		@Override
		public void put(String key, Object value) {
			if (null == key || (set.contains(key) && !"".equals(key) && !key.startsWith("~")))
				return;
			if (key.startsWith("~"))
				key = key.substring(1);
			if (".".equals(key))
				obj = value;
			else if (key.startsWith("~"))
				setTemp(key, value);
			else
				super.put(key, value);
			set.add(key);
		}

		public Object get(String key) {
			if (null == key)
				return null;
			if (!key.startsWith("~"))
				return null;
			Object r = getTemp(key);
			if (null != r)
				return r;
			key = key.substring(1);
			if (".".equals(key))
				return obj;
			return super.get(key);
		}

		public Object getTemp(String key) {
			if (null == temp)
				return null;
			return temp.get(key);
		}

		public void setTemp(String key, Object value) {
			if (null == temp)
				temp = new HashMap<String, Object>();
			temp.put(key, value);
		}

		public Object obj() {
			return obj;
		}

	}

	public static class Rule {
		private IEvaluator condition;
		private String destClass;
		private List<ISelector> selectors = new ArrayList<ISelector>();
		String name;
		String next;

		public void setCondition(String condition) {
			this.condition = ExprEvaluator.build(condition);
			if (null == this.condition)
				throw new RuntimeException("Illegal conditino expression: \""
						+ condition + "\"");
		}

		public boolean checkCondition(IVars vars) {
			if (null != condition)
				return (Boolean) TypeCaster.cast(Boolean.class, condition
						.eval(vars));
			return true;
		}

		public String getDestClass() {
			return destClass;
		}

		public void setDestClass(String v) {
			destClass = v;
		}

		public void setName(String v) {
			name = v;
		}

		public void setNext(String v) {
			next = v;
		}

		public void setSelect(CommData select) throws Exception {
			for (Object c : select) {
				if (c instanceof CommData) {
					ISelector selector = (ISelector) (beanBuilder
							.createObject((CommData) c));
					selectors.add(selector);
				}
			}
		}

		public void convert(IEnumerableVars srcVars, IWritableVars destVars,
				IVars cVars) {
			for (ISelector select : selectors) {
				select.select(srcVars, destVars, cVars);
			}
		}
	}
	
	static interface ISelector {
		void select(IEnumerableVars srcVars, IWritableVars destVars,
				IVars cVars);
	}

	public static class Selector implements ISelector {
		private IEvaluator valueExpr;
		private IEvaluator conditionExpr;
		private Pattern eachExpr;
		private IVarReplacer toExpr;

		public void setValue(String v) {
			valueExpr = ExprEvaluator.build(v);
		}

		public void setEach(String v) {
			eachExpr = Pattern.compile(v);
		}

		public void setTo(String v) {
			toExpr = new AdvanceVarReplacer(v);
		}

		public void setCondition(String v) {
			conditionExpr = ExprEvaluator.build(v);
		}

		public void select(IEnumerableVars srcVars, IWritableVars destVars,
				IVars cVars) {
			if (null == eachExpr)
				select(destVars, cVars);
			else {
				Map<String, Object> params = new HashMap<String, Object>();
				cVars = new CombinedVars(new MapVars<Object>(params), cVars);
				for (String key : srcVars) {
					params.put(".field", key);
					params.put(".value", srcVars.get(key));
					if (eachExpr.matcher(key).find()) {
						select(destVars, cVars);
					}
				}
			}
		}

		public void select(IWritableVars destVars, IVars cVars) {
			if (null != conditionExpr) {
				Object o = conditionExpr.eval(cVars);
				if (!TypeCaster.toBoolean(o))
					return;
			}
			Object value = valueExpr.eval(cVars);
			String key = toExpr.replace(cVars);
			destVars.put(key, value);
		}

	}
	
	public static class ForEachSelector implements ISelector {
		private List<ISelector> selectors = new ArrayList<ISelector>();
		private Pattern eachExpr;
		private IEvaluator conditionExpr;

		public void setEach(String v) {
			eachExpr = Pattern.compile(v);
		}
		
		public void setCondition(String v) {
			conditionExpr = ExprEvaluator.build(v);
		}
		
		public void setSelect(CommData select) throws Exception {
			for (Object c : select) {
				if (c instanceof CommData) {
					ISelector selector = (ISelector) (beanBuilder
							.createObject((CommData) c));
					selectors.add(selector);
				}
			}
		}

		@Override
		public void select(IEnumerableVars srcVars, IWritableVars destVars,
				IVars cVars) {
			if (null != conditionExpr) {
				Object o = conditionExpr.eval(cVars);
				if (!TypeCaster.toBoolean(o))
					return;
			}
			Map<String, Object> params = new HashMap<String, Object>();
			cVars = new CombinedVars(new MapVars<Object>(params), cVars);
			for (String key : srcVars) {
				params.put(".field", key);
				params.put(".value", srcVars.get(key));
				if (eachExpr.matcher(key).find()) {
					for(ISelector selector : selectors) {
						selector.select(srcVars, destVars, cVars);
					}
				}
			}
		}
	}

	public DataConvertor(String conf) throws Exception {
		this(conf, null);
	}

	public DataConvertor(String conf, IVars vars) throws Exception {
		this(parse(conf, vars), vars);
	}

	public DataConvertor(Element conf, IVars vars) throws Exception {
		if (null == vars)
			vars = new MethodVars(VarFunLib.class);
		this.vars = vars;
		CommData c = ConfDigester.digest(conf, new DigestPolicy() {
			@Override
			public void buildTarget(CommData parent, CommData current,
					PolicyTarget target) {
				String cKey = current.getString(ConfDigester.TAG_KEY);
				String pKey = parent.getString(ConfDigester.TAG_KEY);
				if ("rule".equals(cKey)) {
					target.key = null;
					target.cat = cKey;
					target.value = current;
					current.put("class", DataConvertor.class.getName()
							+ "$Rule");
				} else if ("for".equals(cKey) && ("rule".equals(pKey) || "for".equals(pKey))) {
					target.key = null;
					target.cat = "select";
					target.value = current;
					current.put("class", DataConvertor.class.getName()
							+ "$ForEachSelector");
				} else if ("select".equals(cKey) && ("rule".equals(pKey) || "for".equals(pKey))) {
					target.key = null;
					target.cat = cKey;
					target.value = current;
					current.put("class", DataConvertor.class.getName()
							+ "$Selector");
				} else if ("mapping".equals(cKey)) {
					target.cat = cKey;
					target.key = current.getString("name");
					current.put("name", null);
					target.value = current;
				} else if ("default".equals(cKey) && "mapping".equals(pKey)) {
					target.key = "default";
					target.value = current.getString(ConfDigester.VALUE_KEY);
				} else if ("mapping".equals(pKey)) {
					target.cat = cKey;
					target.key = current.getString("key");
					target.value = current.getString(ConfDigester.VALUE_KEY);
				}
			}
		});
		for (Object o : c.getChild("rule")) {
			if (o instanceof CommData) {
				Rule rule = (Rule) beanBuilder.createObject((CommData) o);
				addRule(rule);
			}
		}
		maps = c.getChild("mapping");
		setSelect(c.getString("select"));
	}

	private void addRule(Rule rule) {
		List<Rule> ruleList;
		if (null == rule.name)
			rule.name = "";
		if (rules.containsKey(rule.name))
			ruleList = rules.get(rule.name);
		else {
			ruleList = new ArrayList<Rule>();
			rules.put(rule.name, ruleList);
		}
		ruleList.add(rule);
	}

	private static Element parse(String conf, IVars vars) throws Exception {
		String xmlStr = null;
		try {
			xmlStr = TextFile.loadResource(conf, "utf8");
		} catch (Throwable e) {
			throw new Exception("fail to load config file: " + conf, e);
		}
		if (xmlStr == null)
			throw new Exception("fail to load config file: " + conf);
		if (vars != null) {
			IVarReplacer replacer = new AdvanceVarReplacer(xmlStr);
			xmlStr = replacer.replace(vars);
		}
		SAXReader reader = new SAXReader();
		Document document;
		document = reader.read(new StringReader(xmlStr));
		Element el = document.getRootElement();
		handleIncludes(el, vars);
		return el;
	}

	@SuppressWarnings("unchecked")
	private static void handleIncludes(Element el, IVars vars) throws Exception {
		for (Element incEl : (List<Element>) el.elements("Include")) {
			String path = incEl.attributeValue("file");
			Element resEl = parse(path, vars);
			int p = el.elements().indexOf(incEl);
			el.remove(incEl);
			for (Element res : (List<Element>) resEl.elements()) {
				el.elements().add(p, res.clone());
				p++;
			}
		}
	}

	public Object convert(Object src, Object dest) throws Exception {
		return convert(null, src, dest);
	}

	public Object convert(String ruleName, Object src) throws Exception {
		return convert(ruleName, src, null);
	}

	public Object convert(Object src) throws Exception {
		return convert(null, src, null);
	}

	public Object convert(String ruleName, Object src, Object dest)
			throws Exception {
		IEnumerableVars srcVars = new AutomaticVars(src);
		CombinedVars cVars = new CombinedVars(srcVars, this, vars);
		cVars.add(new ValuesVars(".", src, "..", cVars));
		Rule rule;
		if (null == ruleName)
			rule = getRule(cVars);
		else
			rule = getRule(ruleName, cVars);
		if (null == rule)
			throw new Exception("No suitable rules found for " + src);
		if (null == dest) {
			if (dest instanceof String)
				dest = beanBuilder.createObject((String) dest);
			else if (null != rule.getDestClass()) {
				dest = beanBuilder.createObject(rule.getDestClass());
			}
		}
		if (null == dest)
			dest = src;
		DestSetVars destVars = new DestSetVars(dest);
		cVars.add(destVars);
		rule.convert(srcVars, destVars, cVars);
		Object r = destVars.obj();
		if (null != rule.getDestClass()) {
			r = TypeCaster.cast(rule.getDestClass(), r);
		}
		if (null != rule.next)
			return convert(rule.next, r);
		else
			return r;
	}

	public static Object cast(Object src, Class<?> destClass) {
		try {
			Object dest = destClass.newInstance();
			return cast(src, dest);
		} catch (Exception e) {
			return null;
		}

	}

	public static Object cast(Object src, Object dest) {
		if (null == src || null == dest)
			return null;
		AutomaticVars destVars = new AutomaticVars(dest);
		destVars.put(src);
		return dest;

	}

	protected void setSelect(String v) {
		if (null != v)
			selectExpr = ExprEvaluator.build(v);
	}

	private Rule getRule(IVars vars) {
		String ruleName = "";
		if (null != selectExpr)
			ruleName = (String) TypeCaster.cast(String.class, selectExpr
					.eval(vars));
		return getRule(ruleName, vars);
	}

	private Rule getRule(String ruleName, IVars vars) {
		List<Rule> ruleList = rules.get(ruleName);
		if (null == ruleList)
			return null;
		for (Rule rule : ruleList) {
			if (rule.checkCondition(vars))
				return rule;
		}
		return null;
	}

	public IVars getVars() {
		return vars;
	}

	public void setVars(IVars vars) {
		this.vars = vars;
	}

	public Object mapping(String key, CommData mapping) {
		CommData cd = mapping.getChild("map");
		Object r = null;
		if (null != cd)
			r = cd.get(key);
		if (null != r)
			return r;
		cd = mapping.getChild("partof");
		if (null != cd) {
			for (String k : cd.keySet()) {
				if (key.indexOf(k) >= 0) {
					r = cd.get(k);
					break;
				}
			}
		}
		if (null != r)
			return r;
		cd = mapping.getChild("match");
		if (null != cd) {
			for (String k : cd.keySet()) {
				if (Pattern.matches(k, key)) {
					r = cd.get(k);
					break;
				}
			}
		}
		if (null != r)
			return r;
		cd = mapping.getChild("test");
		if (null != cd) {
			IVars vars = new CombinedVars(new ValuesVars("value", key),
					this.vars);
			for (String k : cd.keySet()) {
				IEvaluator e = Evaluator.build(k);
				if (null != e) {
					if (TypeCaster.toBoolean(e.eval(vars))) {
						r = cd.get(k);
						break;
					}
				}
			}
		}
		if (null != r)
			return r;
		r = mapping.get("default");
		return r;
	}

	@Override
	public Object eval(String fun, List<Object> params) {
		int pcount = params.size();
		if ("call".equals(fun)) {
			if (pcount <= 1 || null == params.get(0))
				return null;
			List<Object> params2 = new ArrayList<Object>();
			params2.addAll(params.subList(1, pcount));
			return eval(params.get(0).toString(), params2);
		}
		CommData map = null;
		if (null != maps)
			map = maps.getChild(fun);
		if (null != map && pcount == 1 && null != params.get(0)) {
			String key = params.get(0).toString();
			return mapping(key, map);
		} else {
			Object o = null;
			if (fun.equals("convert") && (pcount == 2 || pcount == 1)) {
				if (pcount == 1) {
					fun = null;
					o = params.get(0);
				} else if (pcount == 2) {
					fun = params.get(0).toString();
					o = params.get(1);
				}

			} else if (rules.containsKey(fun))
				o = params.get(0);

			if (null != o)
				try {
					return convert(fun, o);
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
		}

		return null;
	}

	@Override
	public Object get(String key) {
		return null;
	}

}
