package com.hp.itis.core2.procengine;

import java.util.Set;

import com.hp.itis.core2.event.IEventListener;
import com.hp.itis.core2.procengine.module.IControllableModule;

public interface IEventConsumer extends IEventListener, IControllableModule {
	Set<String> events();
}
