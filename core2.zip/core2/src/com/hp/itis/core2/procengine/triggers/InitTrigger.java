package com.hp.itis.core2.procengine.triggers;


public class InitTrigger extends SyncTrigger {

	public void activate() {
		check();
	}

	public void deactivate() {
		
	}

	@Override
	protected void setup() {
		
	}
	
	protected Class<? extends ITriggerCondition> defaultConditionClass() {
		return TrueCondition.class;
	};
}
