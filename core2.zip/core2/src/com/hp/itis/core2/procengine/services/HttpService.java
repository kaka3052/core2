package com.hp.itis.core2.procengine.services;

import java.net.InetSocketAddress;

import com.hp.itis.core2.procengine.module.Service;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpServer;

public class HttpService extends Service {

	public static final int DEF_HTTP_PORT = 80;
	
	private String host;
	private int port = DEF_HTTP_PORT;
	private HttpServer http;
	
	public void setAddress(String address) {
		String[] s = address.split(":");
		if(s.length>0) {
			host = s[0];
			if(s.length>1)
				port = Integer.valueOf(s[1]);
		}
	}
	
	public void setPort(int port) {
		this.port = port;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}
	
	public void init() throws Exception {
		InetSocketAddress addr;
		if(null == host)
			addr = new InetSocketAddress(port);
		else
			addr = new InetSocketAddress(host, port);
		http = HttpServer.create(addr, 0);
	}
	
	@Override
	public void start() throws Exception {
		http.start();
	}

	@Override
	public void stop() throws Exception {
		http.stop(0);
	}
	
	public void removeContext(HttpContext context) {
		http.removeContext(context);
	}
	
	public HttpContext createContext(String path) {
		return http.createContext(path);
	}

}
