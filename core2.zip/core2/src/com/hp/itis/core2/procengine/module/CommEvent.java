package com.hp.itis.core2.procengine.module;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.hp.itis.core2.event.Event;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.procengine.task.ISession;
import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.IWritableVars;

public class CommEvent extends Event implements Serializable, IWritableVars {

	public static class EventContext implements IVars, Serializable {
		
		/**
		 * 
		 */
		private static final long serialVersionUID = -3113777936299881780L;
		private long contextId;
		private Map<String, Object> values;
		
		public EventContext(IEvent event) {
			contextId = event.id();
		}
		
		public long contextId() {
			return contextId;
		}
		
		Map<String, Object> values() {
			return values;
		}
		
		@Override
		public boolean equals(Object o) {
			if(o instanceof EventContext)
				return ((EventContext)o).contextId == contextId;
			return false;
		}
		
		synchronized public Set<String> keySet() {
			Set<String>  keySet = new LinkedHashSet<String>();
			if(null != values)
				keySet.addAll(values.keySet());
			return keySet;
		}
		
		synchronized public void put(String key, Object value) {
			if(null == values)
				values = new LinkedHashMap<String, Object>();
			values.put(key, value);
		}

		synchronized public Object get(String key) {
			if(null == values)
				return null;
			return values.get(key);
		}
		
	}
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2733934335956370147L;
	
	public CommEvent(String type) {
		this(type, null);
	}
	
	public CommEvent(String type, Object data) {
		this(type, null, data, false);
	}

	public CommEvent(String type, IEvent srcEvent, Object data, boolean sync) {
		super(type, null, data, sync);
		if(null != srcEvent) {
			if(srcEvent.source() instanceof EventContext)
				source = srcEvent.source();
			else
				source = new EventContext(srcEvent);
		}
		else
			source = new EventContext(this);
	}
	
	public static CommEvent createEvent(Object data, String type, boolean sync) {
		if(data instanceof CommEvent && null == type)
			return (CommEvent)data;
		IEvent srcEvent = null;
		if(data instanceof IEvent) {
			srcEvent = (IEvent)data;
			data = srcEvent.data();
		}
		else {
			ISession session = null;
			if(data instanceof ISession) {
				session = (ISession)data;
				data = session.deriveValue();
			}
			else
				session = SessionFactory.instance.currentSession();
			
			if(null != session && null != session.event()) {
				sync = session.event().sync();
				srcEvent = session.event();
			}
			if(data instanceof String && null == type) {
				type = data.toString();
				data = null;
			}
			else if(null == type)
				type = data.getClass().getSimpleName();
		}
		return new CommEvent(type, srcEvent, data, sync);
	}
	
    private void writeObject(ObjectOutputStream out) throws IOException {
    	if(!(source instanceof Serializable))
    		source = null;
    	if(!(target instanceof Serializable))
    		target = null;
        out.defaultWriteObject();
        
    }
 
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
    }
    
    protected EventContext context() {
    	if(!(source instanceof EventContext))
    		source = new EventContext(this);
    	return (EventContext)source;
    }

	@Override
	public void put(String key, Object value) {
		context().put(key, value);
	}

	@Override
	public Object get(String key) {
		return context().get(key);
	}
	
	public Set<String> keySet() {
		return context().keySet();
	}
}
