package com.hp.itis.core2.procengine.module;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.vars.IVars;

public interface IConfigProvider extends IVars{
	
	public interface ConfigVisitor {
		void accept(CommData conf);
	}
	
	public static final String CAT_TRIGGER = "Trigger";
	public static final String CAT_TASK = "Task";
	public static final String CAT_MODULE = "Module";
	public static final String CAT_FILTER = "Filter";
	public static final String CAT_BEAN = "Bean";
	public static final String CAT_SERVICE = "Service";
	public static final String CAT_FACTORY = "Factory";
	public static final String CAT_CLASSPATH = "ClassPath";
	public static final String CAT_IMPORT = "Import";
	
	CommData getConfig(String cat, String name);
	void visit(String cat, ConfigVisitor visitor);
	
}
