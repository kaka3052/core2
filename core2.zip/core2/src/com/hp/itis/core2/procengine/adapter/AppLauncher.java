package com.hp.itis.core2.procengine.adapter;

import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.module.ControllableModule;
import com.hp.itis.core2.vars.CmdLineVars;
import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.EnvVars;
import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.SysPropertyVars;
import com.hp.itis.core2.version.DefaultVersion;

public class AppLauncher extends ControllableModule {

	public static final String DEF_VER_PROP = "version.info";
	private IVars cmdVars;
	
	protected String configName() {
		return null;
	}
	
	@Override
	protected void activate() throws ModuleException {
		ProcEngine.instance().loadDefination(configName(), new CombinedVars(cmdVars, new EnvVars(), new SysPropertyVars()));
		IVars version = new DefaultVersion(DEF_VER_PROP);
		ProcEngine.instance().addVars(version);
		ProcEngine.instance().start();
	}

	@Override
	protected void deactivate() {

	}

	/**
	 * @param args
	 * @throws ModuleException 
	 */
	public void start(String[] args) throws ModuleException {
		cmdVars = new CmdLineVars(args);
		setActive(true);
	}
	
	public static void main(String[] args) throws ModuleException {
		new AppLauncher().start(args);
	}
	

}
