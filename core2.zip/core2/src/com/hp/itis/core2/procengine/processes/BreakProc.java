package com.hp.itis.core2.procengine.processes;

public class BreakProc extends DataProcess {

	@Override
	protected boolean execute() throws Exception {
		session().end();
		return true;
	}

	@Override
	protected void setup() throws Exception {
	}

}
