package com.hp.itis.core2.procengine.triggers;

import com.hp.itis.core2.misc.StrUtil;
import com.hp.itis.core2.misc.SException;

public class DelayCondition extends TriggerCondition {

	private long triggerTime = -1;
	
	@Override
	protected Object doCheck() {
		if(triggerTime != -1 && System.currentTimeMillis()>triggerTime) {
			triggerTime = -1;
			return true;
		}
		return false;
	}

	@Override
	protected void setup() throws SException {
		
	}
	
	public void setTest(String v) {
		triggerTime = System.currentTimeMillis() + StrUtil.str2Millisec(v);
	}

}
