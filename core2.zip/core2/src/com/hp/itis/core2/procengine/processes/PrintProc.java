package com.hp.itis.core2.procengine.processes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

public class PrintProc extends DataProcess {
	
	private String charset;
	
	public void setCharset(String charset) {
		this.charset = charset;
	}

	@Override
	protected boolean execute() throws Exception {
		return false;
	}
	
	public void execute(File file) throws Exception {
		execute(new FileInputStream(file));
	}
	
	public void execute(InputStream is) throws Exception {
		BufferedReader reader;
		if(null == charset)
			reader = new BufferedReader(new InputStreamReader(is));
		else
			reader = new BufferedReader(new InputStreamReader(is, charset));
		while(true) {
			String l = reader.readLine();
			if(null == l)
				break;
			System.out.println(l);
		}
	}
	
	public void execute(String text) {
		System.out.println(text);
	}

	@Override
	protected void setup() throws Exception {
	}

}
