package com.hp.itis.core2.procengine.triggers;

import java.util.Enumeration;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.Topic;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;
import com.hp.itis.core2.procengine.exception.ModuleException;

public class JmsTrigger extends AsynTrigger implements MessageListener {

	private ConnectionFactory connFactory;
	private Connection conn;
	private boolean topicMode = true;
	private String subscription;
	private String destName;
	private Destination dest; 
	private String clientId;
	private MessageConsumer consumer;
	private Session session;
	protected boolean transacted = false;
	protected String acknowledgeMode;
	private boolean clentAcknowledge = false;
	
	public void setConnFactory(ConnectionFactory connFactory) {
		this.connFactory = connFactory;
	}
	
	public void setMode(String v) {
		topicMode = "topic".equals(v);
	}
	
	public void setSubscription(String v) {
		subscription = v;
		if(null != v)
			topicMode = true;
	}
	
	public void setDest(Object v) {
		if(v instanceof String)
			destName = (String)v;
		else if(v instanceof Destination)
			dest = (Destination)v;
	}
	
	public void setClientId(String v) {
		clientId = v;
	}
	
	public void setAcknowledgeMode(String acknowledgeMode) {
		this.acknowledgeMode = acknowledgeMode;
	}

	public void setTransacted(boolean transacted) {
		this.transacted = transacted;
	}
	
	@Override
	protected void setup() throws ModuleException {
		try {
			conn = connFactory.createConnection();
		} catch (JMSException e) {
			throw new ModuleException(this, e);
		}
		 
	}
	
	@Override
	protected void activate() throws ModuleException {
		try {
            if (null != subscription && clientId != null) {
                conn.setClientID(clientId);
            }
            clentAcknowledge = false;
    		if("client".equalsIgnoreCase(acknowledgeMode)) {
    			session = conn.createSession(transacted, Session.CLIENT_ACKNOWLEDGE);
    			clentAcknowledge = true;
    		}
    		else if("dups".equalsIgnoreCase(acknowledgeMode))
    			session = conn.createSession(transacted, Session.DUPS_OK_ACKNOWLEDGE);
    		else
    			session = conn.createSession(transacted, Session.AUTO_ACKNOWLEDGE);
			if(null == dest) {
				if(topicMode)
					dest = session.createTopic(destName);
				else
					dest = session.createQueue(destName);
			}
			
			if(topicMode && null != subscription)
				consumer = session.createDurableSubscriber((Topic)dest, subscription);
			else
				consumer = session.createConsumer(dest);
			consumer.setMessageListener(this);
		} catch (JMSException e) {
			throw new ModuleException(this, e);
		}
	}

	@Override
	protected void deactivate() throws ModuleException {
		try {
			consumer.close();
			session.close();
		} catch (JMSException e) {
			throw new ModuleException(this, e);
		}
	}

	@Override
	public void onMessage(Message message) {
		Object data = null;
		try {
			if(message instanceof MapMessage) {
				MapMessage m = (MapMessage)message;
				Enumeration<?> e = m.getMapNames();
				CommData cd = new CommDataImpl();
				while(e.hasMoreElements()) {
					String name = e.nextElement().toString();
					cd.put(name, m.getObject(name));
				}
			}
			else if(message instanceof ObjectMessage) {
				ObjectMessage m = (ObjectMessage)message;
				data = m.getObject();
			}
			trigger(data);
			if(clentAcknowledge)
				message.acknowledge();
		} catch (JMSException e) {
			log().error(e, e);
		}
	}

}
