package com.hp.itis.core2.procengine.task;

import com.hp.itis.core2.event.Event;
import com.hp.itis.core2.procengine.module.IModule;

public class TaskEvent extends Event {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7870797571561805970L
	;
	public static final String TASK_BEGIN = "TaskBegin";
	public static final String TASK_END = "TaskEnd";
	public static final String PROC_BEGIN = "ProcBegin";
	public static final String PROC_ERROR = "ProcEnd";
	public static final String PROC_END = "ProcBegin";
	
	private IModule module;
	
	public TaskEvent(String type, ISession session, IModule module, Object data) {
		super(type, session, data, false);
		this.module = module;
	}
	
	public TaskEvent(String type, ISession session, IModule module) {
		this(type, session, module, null);
	}
	
	public ISession session() {
		return (ISession)source;
	}

	public IModule module() {
		return (IModule)module;
	}
	
	public Throwable error() {
		return (Throwable)data;
	}
}
