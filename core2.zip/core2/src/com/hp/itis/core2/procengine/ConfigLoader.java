package com.hp.itis.core2.procengine;

import java.net.URL;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;
import com.hp.itis.core2.file.TextFile;
import com.hp.itis.core2.procengine.bean.DefaultBeanFactory;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.module.IConfigProvider;
import com.hp.itis.core2.procengine.module.Module;
import com.hp.itis.core2.procengine.task.Filter;
import com.hp.itis.core2.procengine.task.Task;
import com.hp.itis.core2.procengine.triggers.DefaultTrigger;
import com.hp.itis.core2.procengine.triggers.InitTrigger;
import com.hp.itis.core2.procengine.util.ConfDigester;
import com.hp.itis.core2.procengine.util.ConfDigester.DigestPolicy;
import com.hp.itis.core2.procengine.util.ConfDigester.PolicyTarget;
import com.hp.itis.core2.vars.AdvanceVarReplacer;
import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.CommDataVars;
import com.hp.itis.core2.vars.IVarReplacer;
import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.PropertiesVars;
import com.hp.itis.core2.vars.XmlVarFormater;

public class ConfigLoader extends Module implements IConfigProvider {
	
	private CommData conf; 
	private CombinedVars vars = new CombinedVars();
	private String encoding = null;
	
	public ConfigLoader(String confPath, IVars vars) throws ModuleException {
		load(confPath, vars);
	}
	
	@Override
	public Object get(String key) {
		return vars.get(key);
	}

	@Override
	public CommData getConfig(String cat, String name) {
		CommData c = conf.getChild(cat);
		if(null == c)
			return null;
		return c.getChild(name);
	}
	
	@Override
	public void visit(String cat, ConfigVisitor visitor) {
		CommData c = conf.getChild(cat);
		if(null != c) {
			for(Object o : c) {
				if(o instanceof CommData)
					visitor.accept((CommData)o);
			}
		}
	}
	
	public void load(String confPath, IVars vars) throws ModuleException {
		Element el = parse(confPath, vars);
		CommData c = ConfDigester.digest(el, new DigestPolicy() {
			@Override
			public void buildTarget(CommData parent, CommData current, PolicyTarget target) {
				String cKey = current.getString(ConfDigester.TAG_KEY);
				String pKey = parent.getString(ConfDigester.TAG_KEY);
				if("Task".equals(cKey) || 
						"Filter".equals(cKey) ||
						"Trigger".equals(cKey) ||
						"Module".equals(cKey) ||
						"Service".equals(cKey) ||
						"Bean".equals(cKey) ||
						"Factory".equals(cKey)) {
					target.key = null;
					target.cat =  cKey;
					target.value = current;
				}
				if("ClassPath".equals(cKey) ||
						"Import".equals(cKey)) {
					target.key = null;
					target.cat =  cKey;
				}
				if("Task".equals(cKey)) {
					current.put("class", Task.class.getName());
				}
				if("Filter".equals(cKey)) {
					current.put("class", Filter.class.getName());
				}
				if("Trigger".equals(cKey)) {
					if(null == current.get("class"))
						current.put("class", DefaultTrigger.class.getName());
				}
				if("Task".equals(pKey) || "Filter".equals(pKey)) {
					target.key = null;
					target.cat =  "Process";
					target.value = current;
					if(null == current.getString("class"))
						current.put("class", cKey + "Proc");
				}
				if("Trigger".equals(pKey) &&
						("Condition".equals(cKey) || "Entry".equals(cKey))) {
					target.key = null;
					target.cat =  cKey;
					target.value = current;
				}
				if("Trigger".equals(pKey) &&
						(null == parent.getString("class") || 
								DefaultTrigger.class.getName() == parent.getString("class") ||
								InitTrigger.class.getName() == parent.getString("class")
						)) {
					target.key = null;
					target.cat =  "Condition";
					target.value = current;
					if(null == current.getString("class") && null == parent.getString("class"))
						current.put("class", cKey + "Condition");
				}
				if("Task".equals(cKey) ||
						"Module".equals(cKey)) {
					if(null == current.get("runMode")) {
						current.put("runMode", "asyn");
						if(null == current.get("queueSize"))
						current.put("queueSize", 100);
					}
				}
				if("Filter".equals(cKey)) {
					if(null == current.get("runMode")) {
						current.put("runMode", "sync");
					}
				}
				if("Factory".equals(cKey) && null == current.get("class")) {
					current.put("class", DefaultBeanFactory.class.getName());
				}
				if("Factory".equals(pKey) && 
						DefaultBeanFactory.class.getName().equals(parent.get("class"))) {
					if("Import".equals(cKey)) {
						target.key = null;
						target.cat =  "Import";
					}
					else {
						target.key = null;
						target.cat =  "Bean";
						target.value = current;
						if(null == current.getString("class"))
							current.put("class", cKey);
					}
				}
			}
		});
		conf = c;
		this.vars.add(new CommDataVars(conf));
	}
	
	private Element _parse(String path, IVars vars) throws ModuleException
	{
		String xmlStr = null;
		xmlStr = TextFile.loadResource(path, encoding);
		if(xmlStr == null)
			throw new ModuleException(this, 10001, path);
		if(vars!=null){
			IVarReplacer replacer = new AdvanceVarReplacer(xmlStr);
			replacer.setFormater(new XmlVarFormater());
			xmlStr = replacer.replace(VarFunLib.getVars(vars));
		}
		Document document;
		try {
			
			document = DocumentHelper.parseText(xmlStr);
			encoding = document.getXMLEncoding();
			Element el = document.getRootElement();
			handleIncludes(el, vars);
			return el;
		} catch (DocumentException e) {
			throw new ModuleException(this, 10003, path, e.toString());
		}
	}
	
	private Element parse(String path, IVars vars) throws ModuleException {
		URL url = TextFile.getURL(path);
		log().debug(20001, path, null==url?"":url.toString());
		log().setEnabled(false);
		Element el = _parse(path, vars);
		IVars inVars = new CombinedVars(vars, handleProperties(el, vars));
		el = _parse(path, inVars);
		inVars = new CombinedVars(vars, handleProperties(el, vars), handleParams(el));
		log().setEnabled(true);
		el = _parse(path, inVars);
		inVars = handleProperties(el, inVars);
		this.vars.add(inVars);
		return el;
	}
	
	@SuppressWarnings("unchecked")
	private void handleIncludes(Element el, IVars vars) throws ModuleException {
		for(Element incEl:(List<Element>)el.elements("Include"))
		{
			String path = incEl.attributeValue("file");
			URL url = TextFile.getURL(path);
			log().debug(20002, path, null==url?"":url.toString());
			Element resEl = _parse(path, vars);
			int p = el.elements().indexOf(incEl);
			el.remove(incEl);
			for(Element res : (List<Element>)resEl.elements()) {
				el.elements().add(p, res.clone());
				p++;
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private IVars handleProperties(Element el, IVars vars) throws ModuleException {
		CombinedVars cVars = new CombinedVars();
		for(Element pEl:(List<Element>)el.elements("Properties"))
		{
			String path = pEl.attributeValue("file");
			URL url = TextFile.getURL(path);
			log().debug(20003, path, null==url?"":url.toString());
			cVars.add(new PropertiesVars(path, vars));
			el.remove(pEl);
		}
		return cVars;
	}
	
	@SuppressWarnings("unchecked")
	private IVars handleParams(Element el) {
		CommData cd = new CommDataImpl();
		for(Element vEl:(List<Element>)el.elements("Param"))
		{
			String key = vEl.attributeValue("name");
			String value = vEl.attributeValue("value");
			if(null == value)
				value = vEl.getTextTrim();
			cd.put(key, value);
		}
		return new CommDataVars(cd);
	}

}
