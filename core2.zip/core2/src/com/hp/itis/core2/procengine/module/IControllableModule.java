package com.hp.itis.core2.procengine.module;

import com.hp.itis.core2.procengine.exception.ModuleException;


public interface IControllableModule extends IModule {
	enum ModuleState{INIT, STARTING, RUNNING, STOPPING, STOPPED};
	ModuleState moduleState();
	boolean isActive();
	void setActive(boolean value) throws ModuleException;
	void reload() throws ModuleException;
}
