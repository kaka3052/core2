package com.hp.itis.core2.procengine.triggers;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.hp.itis.core2.file.ExPathExpander;

public class FileTrigger extends IntervalTrigger {

	private class FileInfo {
		File file;
		long lastModified;
		
		public FileInfo(String fileName) {
			file = new File(fileName);
			if(file.exists())
				lastModified = file.lastModified();
		}
	    
        public boolean equals(Object obj) {
        	if(!(obj instanceof FileInfo))
        		return false;
        	FileInfo fileInfo = (FileInfo)obj;
        	return file.equals(fileInfo.file);
        }
        
        public int hashCode() {
        	return file.hashCode();
        }
	}
	
	private String filePath;
	private Map<String, FileInfo> files = new LinkedHashMap<String, FileInfo>();
	
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	@Override
	public void run() {
		Set<String> tFiles = new LinkedHashSet<String>();
		tFiles.addAll(ExPathExpander.expand(filePath));
		for(String fileName : tFiles) {
			FileInfo fileInfo = files.get(fileName);
			if(null == fileInfo) {
				fileInfo = new FileInfo(fileName);
				files.put(fileName, fileInfo);
				trigger(fileInfo.file);
			}
			else {
				File f = new File(fileName);
				if(fileInfo.lastModified != f.lastModified()) {
					fileInfo.lastModified = f.lastModified();
					fileInfo.file = f;
					trigger(fileInfo.file);
				}
			}
		}
		if(files.size()>tFiles.size()) {
			for(FileInfo fileInfo : files.values()) {
				if(!tFiles.contains(fileInfo.file.getPath())) {
					files.remove(fileInfo.file.getPath());
					trigger(fileInfo.file);
				}
			}
		}
	}

}
