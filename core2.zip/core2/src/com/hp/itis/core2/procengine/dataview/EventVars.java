package com.hp.itis.core2.procengine.dataview;

import java.util.List;

import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.procengine.module.CommEvent;
import com.hp.itis.core2.vars.AutomaticVars;
import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.IFunVars;
import com.hp.itis.core2.vars.IVars;

class EventVars implements IFunVars {

	private CombinedVars cvars;
	@Override
	public Object get(String key) {
		return cvars.get(key);
	}

	@Override
	public Object eval(String fun, List<Object> params) {
		return cvars.eval(fun, params);
	}
	
	public EventVars(Object data, IVars vars) {
		cvars = new CombinedVars();
		if(data instanceof IEvent) {
			IEvent event = (IEvent)data;
			if(null != event.data())
				cvars.add(new AutomaticVars(event.data()));
			if(event instanceof CommEvent)
				cvars.add((CommEvent)event);
		}
		else
			cvars.add(new AutomaticVars(data));
		if(null != vars)
			cvars.add(vars);
	}
	
}