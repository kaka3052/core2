package com.hp.itis.core2.procengine.adapter;

import javax.jms.Connection;
import javax.jms.ConnectionConsumer;
import javax.jms.ConnectionFactory;
import javax.jms.ConnectionMetaData;
import javax.jms.Destination;
import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.ServerSessionPool;
import javax.jms.Session;
import javax.jms.Topic;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.misc.PLog;
import com.hp.itis.core2.procengine.module.Service;

public class ActiveMqConnFactory extends Service implements ConnectionFactory {

    private String user = ActiveMQConnection.DEFAULT_USER;
    private String password = ActiveMQConnection.DEFAULT_PASSWORD;
    private String url = ActiveMQConnection.DEFAULT_BROKER_URL;
    private WrappedConnection connection;
    private ActiveMQConnectionFactory connectionFactory;
    
    private static class WrappedConnection implements Connection {

    	private Connection connection;
    	protected PLog log;

		public void close() throws JMSException {
			connection.close();
		}

		public ConnectionConsumer createConnectionConsumer(Destination arg0,
				String arg1, ServerSessionPool arg2, int arg3)
				throws JMSException {
			return connection.createConnectionConsumer(arg0, arg1, arg2, arg3);
		}

		public ConnectionConsumer createDurableConnectionConsumer(Topic arg0,
				String arg1, String arg2, ServerSessionPool arg3, int arg4)
				throws JMSException {
			return connection.createDurableConnectionConsumer(arg0, arg1, arg2,
					arg3, arg4);
		}

		public Session createSession(boolean arg0, int arg1)
				throws JMSException {
			return connection.createSession(arg0, arg1);
		}

		public String getClientID() throws JMSException {
			return connection.getClientID();
		}

		public ExceptionListener getExceptionListener() throws JMSException {
			return connection.getExceptionListener();
		}

		public ConnectionMetaData getMetaData() throws JMSException {
			return connection.getMetaData();
		}

		public void setClientID(String arg0) throws JMSException {
			connection.setClientID(arg0);
		}

		public void setExceptionListener(ExceptionListener arg0)
				throws JMSException {
			connection.setExceptionListener(arg0);
		}

		public void start() throws JMSException {
			//start a new thread here to wait the JMS connection starting
			//	to avoid unnecessary blocking
			new Thread( new Runnable() {
				@Override
				public void run() {
					try {
						connection.start();
					} catch (JMSException e) {
						log.error(e, e);
					}
				}
		
			}).start();
		}

		public void stop() throws JMSException {
			connection.stop();
		}
		
		public void setConnection(Connection conn) {
			connection = conn;
		}
    	
    	
    }
    
    public void init(CommData params) throws JMSException {
       connectionFactory = new ActiveMQConnectionFactory(user, password, url);
       connection = new WrappedConnection();
       connection.log = log();
    }
    
	@Override
	public Connection createConnection() throws JMSException {
		return connection;
	}

	@Override
	public Connection createConnection(String user, String password)
			throws JMSException {
		Connection connection = connectionFactory.createConnection(user, password);
		connection.start();
		return connection;
	}

	@Override
	public void start() throws Exception {
		connection.setConnection(connectionFactory.createConnection());
		connection.start();
	}

	@Override
	public void stop() throws Exception {
		connection.stop();
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
