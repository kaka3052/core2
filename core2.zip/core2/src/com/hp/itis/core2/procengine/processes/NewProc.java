package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;
import com.hp.itis.core2.procengine.ProcEngine;

public class NewProc extends DataProcess {

	@Override
	protected boolean execute() throws Exception {
		CommData params = this.params.getChild("Bean");
		if(null == params)
			params = this.params;
		else
			params = params.getChild("0");
		CommData oParams = new CommDataImpl();
		for(String key : params.keySet()) {
			oParams.put(key, evalValue(params.get(key)));
		}
		Object o = ProcEngine.instance().createObject(oParams);
		value(o);
		return true;
	}

	@Override
	protected void setup() throws Exception {

	}

}
