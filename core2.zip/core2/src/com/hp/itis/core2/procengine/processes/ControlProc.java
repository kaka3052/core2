package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.module.IControllableModule;

public class ControlProc extends DataProcess {

	private String module;
	private String command;
	
	@Override
	public boolean execute() throws Exception {
		IControllableModule  m = (IControllableModule)(ProcEngine.instance().getBean(module, IControllableModule.class));
		if(null != m) {
			if("start".equalsIgnoreCase(command))
				m.setActive(true);
			else if("stop".equalsIgnoreCase(command))
				m.setActive(false);
			else if("restart".equalsIgnoreCase(command))
				m.reload();
			return true;
		}
		return false;
	}
	
	public void setModule(String v) {
		module = v;
	}
	
	public void setCommand(String v) {
		command = v;
	}

	@Override
	protected void setup() throws Exception {
		
	}

}
