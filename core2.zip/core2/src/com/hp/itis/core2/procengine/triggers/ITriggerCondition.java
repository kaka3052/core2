package com.hp.itis.core2.procengine.triggers;

import com.hp.itis.core2.event.IEventDispatcher;

public interface ITriggerCondition {
	void setEventTarget(IEventDispatcher target);
	boolean check();
}
