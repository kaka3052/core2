package com.hp.itis.core2.procengine.processes;


public class ValueProc extends DataProcess {

	protected Object value;
	
	@Override
	protected boolean execute() throws Exception {
		value(evalValue(value));
		return true;
	}

	@Override
	protected void setup() throws Exception {
	}

	public void setValue(Object value) {
		this.value = value;
	}
}
