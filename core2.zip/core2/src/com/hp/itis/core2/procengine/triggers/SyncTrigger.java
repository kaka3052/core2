package com.hp.itis.core2.procengine.triggers;

import java.util.ArrayList;
import java.util.List;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.event.IEventDispatcher;
import com.hp.itis.core2.commdata.FieldMap;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.module.ControllableModule;

public abstract class SyncTrigger extends ControllableModule implements ITrigger {

	private List<ITriggerCondition> conditions = new ArrayList<ITriggerCondition>();
	private CommData condParams;
	protected CommData params;
	protected IEventDispatcher target;
	
	protected abstract void setup();
	
	public void init(CommData params) throws Exception {
		this.params = params;
		for(Object o : condParams) {
			if(o instanceof CommData) {
				CommData p = (CommData)o;
				for(String key : params.keySet()) {
					if(!"name".equals(key) && !"class".equals(key) && null == p.get(key))
						p.put(key, params.get(key));
				}
				ITriggerCondition condition = null;
				if(null != p.get("class") || null == defaultConditionClass())
					condition = (ITriggerCondition) ProcEngine.instance().createObject(p);
				else
					condition = (ITriggerCondition) ProcEngine.instance().createObject(defaultConditionClass(), p);
				if(null != condition)
					conditions.add(condition);
			}
		}
		setup();
	}
	
	@FieldMap("Condition")
	public void setCondition(CommData conf) throws Exception {
		condParams = conf;
	}
	
	protected void check() {
		for(ITriggerCondition condition : conditions) {
			condition.check();
		}
	}

	protected Class<? extends ITriggerCondition> defaultConditionClass() {
		return null;
	};
	
	@Override
	abstract protected void activate();

	@Override
	abstract protected void deactivate();

	@Override
	public void setEventTarget(IEventDispatcher target) {
		this.target = target;
		for(ITriggerCondition condition : conditions)
			condition.setEventTarget(target);
	}

}
