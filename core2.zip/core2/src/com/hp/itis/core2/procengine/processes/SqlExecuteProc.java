package com.hp.itis.core2.procengine.processes;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.db.SqlPreparation;
import com.hp.itis.core2.procengine.util.DbHelper;

public class SqlExecuteProc extends DataProcess {
	protected Log log = LogFactory.getLog(this.getClass());
	private String sql;
	private String resultKey;
	private String updateKey;
	private String keyField;
	private DataSource dataSource;
	private String driver;
	private String url;
	private String user;
	private String password;

	@Override
	protected void setup() throws Exception {
		sql = params.getString("sql");
		keyField = params.getString("key_field");
		resultKey = params.getString("result_key");
		updateKey = params.getString("update_key");
	}

	@Override
	public boolean execute() throws Exception {
		Connection conn = fetchConn();
		try {
			if(null == resultKey) {
				SqlPreparation sp = DbHelper.instance().prepareSql(conn, sql, session().vars());
				DbHelper.instance().execute(sp);
				Integer updated = sp.getStatement().getUpdateCount();
				if(null != updateKey)
					session().values().put(updateKey, updated);
			} else {
				CommData result;
				result = DbHelper.instance().queryCommData(conn, sql, keyField, session().vars());
				session().values().put(resultKey, result);
			}
			return true;
		} catch (Exception e) {
			session().log().error(e, e);
		}
		finally {
			releaseConn(conn);
		}
		return false;
	}
	
	protected Connection fetchConn() throws Exception {
		Connection conn = null;
		if(null != url) {
			String tUrl = (String)evalValue(url);
			if(null == DriverManager.getDriver(tUrl)) {
				Driver d = (Driver) Class.forName((String)evalValue(driver)).newInstance();
				DriverManager.registerDriver(d);
			}
			conn = DriverManager.getConnection(tUrl, (String)evalValue(user), (String)evalValue(password));
		}
		if(null == conn && null != dataSource)
			conn = dataSource.getConnection();
		if(null == conn)
			conn = (Connection)session().values().get("_CONN");
		if(conn == null)
			conn = DbHelper.instance().getConnection();
		return conn;
	}
	
	protected void releaseConn(Connection conn) {
		if(null != conn &&
				conn != (Connection)session().values().get("_CONN")) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public void setDriver(String driver) {
		this.driver = driver;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public void setPassword(String password) {
		this.password = password;
	}
			

}
