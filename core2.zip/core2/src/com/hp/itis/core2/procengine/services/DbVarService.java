package com.hp.itis.core2.procengine.services;

import javax.sql.DataSource;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.module.Service;
import com.hp.itis.core2.vars.DbPersistentVars;
import com.hp.itis.core2.vars.IPersistentVars;

public class DbVarService extends Service implements IPersistentVars {
	private IPersistentVars vars = null;
	private DataSource dataSource;
	
	public void init(CommData params) throws Exception {
		vars = new DbPersistentVars(dataSource, 
				params.getString("load_sql"), params.getString("get_sql"), 
				params.getString("add_sql"), params.getString("update_sql"), params.getString("del_sql"));
		try {
			vars.load();
		} catch (Exception e) {
			throw new ModuleException(this, e);
		}
	}
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public void load() throws Exception {
		vars.load();
	}

	@Override
	public void save() throws Exception {
		vars.save();
	}

	@Override
	public void put(String key, Object value) {
		vars.put(key, value);
	}

	@Override
	public Object get(String key) {
		return vars.get(key);
	}

	@Override
	public void start() throws ModuleException {

	}

	@Override
	public void stop() throws ModuleException {
		try {
			vars.save();
		} catch (Exception e) {
		}
	}
}
