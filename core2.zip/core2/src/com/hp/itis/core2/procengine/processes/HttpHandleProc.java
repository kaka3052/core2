package com.hp.itis.core2.procengine.processes;

import java.io.File;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;

import com.hp.itis.core2.file.TextFile;
import com.hp.itis.core2.misc.StrUtil;
import com.sun.net.httpserver.HttpExchange;

public class HttpHandleProc extends DataProcess {

	protected String contentAs;
	protected String requestFile = "request.data";
	protected boolean extractHeaders;
	
	public void setContentAs(String v) {
		contentAs = v;
	}
	
	public void setExtractHeaders(boolean extractHeaders) {
		this.extractHeaders = extractHeaders;
	}
	
	@Override
	protected boolean execute() throws Exception {
		return false;
	}
	

	@Override
	protected void setup() throws Exception {
	}

	public boolean execute(HttpExchange http) throws Exception {
		parseQuery(http.getRequestURI().getQuery(), "UTF-8");
		if(extractHeaders) {
			for(String name : http.getRequestHeaders().keySet()) {
				session().values().put(name, http.getRequestHeaders().getFirst(name));
			}
		}
		String contentType = http.getRequestHeaders().getFirst("Content-Type");
		String contentCharset = null;
		String contentAs = this.contentAs;
		if(null != contentType) {
			Map<String, String> ctParts = StrUtil.str2map(contentType, ";\\s?", "=");
			contentType = ctParts.keySet().iterator().next();
			contentCharset = ctParts.get("charset");
			if(null == contentAs && null != contentType) {
				if("application/x-www-form-urlencoded".equals(contentType))
					contentAs = "form";
				else if(contentType.contains("text"))
					contentAs = "text";
				else if(contentType.contains("xml"))
					contentAs = "xml";
			}
		}
		if("text".equals(contentAs)) {
			String content = TextFile.load(http.getRequestBody(), contentCharset);
			session().value(content);
		}
		else if("xml".equals(contentAs)) {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance(); 
			DocumentBuilder db = dbf.newDocumentBuilder(); 
			Document document = db.parse(http.getRequestBody());
			session().value(document);
		}
		else if("file".equals(contentAs)) {
			File file = saveFile(requestFile, http.getRequestBody());
			session().value(file);
		}
		else if("form".equals(contentAs)) {
			String content = TextFile.load(http.getRequestBody(), contentCharset);
			parseQuery(content, "UTF-8");
		}
		else
			session().value(http.getRequestBody());
		return true;
	}
	
	private void parseQuery(String query, String encoding) throws UnsupportedEncodingException {
		if(null == query)
			return;
		String pairs[] = query.split("&");
		for (String pair : pairs) {
			int pos = pair.indexOf('=');
			if (pos>0) {
				String name = URLDecoder.decode(pair.substring(0, pos), encoding);
				String value = URLDecoder.decode(pair
						.substring(pos + 1, pair.length()), encoding);
				session().values().put(name, value);
			}
		}
	}
	
	private File saveFile(String fileName, InputStream in) throws Exception {
		File file = session().getSessionFile(fileName);
		TextFile.save(file, in);
		return file;
	}

	public void setRequestFile(String requestFile) {
		this.requestFile = requestFile;
	}
	
}
