package com.hp.itis.core2.procengine.dataview;


public class ViewDataRemove<T> extends ViewDataEvent<T> implements IViewDataEvent<T> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 588193052903705984L;
	
	public ViewDataRemove(T data) {
		super(data.getClass().getSimpleName(), data);
	}
	
	public ViewDataRemove(String type, T data) {
		super(type, data);
	}
	
}
