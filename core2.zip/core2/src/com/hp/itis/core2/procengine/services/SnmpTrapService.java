package com.hp.itis.core2.procengine.services;

import java.io.IOException;

import org.snmp4j.CommandResponder;
import org.snmp4j.CommandResponderEvent;
import org.snmp4j.Snmp;
import org.snmp4j.TransportMapping;
import org.snmp4j.mp.MPv1;
import org.snmp4j.mp.MPv2c;
import org.snmp4j.mp.MPv3;
import org.snmp4j.security.SecurityModels;
import org.snmp4j.security.SecurityProtocols;
import org.snmp4j.security.USM;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.GenericAddress;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.TcpAddress;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.transport.DefaultTcpTransportMapping;
import org.snmp4j.transport.DefaultUdpTransportMapping;

import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.module.Service;

public class SnmpTrapService extends Service implements CommandResponder {

	public static final String SNMP_TRAP_EVENT = CommandResponderEvent.class.getSimpleName();
	
	private TransportMapping transport;
	private String address = "0.0.0.0/162";
	
	public void setAddress(String v) {
		v = v.replace(":", "/");
	    address = v;
	}
	
	@Override
	public void start() throws Exception {
		try 
		{
	        //创建SNMP
	        Address listenAddress = GenericAddress.parse(System.getProperty("snmp4j.listenAddress", address)); ;
	        
	        if (listenAddress instanceof UdpAddress) {
	            transport = new DefaultUdpTransportMapping((UdpAddress) listenAddress);
	        } else {
	            transport = new DefaultTcpTransportMapping((TcpAddress) listenAddress);
	        }
	        
	        Snmp snmp = new Snmp(transport);
	        
	        //处理V1,V2,V3
	        snmp.getMessageDispatcher().addMessageProcessingModel(new MPv1());
	        snmp.getMessageDispatcher().addMessageProcessingModel(new MPv2c());
	        snmp.getMessageDispatcher().addMessageProcessingModel(new MPv3());
	        USM usm = new USM(SecurityProtocols.getInstance(), new OctetString(MPv3.createLocalEngineID()), 0);
	        SecurityModels.getInstance().addSecurityModel(usm);
	        
	        //注册命令响应监听器
			snmp.addCommandResponder(this);
			snmp.listen();
			
		} catch (IOException e) {
			throw new ModuleException(this, e);
		}
	}

	@Override
	public void stop() throws Exception {
		if(null != transport)
			try {
				transport.close();
			} catch (IOException e) {
				throw new ModuleException(this, e);
			}
	}

	@Override
	public void processPdu(CommandResponderEvent evt) {
		if(hasListener(SNMP_TRAP_EVENT))
			dispatch(evt);
	}

}
