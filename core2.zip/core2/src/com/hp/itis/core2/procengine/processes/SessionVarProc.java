package com.hp.itis.core2.procengine.processes;


public class SessionVarProc extends DataProcess {

	@Override
	protected void setup() throws Exception {

	}

	@Override
	public boolean execute() throws Exception {
		session().values().put(this.params);
		return true;
	}

}
