package com.hp.itis.core2.procengine.triggers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.FieldMap;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.services.HttpService;
import com.sun.net.httpserver.Authenticator;
import com.sun.net.httpserver.BasicAuthenticator;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

public class HttpTrigger extends AsynTrigger {
	
	public static class HttpEntry implements HttpHandler {
		private String path;
		private String userName;
		private String password;
		private String realm;
		private boolean autoRespond = true;
		private HttpTrigger httpTrigger;
		private HttpContext context;
		private Authenticator authenticator;
		
		private List<String> events = new ArrayList<String>();
		
		public void setUserName(String userName) {
			this.userName = userName;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public void init(CommData conf) {
			if(null == authenticator && null != userName) {
				authenticator = new BasicAuthenticator(realm) {

					@Override
					public boolean checkCredentials(String u, String p) {
						return (null == userName || userName.equals(u) &&
								null == password || password.equals(p));
					}
				};
			};
		}
		
		public HttpTrigger getHttpTrigger() {
			return httpTrigger;
		}

		public void setHttpTrigger(HttpTrigger httpTrigger) {
			this.httpTrigger = httpTrigger;
		}

		public void setAutoRespond(boolean autoRespond) {
			this.autoRespond = autoRespond;
		}

		public String getPath() {
			return path;
		}

		public void setPath(String path) {
			this.path = path;
		}

		public Authenticator getAuthenticator() {
			return authenticator;
		}

		public void setAuthenticator(Authenticator authenticator) {
			this.authenticator = authenticator;
		}

		public HttpContext getContext() {
			return context;
		}

		public void setContext(HttpContext context) {
			this.context = context;
			context.setHandler(this);
		}

		public void setEvent(String v) {
			String[] tasks = v.split(",");
			for(int i=0; i< tasks.length ;i++)
				events.add(tasks[i].trim());
		}

		protected void sendEvents(HttpExchange hex) {
			for(String event : events)
				httpTrigger.sendEvent(event, hex);
		}
		
		@Override
		public void handle(HttpExchange hex) throws IOException {
			sendEvents(hex);
			if(autoRespond && hex.getResponseCode()<=0) {
				try {
					hex.sendResponseHeaders(200, 0);
				}
				catch(Throwable e) {}
			}
		}
	}
	
	private HttpService httpService;
	private CommData entryConf;
	private List<HttpEntry> entries = new ArrayList<HttpEntry>();

	public void setHttpService(HttpService httpService) {
		this.httpService = httpService;
	}

	@Override
	protected void activate() throws ModuleException {
		for(HttpEntry entry : entries) {
			entry.setContext(httpService.createContext(entry.getPath()));
		}
	}

	@Override
	protected void deactivate() throws ModuleException {
		for(HttpEntry entry : entries) {
			httpService.removeContext(entry.getContext());
		}
	}

	@Override
	protected void setup() throws ModuleException {
		for(Object o : entryConf) {
			if(o instanceof CommData) {
				CommData p = (CommData)o;
				for(String key : params.keySet()) {
					if(!"name".equals(key) && !"class".equals(key) && null == p.get(key))
						p.put(key, params.get(key));
				}
				HttpEntry entry = null;
				try {
					if(null != p.get("class"))
						entry = (HttpEntry) ProcEngine.instance().createObject(p);
					else
						entry = (HttpEntry) ProcEngine.instance().createObject(HttpEntry.class, p);
				}
				catch(Exception e) {
					throw new ModuleException(this, e);
				}
				if(null != entry) {
					entry.setHttpTrigger(this);
					entries.add(entry);
				}
			}
		}
	}
	
	public void sendEvent(String t, Object data) {
		super.sendEvent(t, data);
	}

	@FieldMap("Entry")
	public void setEntry(CommData conf) throws Exception {
		entryConf = conf;
	}
	
}
