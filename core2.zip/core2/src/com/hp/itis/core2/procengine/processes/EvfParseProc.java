package com.hp.itis.core2.procengine.processes;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;

import com.hp.itis.core2.evf.EvfDocument;
import com.hp.itis.core2.evf.EvfEventSink;
import com.hp.itis.core2.evf.EvfMetaLib;
import com.hp.itis.core2.evf.MetaLib;
import com.hp.itis.core2.evf.MetaValue;
import com.hp.itis.core2.evf.Record;
import com.hp.itis.core2.file.TextFile;
import com.hp.itis.core2.procengine.ProcEngine;

public class EvfParseProc extends DataProcess {


	private EvfDocument schema;
	private String charset = null;
	private String target;
	private MetaLib metaLib;
	private EvfEventSink evfEventSink;
	
	private class EvfStreamEventSink implements EvfEventSink {

		@Override
		public Record onAppendRecord(Record record) {
			EvfParseProc.this.dispatch(record);
			return null;
		}

		@Override
		public MetaValue onAppendMeta(MetaValue metaValue) {
			return metaValue;
		}

		@Override
		public void onSectionBegin() {
		}

		@Override
		public boolean onSectionEnd() {
			return false;
		}

		@Override
		public String onAppendMemo(String memo) {
			return memo;
		}

		@Override
		public boolean onContinue() {
			return true;
		}

		@Override
		public void onParseBegin() {
		}

		@Override
		public void onParseEnd() {
		}

		@Override
		public String onParseLine(String line) {
			return line;
		}

		@Override
		public String[] onParseValues(String[] values) {
			return values;
		}
		
	}
	
	public void setSchema(String schema) throws IOException {
		this.schema = new EvfDocument();
		this.schema.parse(TextFile.getResource(schema));
	}
	
	public void setCharset(String charset) {
		this.charset = charset;
	}

	@Override
	protected boolean execute() throws Exception {
		return false;
	}

	@Override
	protected void setup() throws Exception {
		if(null == schema)
			schema = new EvfDocument();
		for(String name : params.keySet()) {
			Object v = params.get(name);
			if(null != v)
				schema.meta().put(name, v);
		}
	}
	
	public boolean execute(String text) throws Exception {
		EvfDocument doc = new EvfDocument(schema);
		if(null != charset)
			doc.charset(charset);
		doc.parse(new StringReader(text), metaLib, evfEventSink);
		if(null == evfEventSink)
			value(doc);
		return true;
	}
	
	public boolean execute(File file) throws Exception {
		EvfDocument doc = new EvfDocument(schema);
		if(null != charset)
			doc.charset(charset);
		doc.parse(file, metaLib, evfEventSink);
		if(null == evfEventSink)
			value(doc);
		return true;
	}
	
	public boolean execute(InputStream is) throws Exception {
		EvfDocument doc = new EvfDocument(schema);
		if(null != charset)
			doc.charset(charset);
		doc.parse(is, metaLib, evfEventSink);
		if(null == evfEventSink)
			value(doc);
		return true;
	}
	
	public void setEvent(String v) {
		target = v;
	}
	
	public void setMode(String v) {
		if("stream".equals(v))
			evfEventSink = new EvfStreamEventSink();
		else
			evfEventSink = null;
	}
	
	public void setMetaLib(Object v) throws IOException {
		if(v instanceof MetaLib)
			metaLib = (MetaLib)v;
		else if(v instanceof String)
			metaLib = new EvfMetaLib((String)v);
	}
	
	protected void dispatch(Record record) {
		String eventName = record.meta().getString("event");
		if(null == eventName)
			eventName = target;
		if(null == eventName)
			eventName = record.meta().getString("name");
		if(null != eventName)
			ProcEngine.instance().dispatch(record, eventName);
	}

}
