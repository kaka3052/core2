package com.hp.itis.core2.procengine.processes;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.misc.Platform;
/**
 * 外部进程执行过程类<p>
 *	
 * <code>ExecutableProc</code>通过指定参数执行一个外部进程进行数据处理
 * <p>
 * 调用说明：<br>
 * 	可以通过2种方式输入参数到外部进程<p>
 * 	<ul>
 * 	<li>调用参数：名称为$0,$1..$n的参数</li>
 *  <li>环境变量: 名称为$var的参数</li>
 *  </ul>
 *  可执行程序可以通过参数<code>execution</code>或者参数<code>$0</code>输入。</p>
 *  对于数据的输入输出也有两种方式<p>
 *  <ul>
 *   <li>通过环境变量传递输入输出路径到进程内，默认的输入路径为<code>src_path</code>，
 *   默认的输出路径为<code>dest_path</code>。</li>
  *  <li>标准输入输出文件：通过streamInput控制是否将源路径中的文件重定向到
 *  标准输入流，如果无法通过文件输入过滤器<code>fileFilter</code>取得唯一的文件
 *  则使用默认的文件名<tt>.default</tt>取得输入流；类似通过streamOutput控制是否将输出流定向到
 *  目标路径中，默认文件名为<tt>.default</tt>。</li>
 *  </ul>
 * 
 *  @author changjiang
 */
public class ExecutableProc extends DataProcess {

	private final Integer MAX_COM_ARG_COUNT = 100;
	
	private ArrayList<String> commondList = new ArrayList<String>();
	private HashMap<String, String> envs = new HashMap<String, String>();
	private Boolean inited = false;
	private InputStream inputFile = null;
	private OutputStream outputFile = null;
	private String resultKey = "_VALUE";
	private String workPath = null;
	private String execution;

	/**
	 * 提取param中的调用参数和环境变量
	 *
	 */
	public void extractParams(CommData params)
	{
		String[] commondArray = new String[MAX_COM_ARG_COUNT]; 
		//参数匹配正则表达式，匹配$0,$1等命令参数
		Pattern pattern = Pattern.compile("^\\$(\\d{1,2})$");
		String value;
		int up = -1; //参数最大下标
		int cp = -1; //参数下标
		
		for(String key : params.keySet())
		{
			value = params.getString(key);
			if(key.startsWith("$"))
			{
				Matcher matcher = pattern.matcher(key);
				if(matcher.find())
				{
					//参数为命令参数
					cp = Integer.parseInt(matcher.group(1));
					if(cp<MAX_COM_ARG_COUNT)
						commondArray[cp] = value;
					//存储最大参数下标
					if(cp>up)
						up = cp;
				}
				else 
					//否则参数为环境变量
					envs.put(key.substring(1), value);
			}
		}
		//将默认调用命令放入命令参数列表
		if(null != params.get("execution"))
		{
			if(up<0) 
				up = 0;
			commondArray[0] = execution;
		}
		//将参数数组中的参数添加到参数列表，空确参数补为空字符串
		for(int i=0; i<=up; i++)
		{
			if(null == commondArray[i])
				commondList.add("");
			else
				commondList.add(commondArray[i]);
		}
	}
	
	/**
	 * 取得调用进程命令列表的字符串表现形式
	 * @return
	 */
	public String getCommondStr()
	{
		if(0==commondList.size()) return "";
		StringBuffer sb= new StringBuffer();
		sb.append(commondList.get(0)); 
		for(int i=1; i<commondList.size(); i++)
		{
			sb.append(" \"");
			sb.append(commondList.get(i));
			sb.append("\"");
		}
		return sb.toString();
	}
	
	/**
	 * 取得调用进程环境变量列表的字符串表现形式
	 * @return
	 */
	public String getEnvsStr()
	{
		StringBuffer sb= new StringBuffer();
		for(Entry<String, String> pair:envs.entrySet())
		{
			sb.append(pair.getKey());
			sb.append("=\"");
			sb.append(pair.getValue());
			sb.append("\";");
		}
		return sb.toString();
	}

	@Override
	protected void setup() throws Exception {
		extractParams(params);
		inited = commondList.size()>0;
	}

	public void setInputFile(String inputFile) throws FileNotFoundException {
		this.inputFile = new FileInputStream(session().getSessionFile(inputFile));
	}

	public void setOutputFile(String outputFile) throws FileNotFoundException {
		this.outputFile = new FileOutputStream(session().getSessionFile(outputFile));
	}

	public void setResultKey(String resultKey) {
		this.resultKey = resultKey;
	}

	public void setWorkPath(String workPath) {
		this.workPath = workPath;
	}
	
	public void setExecution(String execution) {
		this.execution = execution;
	}

	@Override
	public boolean execute() throws Exception {
		try{
			if(!inited)
				throw new Exception("<FAIL> call, process is not initialized properly");
			
			session().log().debug("<START> to execute external process: " + getCommondStr());
			session().log().debug("with envirentment params: " + getEnvsStr());
			
			OutputStream ofs = null;
			String errMsg = null;
			if(null != resultKey) {
				ofs = new ByteArrayOutputStream();
				errMsg = Platform.execProcess(commondList, envs, workPath, inputFile, ofs);
				session().values().put(resultKey, ofs.toString());
			}
			else
			{
				//通过命令参数创建外部进程并执行，如果有错误返回错误输出，否则返回null
				errMsg = Platform.execProcess(commondList, envs, 
						workPath, inputFile, outputFile);
			}
			
			if(null == errMsg)
				return true;
			else
			{
				session().log().error("<FAIL> to execute external process, with info returned: " + errMsg);
				return false;
			}
		} catch (Exception e) {
			session().log().error(e);
			session().log().debug("", e);
			return false;
		}	
	}

}
