package com.hp.itis.core2.procengine.dataview;

import java.util.Date;

import com.hp.itis.core2.event.IEvent;

public interface IViewDataEvent<T> extends IEvent {
	
	T getData();
	void setData(T data);
	Date arisingTime();
	
}
