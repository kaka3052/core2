package com.hp.itis.core2.procengine.triggers;

import com.hp.itis.core2.procengine.module.IJob;
import com.hp.itis.core2.procengine.module.IJobContainer;


public class JobTrigger extends IntervalTrigger {

	private IJobContainer jobContainer;
	
	public IJobContainer getJobContainer() {
		return jobContainer;
	}

	public void setJobContainer(IJobContainer jobContainer) {
		this.jobContainer = jobContainer;
	}

	@Override
	public void run() {
		for(IJob job : jobContainer) {
			if(job.schedule())
				trigger(job);
		}
	}
	

}
