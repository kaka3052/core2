package com.hp.itis.core2.procengine.processes;

import java.io.File;
import java.util.List;
import java.util.regex.Pattern;

import com.hp.itis.core2.commdata.FieldMap;
import com.hp.itis.core2.file.ExPathExpander;
import com.hp.itis.core2.misc.StrUtil;

public class FileCleanProc extends DataProcess {
	private String cleanPath;
	private long expiring; 
	private Pattern filePat;


	@FieldMap("clean_path")
	public void setCleanPath(String cleanPath) {
		this.cleanPath = cleanPath;
	}

	@FieldMap("expiring")
	public void setExpiring(String expiring) {
		this.expiring = StrUtil.str2Millisec(expiring);
	}

	@FieldMap("file_filter")
	public void setFileFilter(String fileFilter) {
		filePat = Pattern.compile(fileFilter); 
	}

	@Override
	protected void setup() throws Exception {

	}
	
	@Override
	public boolean execute() throws Exception {
		if(null == cleanPath) {
			session().deleteSessionDir();
			return true;
		}
		List<String> fileNames = ExPathExpander.expand(cleanPath);
		for(String fileName : fileNames) {
			File file = new File(fileName);
			if(!file.exists())
				continue;
			if(filePat.matcher(file.getName()).find() 
					&& (System.currentTimeMillis() - file.lastModified()) > expiring) {
				session().log().debug(20001, file.getPath());
				file.delete();
			}
		}
		return true;
	}

}
