package com.hp.itis.core2.procengine.task;

import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.event.Event;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.procengine.ProcEngine;


public class Filter extends Task {

	public static final int PRI_FILTER_BASE = 100;
	
	protected int defPriority() {
		return PRI_DEFAULT + PRI_FILTER_BASE;
	}
	
	@Override
	public void setPriority(String v) {
		if("high".equals(v))
			priority = PRI_HIGH + PRI_FILTER_BASE;
		else if("higher".equals(v))
			priority = PRI_HIGHER + PRI_FILTER_BASE;
		else if("lower".equals(v))
			priority = PRI_LOWER + PRI_FILTER_BASE;
		else if("low".equals(v))
			priority = PRI_LOW + PRI_FILTER_BASE;
		else
			priority = TypeCaster.cast(v, PRI_DEFAULT + PRI_FILTER_BASE);
	}
	
	@Override
	protected ITaskProfile createProfile() throws Exception {
		if(null == profileClass)
			profileClass = DefaultFilterProfile.class;
		return (ITaskProfile)ProcEngine.instance().createObject(profileClass, params);
	}
	
	@Override
	protected void taskEnd(ISession session, ITask task) {
		IEvent event = session.event();
		if(null != event) {
			if( (!event.depressed()) && (!session.result()) ) {
				event.depress();
			}
			if(event instanceof Event) {
				((Event)event).data(session.value());
			}
		}
		super.taskEnd(session, task);
	}
	
}
