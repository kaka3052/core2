package com.hp.itis.core2.procengine.dataview;

public class ViewDataAdd<T> extends ViewDataEvent<T> implements IViewDataEvent<T> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8293767850377353670L;

	public ViewDataAdd(T data) {
		super(data.getClass().getSimpleName(), data);
	}
	
	public ViewDataAdd(String type, T data) {
		super(type, data);
	}
	
}
