package com.hp.itis.core2.procengine.task;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.itis.core2.misc.WrappedLog;

/**
 * 会话日志类
 * 包装了Log4j中的Log类
 * @author changjiang
 *
 */
public class SessionLog extends WrappedLog {

	private ISession session;
	private String mName = null;
	private String currentCat;
	
	public SessionLog(ISession session)
	{
		super(null);
		this.session = session;
	}
	
	private String getCat() {
		StringBuilder sb = new StringBuilder();
		sb.append(session.getClass().getSimpleName());
		if(null != session.currentModule()) {
			sb.append(".");
			sb.append(session.currentModule().fullName());
		}
		return sb.toString();
		
	}
	
	protected Log log() {
		String cat = getCat();
		if(currentCat != cat) {
			log = LogFactory.getLog(cat);
		}
		return log;
	}
	
	@Override
	protected String wrap(Object obj, Object... args)
	{
		if(null != session.currentModule())
			mName = session.currentModule().name();
		StringBuffer sb = new StringBuffer();
		sb.append(session.sessionID());
		sb.append(" - ");
		sb.append(super.wrap(obj, args));
		return sb.toString();
	}
	
	@Override
	protected String[] defNames() {
		if(null == mName)
			return null;
		else {
			String[] defs = new String[2];
			defs[0] = session.getClass().getSimpleName();
			defs[1] = mName;
			return defs;
		}
	}
}
