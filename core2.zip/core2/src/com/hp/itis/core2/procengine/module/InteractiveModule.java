package com.hp.itis.core2.procengine.module;

import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventDispatcher;

abstract public class InteractiveModule extends EventConsumer implements IInteractiveModule {

	protected IEventDispatcher target;
	
	@Override
	public void setEventTarget(IEventDispatcher target) {
		this.target = target;
	}

	@Override
	public void sendEvent(IEvent event) {
		target.dispatch(event);
	}
	
	public IEvent sendEvent(Object data) {
		return target.dispatch(data);
	}

}
