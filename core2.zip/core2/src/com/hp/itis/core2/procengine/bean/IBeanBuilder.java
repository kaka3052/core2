package com.hp.itis.core2.procengine.bean;

import com.hp.itis.core2.commdata.CommData;

public interface IBeanBuilder {

	Object createObject(Class<?> c, CommData params, Object... args)
			throws Exception;
	
	Object createObject(Class<?> c, Object... args)	throws Exception;

	Object createObject(CommData params) throws Exception;

	Object createObject(String className, CommData params, Object... args)
			throws Exception;
	
	Object createObject(String className, Object... args) throws Exception;

	Class<?> getClass(String className) throws ClassNotFoundException;
	
	void buildObject(Object o, CommData params) throws Exception;

}