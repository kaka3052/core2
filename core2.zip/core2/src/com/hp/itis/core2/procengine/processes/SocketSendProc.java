package com.hp.itis.core2.procengine.processes;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Socket;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hp.itis.core2.misc.StrUtil;

public class SocketSendProc extends DataProcess {

	private String host;
	private int port;
	private Proxy proxy;
	private int timeout = 0;
	private ObjectOutputStream oos;
	private boolean keepConnection = true;
	private Socket socket;

	@Override
	protected void setup() throws Exception {
		
	}
	
	@Override
	protected boolean execute() throws Exception {
		if(null == oos)
			reconnect();
		boolean r = tryWriteObject(session().deriveValue());
		if(!keepConnection)
			disconnect();
		return r;
	}
	
	protected boolean reconnect() {
		try {
			socket = connect();
			oos = new ObjectOutputStream(socket.getOutputStream());
			return true;
		} catch (IOException e) {
			session().log().error("Fail to connect remote host: " + e);
		}
		return false;
	}
	
	protected void disconnect() {
		if(null != oos) {
			try {
				oos.close();
				oos = null;
			} catch (IOException e) {
			}
		}
		if(null != socket) {
			try {
				socket.close();
				socket = null;
			} catch (IOException e) {
			}
		}
	}
	
	protected boolean tryWriteObject(Object o) {
		if(!writeObject(o)) {
			reconnect();
			return writeObject(o);
		}
		return true;
	}
	
	protected boolean writeObject(Object o) {
		if(null != oos) {
			try {
				oos.writeObject(o);
				oos.flush();
				return true;
			} catch (IOException e) {
				session().log().error("Fail to send object through socket connection: " + e);
			}
		}
		return false;
	}
	
	protected Socket connect() throws IOException {
		Socket socket;
		if(null != proxy)
			socket = new Socket(proxy);
		else
			socket = new Socket();
		InetSocketAddress address = new InetSocketAddress(host, port);
		if(timeout>0)
			socket.connect(address, timeout);
		else
			socket.connect(address);
		return socket;
	}

	
	public void setPort(int v) {
		port = v;
	}
	
	public void setProxy(String proxy) {
		try {
			Proxy.Type proxyType = Proxy.Type.SOCKS;
			Matcher m = Pattern.compile("((.+?)://)?(.*?)(:(\\d+))").matcher(proxy);
			if(!m.find())
				throw new Exception();
			String protocal = m.group(2);
			if(null != protocal)
				proxyType = Proxy.Type.valueOf(protocal.toUpperCase());
			String host = m.group(3);
			int port = Integer.valueOf(m.group(5));
			this.proxy = new Proxy(proxyType, new InetSocketAddress(host, port));
		}
		catch(Throwable e) {
			throw new RuntimeException("Illegel proxy setting: " + proxy);
		}
	}
	
	public void setTimeout(String v) {
		timeout = (int)StrUtil.str2Millisec(v);
	}
	
	public void setAddress(String v) {
		try {
			Matcher m = Pattern.compile("((.+?)://)?(.*?)(:(\\d+))").matcher(v);
			if(!m.find())
				throw new Exception();
			host = m.group(3);
			port = Integer.valueOf(m.group(5));
		}
		catch(Throwable e) {
			throw new RuntimeException("Illegel address setting: " + v);
		}
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public Proxy getProxy() {
		return proxy;
	}

	public int getTimeout() {
		return timeout;
	}

	public int getPort() {
		return port;
	}

	public void setKeepConnection(boolean keepConnection) {
		this.keepConnection = keepConnection;
	}

}
