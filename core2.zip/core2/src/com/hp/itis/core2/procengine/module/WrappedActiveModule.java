package com.hp.itis.core2.procengine.module;

public class WrappedActiveModule extends ActiveModule {

	private IActiveModule module;
	
	public WrappedActiveModule(IActiveModule module) {
		this.module = module;
	}
	
	protected IActiveModule module() {
		return module;
	}
	
	@Override
	public void run() {
		module.run();
	}
 
	@Override
	public void activate() {
		super.activate();
	}

	@Override
	public void deactivate() {
		super.deactivate();
	}
}
