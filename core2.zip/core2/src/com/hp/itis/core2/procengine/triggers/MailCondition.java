package com.hp.itis.core2.procengine.triggers;

import java.util.List;
import java.util.regex.Pattern;

import com.hp.itis.core2.mail.MailMessage;
import com.hp.itis.core2.mail.MailParams;
import com.hp.itis.core2.mail.MailReceiver;
import com.hp.itis.core2.mail.ReceiveHandler;
import com.hp.itis.core2.misc.StrUtil;
import com.hp.itis.core2.misc.SException;
import com.hp.itis.core2.vars.AutomaticVars;

public class MailCondition extends TriggerCondition implements ReceiveHandler{

	private MailReceiver mailReceiver = new MailReceiver();
	private MailParams mailParams;
	private ReceiveHandler receiveFilter;
	private Pattern subjectFilter;
	private Pattern senderFilter;
	private long expire = 0;
	
	@Override
	protected Object doCheck() {
		try {
			List<MailMessage> mails = mailReceiver.receive(mailParams, this);
			if(mails.size()>0)
				return mails;
		} catch (Exception e) {
			log().error(e, e);
		}
		return null;
	}

	@Override
	protected void setup() throws SException {
		mailParams = new MailParams();
		AutomaticVars paramVars = new AutomaticVars(mailParams);
		paramVars.put(vars);
	}

	@Override
	public boolean accept(MailMessage message) {
		boolean r = true;
		if(null != receiveFilter)
			r = receiveFilter.accept(message);
		if(null != subjectFilter && !subjectFilter.matcher(message.getSubject()).find())
			r = false;
		if(null != senderFilter && !senderFilter.matcher(message.getFrom()).find())
			r = false;
		if(expire>0 && System.currentTimeMillis() - message.getSentDate().getTime() > expire)
			r = false;
		return r;
	}
	
	public void setReceiveFilter(ReceiveHandler receiveFilter) {
		this.receiveFilter = receiveFilter;
	}
	
	public void setSubjectFilter(String v) {
		subjectFilter = Pattern.compile(v);
	}
	
	public void setSenderFilter(String v) {
		senderFilter = Pattern.compile(v);
	}
	
	public void setExpire(String v) {
		expire = StrUtil.str2Millisec(v);
	}

}
