package com.hp.itis.core2.procengine.task;

import com.hp.itis.core2.procengine.module.IModule;

public interface ITask extends IProcess, IModule {

}
