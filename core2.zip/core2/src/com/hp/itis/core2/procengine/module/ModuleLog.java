package com.hp.itis.core2.procengine.module;

import java.util.ArrayList;
import java.util.List;

import com.hp.itis.core2.misc.WrappedLog;

public class ModuleLog extends WrappedLog {
	
	protected IModule module;
	
	private static String[] getSupperNames(IModule module) {
		Class<?> c = module.getClass();
		List<String> defs = new ArrayList<String>();
		while(c != Object.class && c != null) {
			if(module.name() != c.getSimpleName())
				defs.add(c.getSimpleName());
			c = c.getSuperclass();
		}
		return defs.toArray(new String[0]);
	}
	
	public ModuleLog(IModule module)
	{
		super(module.name(), getSupperNames(module));
		this.module = module;
	}
}
