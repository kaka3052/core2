package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.commdata.TypeCaster;


public class TestProc extends DataProcess {
	
	private Object result = true;
	private String error = null;

	@Override
	public boolean execute() throws Exception {
		if(null != error)
			throw new Exception(error);
		return TypeCaster.toBoolean(evalValue(result));
	}

	@Override
	protected void setup() throws Exception {

	}
	
	public void setResult(Object value) {
		result = value;
	}
	
	public void setError(String value) {
		error = value;
	}

}
