package com.hp.itis.core2.procengine.bean;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.FieldMapper;
import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.procengine.VarFunLib;
import com.hp.itis.core2.vars.Evaluator;
import com.hp.itis.core2.vars.IEvaluator;
import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.MethodVars;

public class BeanBuilder implements IBeanBuilder {
	
	private IBeanFactory beanFacory;
	private Set<String> defPackages = new LinkedHashSet<String>();
	private Map<String, String> mapPackages = new HashMap<String, String>();
	private IVars vars = new MethodVars(VarFunLib.class);
	
	public BeanBuilder(IBeanFactory beanFacory) {
		this.beanFacory = beanFacory;
	}
	
	public BeanBuilder() {
	}
	
	public void setVars(IVars vars) {
		this.vars = vars;
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.procengine.bean.IBeanBuilder#createObject(java.lang.Class, com.hp.itis.core2.commdata.CommData, java.lang.Object)
	 */
	public Object createObject(Class<?> c, CommData params, Object... args) throws Exception {
		Object o;
		Constructor<?> co = null;
		//try find a constructor with args
		if(args.length>0) {
			Class<?>[] aTypes = new Class<?>[args.length];
			for(int i=0; i<args.length; i++) {
				aTypes[i] = args[i].getClass();
			}
			try {
				co = c.getConstructor(aTypes);
			} catch (Exception e) {	}
		}
		else {
			//try find a constructor with a CommData type argument 
			try {
				co = c.getConstructor(CommData.class);
			} catch (Exception e) {	}
		}
		Method im = null;
		if(null == co) {
			o = c.newInstance();
			if(null != params) {
				injectParams(o, params);
				//尝试执行带CommData参数的初始化方法
				try {
					im = c.getMethod("init", CommData.class);
					if(null != im);
						im.invoke(o, params);
				} catch (SecurityException e) {
				} catch (NoSuchMethodException e) {
				}
			}
		}
		else {
			if(args.length>0)
				o = co.newInstance(args);
			else
				o = co.newInstance(params);
			if(null != params)
				injectParams(o, params);
		}
		//如未执行初始化则尝试执行不带参数的初始化方法
		if(null == im) {
			try {
				im = c.getMethod("init");
				if(null != im);
					im.invoke(o);
			} catch (SecurityException e) {
			} catch (NoSuchMethodException e) {
			}
		}
		return o;
	}
	
	public void buildObject(Object o, CommData params) throws Exception {
		injectParams(o, params);
		Class<?> c = o.getClass();
		Method im = c.getMethod("init", CommData.class);
		if(null != im)
			im.invoke(o, params);
		else {
			im = c.getMethod("init");
			if(null != im)
				im.invoke(o);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.procengine.bean.IBeanBuilder#createObject(com.hp.itis.core2.commdata.CommData)
	 */
	public Object createObject(CommData params) throws Exception {
		String className = params.getString("class");
		if(null == className)
			className = params.getString("className");
		if(className == null)
			throw new Exception("Can not find any suitable class for: " +  params);
		return createObject(className, params);
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.procengine.bean.IBeanBuilder#createObject(java.lang.String, com.hp.itis.core2.commdata.CommData, java.lang.Object)
	 */
	public Object createObject(String className, CommData params, Object... args) throws Exception {
		Class<?> c = getClass(className);
		return createObject(c, params, args);
	}
	
	public void injectParams(Object target, CommData params) throws Exception {
		
		Class<?> c = target.getClass();
		Method ms[] = c.getMethods();
		Method m;
		for(int i = 0; i < ms.length; i++) {
			m = ms[i];
			String fName = FieldMapper.setterName(m);
			if (null != fName) {
				//调用set方法，设置pojo相应属性
				Object[] p = new Object[1];
				//对特殊类型进行必要的转换
				Class<?> pType = m.getParameterTypes()[0];
				Object o = params.get(fName);
				if(o instanceof String) {
					String v = (String) o;
					if(v.startsWith("[") && v.endsWith("]") && null != beanFacory) {
						v = v.substring(1, v.length()-1);
						if(v.startsWith("[") && v.endsWith("]"))
							o = v;
						else if(v.length()==0)
							o = beanFacory.getBean(pType);
						else {
							o = beanFacory.getBean(v, pType);
							if(null == o) {
								IEvaluator eval = Evaluator.build(v);
								o = eval.eval(vars);
							}
						}
					}
				}
				if(null == o)
					continue;
				p[0] = TypeCaster.cast(pType, o);
				m.invoke(target, p);
				params.put(fName, null);
			}
		}

	}
	
	public Class<?> findClass(String className) {
		if(null == className)
			return null;
		Class<?> c = loadClass(className);
		if(null != c)
			return c;
		if(mapPackages.containsKey(className)) {
			c = loadClass(mapPackages.get(className));
			if(null != c)
				return c;
		}
		for(String pName : defPackages) {
			c = loadClass(pName + className);
			if(null != c)
				return c;
		}
		return null;
	}
	
	private Class<?> loadClass(String className) {
		Class<?> c = null;
		try {
			c = Thread.currentThread().getContextClassLoader().loadClass(className);
			//c = Class.forName(className);
		} 
		catch (ClassNotFoundException e) {

		}
		return c;
	}
	
	/* (non-Javadoc)
	 * @see com.hp.itis.core2.procengine.bean.IBeanBuilder#getClass(java.lang.String)
	 */
	public Class<?> getClass(String className) throws ClassNotFoundException {
		Class<?> c = findClass(className);
		if(null == c)
			throw new ClassNotFoundException(className);
		return c;
	}
	
	public void importClass(String className) {
		if(className.endsWith(".*"))
			defPackages.add(className.substring(0, className.length()-1));
		else {
			String shortName;
			int p = className.lastIndexOf('.');
			if(p>=0)
				shortName = className.substring(p+1);
			else
				shortName = className;
			mapPackages.put(shortName, className);
		}
	}
	
	@Override
	public Object createObject(Class<?> c, Object... args) throws Exception {
		return createObject(c, null, args);
	}

	@Override
	public Object createObject(String className, Object... args)
			throws Exception {
		return createObject(className, null, args);
	}
	
	
}
