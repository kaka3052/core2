package com.hp.itis.core2.procengine.processes;


public class DispatchAllProc extends DispatchProc {
	
	@Override
	public boolean execute() throws Exception {
		Object v = value();
		if(null == v)
			return false;
		if(v instanceof Iterable<?>) {
			Iterable<?> i = (Iterable<?>)v;
			for(Object o : i) 
				dispatch(o);
		}
		else if(null != v)
			dispatch(v);
		return true;
	}

	@Override
	protected void setup() throws Exception {
		
	}

}
