package com.hp.itis.core2.procengine.processes;

import javax.script.Compilable;
import javax.script.CompiledScript;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import com.hp.itis.core2.file.TextFile;
import com.hp.itis.core2.vars.VarsBindings;

public class ScriptProc extends DataProcess {

	private String language = "JavaScript";
	private String script;
	private String fileName;
	private String charset;
	private String functionName;
	private boolean compile;
	private ScriptEngine engine;
	private CompiledScript compiled;
	private String resultKey;
	
	@Override
	protected boolean execute() throws Exception {
		Object r = null;
		if(compile) {
			if(null == compiled)
				compiled = ((Compilable)engine()).compile(script());
			r = compiled.eval(new VarsBindings(session().vars()));
		}
		else {
			r = engine().eval(script(), new VarsBindings(session().vars()));
		}
		if(null != functionName)
			r = ((Invocable)engine()).invokeFunction(functionName);
		if(null != resultKey && resultKey.length()>0)
			session().values().put(resultKey, r);
		else if(null == resultKey)
			value(r);
		return true;
	}

	@Override
	protected void setup() throws Exception {
		
	}
	
	private ScriptEngine engine() {
		if(null == engine) {
			ScriptEngineManager sem = new ScriptEngineManager();
			engine = sem.getEngineByName(language);
		}
		return engine;
	}
	
	private String script() throws Exception {
		String s = script;
		if(null == s && null != fileName)
			s = TextFile.loadResource(fileName, charset);
		if(null == s)
			throw new Exception("No script specified!");
		s = (String)evalValue(s);
		return s;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public void setScript(String script) {
		this.script = script;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public void setCompile(boolean compile) {
		this.compile = compile;
	}

	public void setResultKey(String resultKey) {
		this.resultKey = resultKey;
	}
	

}
