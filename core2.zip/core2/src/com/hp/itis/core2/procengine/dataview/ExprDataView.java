package com.hp.itis.core2.procengine.dataview;

import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.vars.Evaluator;
import com.hp.itis.core2.vars.IEvaluator;
import com.hp.itis.core2.vars.IFunVars;

public class ExprDataView extends EventView implements IEventView {

	private IEvaluator selector;
	private IFunVars funcVars;
	
	public ExprDataView(String expr, IFunVars funcVars) {
		this.funcVars = funcVars;
		if(null != expr)
			this.selector = Evaluator.build(expr);
	}

	@Override
	public boolean accept(Object data) {
		if(null != selector) {
			EventVars vars = new EventVars(data, funcVars);
			if(TypeCaster.toBoolean(selector.eval(vars)))
				return true;
		}
		return false;
	}
	
}
