package com.hp.itis.core2.procengine.processes;

public class DepressProc extends DataProcess {

	@Override
	protected boolean execute() throws Exception {
		if(null != session().event())
			session().event().depress();
		return true;
	}

	@Override
	protected void setup() throws Exception {

	}

}
