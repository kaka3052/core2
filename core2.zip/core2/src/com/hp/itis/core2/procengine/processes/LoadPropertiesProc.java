package com.hp.itis.core2.procengine.processes;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.regex.Pattern;

import com.hp.itis.core2.file.TextFile;
import com.hp.itis.core2.vars.AdvanceVarReplacer;
import com.hp.itis.core2.vars.IVarReplacer;

public class LoadPropertiesProc extends DataProcess {
	
	private String filePath;
	private Pattern filter = null;

	@Override
	protected void setup() throws Exception {
	}
	
	public void setFilePath(String value) {
		this.filePath = value;
	}
	
	public void setFilter(String value) {
		if(!"".equals(value))
			this.filter = Pattern.compile(value);
	}

	@Override
	public boolean execute() throws Exception {
		Properties properties = new Properties();
		InputStream is = TextFile.getResource(filePath);
		String t = TextFile.load(is);
		IVarReplacer pat = new AdvanceVarReplacer(t);
		t = pat.replace(session().vars());
		is = new ByteArrayInputStream(t.getBytes());
		try {
			if(is != null) {
				if(filePath.toLowerCase().endsWith(".xml"))
					properties.loadFromXML(is);
				else
					properties.load(is);
			}
			session().log().debug(200001, filePath);
		} catch (Exception e) {
			session().log().error(100001, filePath);
			throw e;
		}
		finally {
			if(null != is)
				try {
					is.close();
				} catch (IOException e) {}
		}
		for(Object key : properties.keySet()) {
			if(filter == null || filter.matcher(key.toString()).find()) {
				t = properties.getProperty(key.toString());
				session().values().put(key.toString(), t);
				session().log().trace(200002, key.toString(), t);
			}
		}
		return true;
	}

}
