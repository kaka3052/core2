package com.hp.itis.core2.procengine.module;

public interface IDataProvider {

	void setReceiver(IDataReceiver receiver);
	
}
