package com.hp.itis.core2.procengine.exception;

import com.hp.itis.core2.misc.SException;
import com.hp.itis.core2.procengine.module.IModule;

public class ModuleException extends SException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6148430434936903473L;
	private IModule module;

	public ModuleException(IModule module, Throwable cause)
	{
		super(module, cause);
		this.module = module;
	}
	
	public ModuleException(IModule module, String message, Throwable cause)
	{
		super(module, message, cause);
		this.module = module;
	}
	
	public ModuleException(IModule module, String message)
	{
		super(module, message);
		this.module = module;
	}
	
	public ModuleException(IModule module, int code, Object... args)
	{
		this(module, getMessage(module, code, args));
	}
	
	private static String getMessage(IModule module, Integer code, Object... args) {
		String message = mapMessage(module.name(), code, args);
		if(message == null)
			message = getMessage(module.getClass(), code, args);
		return message;
	}
	
	public IModule module()
	{
		return module;
	}

	public Throwable getSrcCause()
	{
		Throwable cause = getCause();
		if(null!=cause)
		{
			if(cause instanceof ModuleException)
				return ((ModuleException)cause).getSrcCause();
			else
				return cause;
		}
		else
			return this;
	}
}
