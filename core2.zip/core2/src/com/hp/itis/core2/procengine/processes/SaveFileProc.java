package com.hp.itis.core2.procengine.processes;

import java.io.File;
import java.io.InputStream;

import com.hp.itis.core2.file.TextFile;

public class SaveFileProc extends DataProcess {
	
	protected String toFile = "savefile.data";

	@Override
	protected boolean execute() throws Exception {
		return false;
	}
	
	public void execute(InputStream is) throws Exception {
		File file = session().getSessionFile(toFile);
		TextFile.save(file, is);
		value(null);
		value(file);
	}

	@Override
	protected void setup() throws Exception {
	}

}
