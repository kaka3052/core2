package com.hp.itis.core2.procengine.adapter;

import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventCondition;
import com.hp.itis.core2.event.IEventDemander;
import com.hp.itis.core2.event.IEventListener;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.module.IEngineContext;
import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.EnvVars;
import com.hp.itis.core2.vars.SysPropertyVars;

public class ProcEngineService implements ApplicationContextAware, InitializingBean, DisposableBean, IEventDemander {

	private String configPath = null;
	private ProcEngine procEngine;
	private ApplicationContext context;
	private Map<String, IEventListener> listeners = null;
	
	public void setConfig(String v) {
		configPath = v;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		procEngine = ProcEngine.instance();
		procEngine.addBeanFactory(new SpringBeanFactory(context));
		procEngine.loadDefination(configPath, new CombinedVars(new EnvVars(), new SysPropertyVars()));
		procEngine.start();
		if(null != listeners) {
			for(String key : listeners.keySet())
				addListener(key, listeners.get(key));
		}
	}

	@Override
	public void destroy() throws Exception {
		if(null != listeners) {
			for(String key : listeners.keySet())
				removeListener(key, listeners.get(key));
		}
		procEngine.stop();
		procEngine.awaitStop();
	}

	@Override
	public void addListener(String type, IEventListener listener) {
		procEngine.eventBus().addListener(type, listener);
	}

	@Override
	public void addListener(IEventListener listener) {
		procEngine.eventBus().addListener(listener);
	}

	@Override
	public void clearListeners() {
		procEngine.eventBus().clearListeners();
	}

	@Override
	public void dispatch(IEvent event) {
		procEngine.eventBus().dispatch(event);
	}
	
	public void dispatch(String eventName, Object data) {
		procEngine.dispatch(data, eventName);
	}
	
	public IEvent dispatch(Object data) {
		return procEngine.dispatch(data);
	}
	
	public void dispatch(Object data, String eventName, long delay) {
		procEngine.dispatch(data, eventName, delay);
	}
	
	public void dispatch(Object data, long delay) {
		procEngine.dispatch(data, delay);
	}
	
	@Override
	public IEvent demand(IEvent event, long timeout)
			throws InterruptedException {
		return procEngine.demand(event, timeout);
	}

	@Override
	public IEvent waitEvent(IEventCondition condition, long timeout)
			throws InterruptedException {
		return procEngine.waitEvent(condition, timeout);
	}
	
	public Object demand(Object data, long timeout)
			throws InterruptedException {
		return procEngine.demand(data, timeout);
	}
	
	public Object demand(String eventName, Object data, long timeout)
			throws InterruptedException {
		return procEngine.demand(data, eventName, timeout);
	}
	
	@Override
	public void supply(IEvent event, Object result) {
		procEngine.supply(event, result);
	}
	
	public boolean callTask(String taskName, CommData params) {
		try {
			return procEngine.callTask(params, taskName);
		} catch (Exception e) {
			procEngine.log().error(e);
			return false;
		}
	}
	
	public boolean callTask(String taskName) {
		try {
			return procEngine.callTask(new CommDataImpl(), taskName);
		} catch (Exception e) {
			procEngine.log().error(e);
			return false;
		}
		
	}
	
	public boolean callTask(String taskName, Map<String, Object> params) {
		try {
			return procEngine.callTask(new CommDataImpl(params), taskName);
		} catch (Exception e) {
			procEngine.log().error(e);
			return false;
		}
	}
	
	@Override
	public boolean hasListener(String type) {
		return procEngine.eventBus().hasListener(type);
	}

	@Override
	public void removeListener(String type, IEventListener listener) {
		procEngine.eventBus().removeListener(type, listener);
	}

	@Override
	public void removeListener(IEventListener listener) {
		procEngine.eventBus().removeListener(listener);
	}

	@Override
	public void setApplicationContext(ApplicationContext context)
			throws BeansException {
		this.context = context;
	}
	
	public void setListeners(Map<String, IEventListener> listeners) {
		this.listeners = listeners;
	}
	
	public IEngineContext engineContext() {
		return procEngine;
	}

}
