package com.hp.itis.core2.procengine.bean;

import java.util.Collection;

public interface IBeanFactory {
	Object getBean(String name);
	Object getBean(String name, Class<?> c);
	Object getBean(Class<?> c);
	Collection<?> getBeans(Class<?> c);
}
