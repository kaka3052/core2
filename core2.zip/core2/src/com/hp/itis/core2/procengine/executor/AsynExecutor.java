package com.hp.itis.core2.procengine.executor;

import java.io.File;
import java.io.Serializable;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.SynchronousQueue;

import com.hp.itis.core2.event.Event;
import com.hp.itis.core2.pqueue.PersistentBlockingQueue;
import com.hp.itis.core2.pqueue.PersistentFilter;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.module.ActiveModule;
import com.hp.itis.core2.procengine.module.Module;

/**
 * 异步执行器
 * 
 * @author changjiang
 *
 */

public class AsynExecutor extends ActiveModule implements IExecutor {
	 
	/**内部消息队列*/
	private BlockingQueue<Serializable> queue;
	private IExecutable exec;
	private int queueSize;
	private boolean persistent;


	public AsynExecutor(IExecutable exec, int queueSize, boolean persistent) throws Exception
	{
		this.exec = exec;
		this.queueSize = queueSize;
		this.persistent = persistent;
	}
	
	public String name() {
		if(exec instanceof Module)
			return super.name() + "." + ((Module)exec).name();
		else
			return super.name();
	}
	
	private String queueName() {
		return ((Module)exec).name();
	}
	
	private synchronized BlockingQueue<Serializable> queue() throws Exception {
		if(null != queue)
			return queue;
		if(queueSize>0) {
			if(persistent) {
				File queueFile = ProcEngine.instance().context().getDataFile(queueName() + ".queue");
				queue = new PersistentBlockingQueue<Serializable>(queueFile, queueSize);
				PersistentFilter filter = (PersistentFilter)ProcEngine.instance().getBean(PersistentFilter.class);
				((PersistentBlockingQueue<Serializable>)queue).setFilter(filter);
			}
			else
				queue = new ArrayBlockingQueue<Serializable>(queueSize);
		}
		else
			queue = new SynchronousQueue<Serializable>();
		return queue;
	}
	
	@Override
	public void execute(Object task) throws Exception {
		try {
			int queueSize = queue().size();
			if(queueSize>0) {
				log().debug(20001, queueSize);
			}
			queue.put((Serializable)task);
		} catch (InterruptedException e) {
			//log().debug(e);
		}
	}
	
	protected void doExecute(Object task) throws Exception	{
		try
		{
			exec.execute(task);
		}
		catch(Throwable e)
		{
			dispatch(new Event(EXEC_ERROR, task, e)); 
		}
		dispatch(new Event(EXEC_DONE, task, null));
	}
	
	public void run()
	{
		try {
			Object task = queue().take();
			doExecute(task);
		}
		catch (InterruptedException e) {
		}
		catch(Exception e1) {
			throw new RuntimeException(e1);
		}
		finally {
			if(null != queue && queue.isEmpty()) {
				synchronized(queue) {
					queue.notify();
				}
			}
		}
	}

	@Override
	public void setExecutable(IExecutable exec) {
		this.exec = exec;
	}

	@Override
	protected void deactivate() {
		if(null != queue && queue instanceof PersistentBlockingQueue<?>)
			while(!queue.isEmpty()) {
				try {
					synchronized(queue) {
						queue.wait();
					}
				} catch (InterruptedException e) {
					break;
				}
			}
		super.deactivate();
	}
	
}
