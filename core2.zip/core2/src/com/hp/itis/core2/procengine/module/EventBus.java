package com.hp.itis.core2.procengine.module;

import java.io.File;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.SynchronousQueue;

import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventDispatcher;
import com.hp.itis.core2.pqueue.PersistentBlockingQueue;
import com.hp.itis.core2.pqueue.PersistentFilter;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.exception.ModuleException;

public class EventBus extends ActiveModule implements IActiveModule, IEventDispatcher {
	
	private BlockingQueue<IEvent> queue = null;
	private EventScheduler scheduler;
	private PersistentFilter persistentEventsFilter = null;
	
	public EventBus(int queueSize) throws Exception {
		if(queueSize==0)
			queue = new SynchronousQueue<IEvent>();
		else if(queueSize>0) {
			
			boolean persistent = ProcEngine.instance().context().get("core.queuePersistent", false);
			if(persistent) {
				File queueFile = ProcEngine.instance().context().getDataFile(this.name() + ".queue");
				queue = new PersistentBlockingQueue<IEvent>(queueFile, queueSize);
				PersistentFilter filter = (PersistentFilter)ProcEngine.instance().getBean(PersistentFilter.class);
				((PersistentBlockingQueue<IEvent>)queue).setFilter(filter);
			}
			else
				queue = new ArrayBlockingQueue<IEvent>(queueSize);
		}
		try {
			scheduler = new EventScheduler();
			scheduler.setEventTarget(this);
		} catch (Exception e) {
			log().error(e);
		}
	}

	public void dispatch(IEvent event) {
		try {
			if(null != queue) {
				log().debug(20001, event.toString(), queue.size());
				queue.put(event);
			}
			else {
				log().debug(20001, event.toString(), 0);
				super.dispatch(event);
			}
		} catch (InterruptedException e) {
		}
	}

	@Override
	public void run() {
		try {
			IEvent event = queue.take();
			super.dispatch(event);
		} 
		catch (InterruptedException e) {
		}
		finally {
			if(queue.isEmpty()) {
				synchronized(queue) {
					queue.notify();
				}
			}
		}
	
	}
	
	public IEvent dispatch(Object data, String target) {
		IEvent event = createEvent(data, target, false);
		dispatch(event);
		return event;
	}
	
	public IEvent dispatch(Object data) {
		IEvent event = createEvent(data);
		dispatch(event);
		return event;
	}
	
	public IEvent dispatch(Object data, String target, long delay) {
		IEvent event = createEvent(data, target, false);
		scheduler.schedule(event, delay);
		return event;
	}
	
	public IEvent dispatch(Object data, long delay) {
		IEvent event = createEvent(data);
		scheduler.schedule(event, delay);
		return event;
	}
	
	public Object demand(Object data, long timeout) throws InterruptedException {
		IEvent event = createEvent(data);
		event = demand(event, timeout);
		if(null == event)
			return null;
		return event.data();
	}
	
	public Object demand(Object data, String target, long timeout) throws InterruptedException {
		IEvent event = createEvent(data, target, false);
		event = demand(event, timeout);
		if(null == event)
			return null;
		return event.data();
	}
	
	public IEvent createEvent(Object data) {
		return createEvent(data, null, false);
	}
	
	public static IEvent createEvent(Object data, Object source, String target, boolean sync) {
		return createEvent(data, target, sync);
	}
	
	public static IEvent createEvent(Object data, String target, boolean sync) {
		return CommEvent.createEvent(data, target, sync);
	}
	
	public PersistentFilter persistentEventsFilter() {
		return persistentEventsFilter;
	}

	@Override
	protected void activate() {
		if(null != queue)
			super.activate();
		try {
			scheduler.setActive(true);
		} catch (ModuleException e) {
			log().error(e, e);
		}
	}

	@Override
	protected void deactivate() {
		try {
			scheduler.setActive(false);
		} catch (ModuleException e) {
			log().error(e, e);
		}
		if(null != queue) {
			while(!queue.isEmpty()) {
				try {
					synchronized(queue) {
						queue.wait();
					}
				} catch (InterruptedException e) {
					break;
				}
			}
			super.deactivate();
		}
	}
	
}
