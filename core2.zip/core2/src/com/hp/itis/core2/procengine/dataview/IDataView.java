package com.hp.itis.core2.procengine.dataview;

public interface IDataView {
	boolean accept(Object data);
}
