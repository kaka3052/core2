package com.hp.itis.core2.procengine.triggers;

import com.hp.itis.core2.misc.StrUtil;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.module.IActiveModule;
import com.hp.itis.core2.procengine.module.WrappedActiveModule;

public abstract class IntervalTrigger extends AsynTrigger implements IActiveModule {

	protected WrappedActiveModule module = new WrappedActiveModule(this);
	protected long interval = 1000;
	
	public long interval() {
		return interval;
	}
	
	public void setInterval(String v) {
		//默认单位为ms
		if(null != v && v.length()>0)
			interval = StrUtil.str2Millisec(v);
	}
	
	@Override
	protected void activate() {
		module.activate();
	}

	@Override
	protected void deactivate() {
		module.deactivate();
	}

	@Override
	protected void setup() throws ModuleException {
		
	}

	@Override
	abstract public void run();

}
