package com.hp.itis.core2.procengine.module;

import com.hp.itis.core2.commdata.FieldMap;
import com.hp.itis.core2.event.EventDemander;
import com.hp.itis.core2.misc.PLog;

abstract public class Module extends EventDemander implements IModule {

	private IModule parent = null;
	private String moduleName = null;
	private PLog log = null;
	
	public Module() {
		this(null);
	}
	
	public Module(String moduleName) {
		this(moduleName, null);
	}
	
	
	public Module(String moduleName, IModule parent) {
		this.parent = parent;
		this.moduleName = moduleName;
	}
	
	@Override
	public String fullName() {
		if(parent != null)
			return parent.fullName() + "." + name();
		else
			return name();
	} 

	@Override
	public PLog log() {
		if(null == log)
			log = new ModuleLog(this);
		return log;
	}

	@Override
	@FieldMap("name")
	public String name() {
		if(null == moduleName)
			return this.getClass().getSimpleName();
		return moduleName;
	}

	@Override
	@FieldMap("name")
	public void name(String value) {
		moduleName = value;
	}

	@Override
	public IModule parent() {
		return parent;
	}

	@Override
	public void parent(IModule value) {
		parent = value;
	}
	
	@Override
	public String toString() {
		return super.toString() + "#" +fullName();
	}

}
