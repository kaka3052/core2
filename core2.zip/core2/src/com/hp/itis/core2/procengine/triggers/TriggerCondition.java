package com.hp.itis.core2.procengine.triggers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.Digestible;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventDispatcher;
import com.hp.itis.core2.misc.SException;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.module.CommEvent;
import com.hp.itis.core2.procengine.module.EventBus;
import com.hp.itis.core2.procengine.module.Module;
import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.CommDataVars;
import com.hp.itis.core2.vars.IVars;

@Digestible
abstract public class TriggerCondition extends Module implements ITriggerCondition {
	
	protected CommData params;
	protected IVars vars;
	protected Object eventValue;
	protected IEventDispatcher target;
	protected List<String> events = new ArrayList<String>();
	protected boolean syncEvent = false;
	
	abstract protected Object doCheck();
	
	abstract protected void setup() throws SException ;
	
	public void init(CommData params)
			throws SException {
		this.params = params;
		vars = new CombinedVars(new CommDataVars(params), ProcEngine.instance());
		setup();
	}
	
	public void setClass(String v){

	}
	
	public void setEventValue(Object v) {
		eventValue = v;
	}

	@Override
	public void setEventTarget(IEventDispatcher target) {
		this.target = target;
	}
	
	public void setEvent(String v) {
		String[] tasks = v.split(",");
		for(int i=0; i< tasks.length ;i++)
			events.add(tasks[i].trim());
	}
	
	public void setSyncEvent(boolean v) {
		syncEvent = v;
	}

	@Override
	public boolean check() {
		Object o = doCheck();
		boolean r = null != o;
		if(r) {
			if(o instanceof Boolean) {
				r =  (Boolean)o;
				if(r) {
					trigger(eventValue);
				}
			}
			else if(o instanceof Collection<?>) {
				for(Object item : (Collection<?>)o)
					trigger(item);
			}
			else
				trigger(o);
		}
		return r;
	}

	
	protected void trigger() {
		trigger(null);
	}
	
	protected void trigger(Object data) {
		if(events.size()>0) {
			for(String event : events)
				sendEvent(event, data);
		}
		else
			sendEvent(null, data);
	}
	
	protected void sendEvent(String t, Object data) {
		if(null != t && !target.hasListener(t))
			return;
		IEvent event = EventBus.createEvent(data, t, syncEvent);
		if(event instanceof CommEvent) {
			CommEvent commEvent = (CommEvent)event;
			CommData params = ProcEngine.instance().updateParams(this.params);
			for(String key : params.keySet()) {
				commEvent.put(key, params.get(key));
			}
		}
		target.dispatch(event);
	}
	
}
