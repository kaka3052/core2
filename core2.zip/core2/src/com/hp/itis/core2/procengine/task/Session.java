package com.hp.itis.core2.procengine.task;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.file.FileOperate;
import com.hp.itis.core2.misc.PLog;
import com.hp.itis.core2.procengine.ProcEngine;
import com.hp.itis.core2.procengine.module.CommEvent;
import com.hp.itis.core2.procengine.module.IModule;
import com.hp.itis.core2.vars.AutomaticVars;
import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.CommDataVars;
import com.hp.itis.core2.vars.IFunVars;
import com.hp.itis.core2.vars.IVars;

public class Session implements ISession {
	
	private IEvent event;
	private boolean finished = false;
	private Throwable lastError = null;
	private boolean result = true;
	private String sessionID;
	private CommData values;
	private IVars vars;
	private File sessionDir = null;
	protected long startTime = System.currentTimeMillis();
	protected long procStartTime = 0;
	protected IModule currentModule = null;
	protected static volatile int seqid = 0;
	protected PLog log;
	
	public Session(IEvent event) {
		this(event.data());
		this.event = event;
	}
	
	public Session(Object v) {
		Date now = new Date();
		DateFormat df = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		sessionID = df.format(now) + String.format("%05d", ++seqid);
		if(v instanceof CommData)
			values = (CommData)v;
		else {
			if(null != v) {
				values = new CommDataImpl(v);
				value(v);
			}
			else
				values = new CommDataImpl();
		}
		vars = new CombinedVars( 
			new IFunVars() {
				IFunVars vars;
				Object v;
				public void update() {
					Object cv = value(); 
					if(cv == v)
						return;
					if(cv == null)
						vars = null;
					else
						vars = new AutomaticVars(cv);
				}
			
				@Override
				public Object eval(String fun, List<Object> params) {
					update();
					if(null == vars)
						return null;
					return vars.eval(fun, params);
				}
	
				@Override
				public Object get(String key) {
					if(null == key)
						return null;
					if(key.startsWith("_")) {
						if("_VALUE".equals(key))
							return value();
						if("_RESULT".equals(key))
							return result;
						if("_SESSION_ID".equals(key))
							return sessionID;
						if("_LAST_ERROR".equals(key))
							return lastError;
						if("_LAST_ERROR_MESSAGE".equals(key)) {
							if(null == lastError)
								return "";
							else
								return lastError.toString();
						}
						if("_EVENT".equals(key))
							return event;
						if("_EVENT_NAME".equals(key))
							return event.type();
						if("_EVENT_DATA".equals(key))
							return event.data();
						if("_EVENT_SOURCE".equals(key))
							return event.source();
						if("_SESSION_DIR".equals(key))
							return getSessionDir().getPath();
					}
					if(event instanceof CommEvent) {
						Object v = ((CommEvent)event).get(key);
						if(null != v)
							return v;
					}
					update();
					if(null == vars)
						return null;
					return vars.get(key);
				}
		
			},
			new CommDataVars(values),
			ProcEngine.instance());
		log = new SessionLog(this);
	}

	@Override
	public IEvent event() {
		return event;
	}

	@Override
	public long duration() {
		return System.currentTimeMillis() - startTime;
	}

	@Override
	public void end() {
		if(!finished) {
			finished = true;
			synchronized(this) {
				this.notifyAll();
			}
			deleteSessionDir();
		}
	}

	@Override
	public boolean finished() {
		return finished;
	}

	@Override
	public Throwable lastError() {
		return lastError;
	}

	@Override
	public PLog log() {
		return log;
	}

	@Override
	public void report(boolean result) {
		this.result = result;
	}

	@Override
	public void report(Throwable e) {
		report(false);
		lastError = e;
	}

	@Override
	public boolean result() {
		return result;
	}

	@Override
	public String sessionID() {
		return sessionID;
	}

	@Override
	public long startTime() {
		return startTime;
	}

	@Override
	public CommData values() {
		return values;
	}

	@Override
	public IVars vars() {
		return vars;
	}

	@Override
	public IModule currentModule() {
		return currentModule;
	}
	
	@Override
	public String toString() {
		return this.getClass().getSimpleName() + "." + sessionID;
	}

	@Override
	synchronized public void waitToFinish() {
		while(!finished)
			try {
				this.wait();
			} catch (InterruptedException e) {
			}
	}

	@Override
	public long procDuration() {
		if(0 == procStartTime)
			return 0;
		return System.currentTimeMillis() - procStartTime;
	}

	@Override
	public Object value() {
		CommData value = values.getChild(KEY_VALUE);
		if(null == value)
			return null;
		return value.get("");
	}
	
	@Override
	public Object value(Class<?> clazz) {
		CommData value = values.getChild(KEY_VALUE);
		if(null == value)
			return null;
		if(null != value.get(clazz.getName()))
			return value.get(clazz.getName());
		for(Object v : value)
			if(clazz.isInstance(v))
				return v;
		return null;
	}

	@Override
	public void value(Object v) {
		if(null == v) {
			values.put(KEY_VALUE, null);
			return;
		}
		CommData value = values.getChild(KEY_VALUE);
		if(null == value)
			value = values.add(KEY_VALUE);
		value.put(v.getClass().getName(), v);
		value.put("", v);
	}

	@Override
	public Object deriveValue() {
		if(value() != null)
			return value();
		else {
			CommData data = new CommDataImpl();
			for(String key : values().keySet())
				if(!key.startsWith("_"))
					data.put(key, values().get(key));
			return data;
		}
	}
	
	public File getSessionDir() {
		if(null == sessionDir) {
			sessionDir = ProcEngine.instance().context().getTempFile(sessionID + "");
			sessionDir.mkdir();
		}
		return sessionDir;
	}
	
	public void deleteSessionDir() {
		if(null != sessionDir)
			FileOperate.delete(sessionDir);
	}
	
	@Override
	public File getSessionFile(String fileName) {
		File file = new File(fileName);
		if(file.isAbsolute())
			return file;
		File dir = getSessionDir();
		return ProcEngine.instance().context().getTempFile(dir.getPath() + "/" + fileName);
	}

}
