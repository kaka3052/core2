package com.hp.itis.core2.procengine.executor;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventListener;
import com.hp.itis.core2.procengine.exception.ModuleException;
import com.hp.itis.core2.procengine.module.ControllableModule;
import com.hp.itis.core2.procengine.module.IControllableModule;
import com.hp.itis.core2.procengine.module.IModule;

public class Executor extends ControllableModule implements IExecutor {
	
	private IExecutor executor;
	private int runMode = RM_SYNC;
	private int maxConc = 2;
	private int queueSize = 100;
	private IExecutable exec;
	private boolean queuePersistent = false;
	
	public Executor() {
	}
	
	public String name() {
		if(exec instanceof IModule)
			return super.name() + "." + ((IModule)exec).name();
		else
			return super.name();
	}
	
	public Executor(IExecutable exec) {
		this.exec = exec;
	}
	
	public void setRunMode(String value) {
		if("sync".equalsIgnoreCase(value))
			runMode = RM_SYNC;
		else if("asyn".equalsIgnoreCase(value))
			runMode = RM_ASYN;
		else if("conc".equalsIgnoreCase(value))
			runMode = RM_CONC;
		else if("asco".equalsIgnoreCase(value))
			runMode = RM_ASCO;
	}
	
	public void init(CommData params) throws Exception {
		switch(runMode)
		{
			case RM_SYNC:
				executor = new SyncExecutor(exec);
				break;
			case RM_ASYN:
				executor = new AsynExecutor(exec, queueSize, queuePersistent);
				break;
			case RM_CONC:
				executor = new ConcExecutor(exec, maxConc);
				break;
			case RM_ASCO:
				executor = new AscoExecutor(exec, queueSize, queuePersistent, maxConc);
		}
		
	}
	
	public void setMaxConc(int value) {
		maxConc = value;
	}
	
	public void setQueueSize(int value) {
		queueSize = value;
	}
	
	public void setPersistentQueue(boolean v) {
		queuePersistent = v;
	}
	
	@Override
	public void execute(Object task) throws Exception{
		executor.execute(task);
	}

	@Override
	protected void activate() throws ModuleException {
		if(executor instanceof IControllableModule)
			((IControllableModule)executor).setActive(true);
	}

	@Override
	protected void deactivate() throws ModuleException {
		if(executor instanceof IControllableModule)
			((IControllableModule)executor).setActive(false);
	}

	@Override
	public void setExecutable(IExecutable exec) {
		this.exec = exec;
		if(executor != null)
			executor.setExecutable(exec);
	}

	@Override
	public void addListener(String type, IEventListener listener) {
		executor.addListener(type, listener);
	}

	@Override
	public void dispatch(IEvent event) {
		executor.dispatch(event);
	}

	@Override
	public void removeListener(String type, IEventListener listener) {
		executor.removeListener(type, listener);
	}

	@Override
	public boolean hasListener(String type) {
		return executor.hasListener(type);
	}

	@Override
	public void clearListeners() {
		executor.clearListeners();
	}
	
}
