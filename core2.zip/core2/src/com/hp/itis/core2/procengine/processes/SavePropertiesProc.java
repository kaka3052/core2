package com.hp.itis.core2.procengine.processes;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;
import java.util.regex.Pattern;

import com.hp.itis.core2.file.TextFile;
import com.hp.itis.core2.vars.AdvanceVarReplacer;
import com.hp.itis.core2.vars.IVarReplacer;

public class SavePropertiesProc extends DataProcess {

	private String filePath;
	private Pattern filter = Pattern.compile("^[^_].*");

	@Override
	protected void setup() throws Exception {
	}
	
	public void setFilePath(String value) {
		this.filePath = value;
	}
	
	public void setFilter(String value) {
		if(!"".equals(value))
			this.filter = Pattern.compile(value);
	}

	@Override
	public boolean execute() throws Exception {
		Properties properties = new Properties();
		boolean xmlFormat = filePath.toLowerCase().endsWith(".xml");
		
		InputStream is = TextFile.getResource(filePath);
		String t;
		if(null != is) {
			t = TextFile.load(is);
			IVarReplacer pat = new AdvanceVarReplacer(t);
			t = pat.replace(session().vars());
			is = new ByteArrayInputStream(t.getBytes());
			try {
				if(is != null) {
					if(xmlFormat)
						properties.loadFromXML(is);
					else
						properties.load(is);
				}
			} catch (Exception e) {
				return false;
			}
			finally {
				if(null != is)
					try {
						is.close();
					} catch (IOException e) {}
			}
		}
		for(String key : session().values().keySet()) {
			if(filter == null || filter.matcher(key).find()) {
				t = session().values().getString(key);
				properties.put(key, t);
				session().log().trace(200002, key.toString(), t);
			}
		}
		OutputStream os = null;
		try {
			os = new FileOutputStream(filePath);
			if(xmlFormat)
				properties.storeToXML(os, null);
			else
				properties.store(os, null);
			session().log().debug(200001, filePath);
		} catch (Exception e) {
			session().log().error(100001, filePath);
			throw e;
		}
		finally {
			if(null != os)
				try {
					os.close();
				} catch (IOException e) {}
		}
		return true;
	}
	
}
