package com.hp.itis.core2.procengine.module;

public interface IDataReceiver {
	
	void onData(Object data);
	
}
