package com.hp.itis.core2.procengine.processes;


public class DebugProc extends DataProcess {

	@Override
	protected void setup() throws Exception {

	}

	@Override
	public boolean execute() throws Exception {
		session().log().debug("Session Variables:\n" + session().values());
		return true;
	}

}
