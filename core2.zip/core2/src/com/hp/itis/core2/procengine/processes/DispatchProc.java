package com.hp.itis.core2.procengine.processes;

import com.hp.itis.core2.misc.StrUtil;
import com.hp.itis.core2.procengine.ProcEngine;

public class DispatchProc extends DataProcess {
	
	private String target;
	private long delay = 0;
	private Object value;

	@Override
	public boolean execute() throws Exception {
		Object v = this.evalValue(value);
		if(null == v)
			v = session();
		dispatch(v);
		return true;
	}
	
	protected void dispatch(Object v) {
		if(delay>0)
			ProcEngine.instance().dispatch(v, target, delay);
		else
			ProcEngine.instance().dispatch(v, target);
	}

	@Override
	protected void setup() throws Exception {
		
	}

	public void setEvent(String v) {
		this.target = v;
	}
	
	public void setDelay(String delay) {
		this.delay = StrUtil.str2Millisec(delay);
	}
	
	public void setValue(Object value) {
		this.value = value;
	}
}
