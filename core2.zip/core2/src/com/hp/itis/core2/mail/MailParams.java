package com.hp.itis.core2.mail;


public class MailParams extends MailMessage {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1549728749109459612L;
	
	private String smtpServer;
	private String popServer;
	private String storeDir;
	private String imapServer;
	private boolean needLogin;
	private String username;
	private String password;
	private String charset = "utf8";
	private String mimeType = "text/html";
	private boolean debugMode = false;

	public String getSmtpServer() {
		return smtpServer;
	}
	public void setSmtpServer(String smtpServer) {
		this.smtpServer = smtpServer;
	}
	public String getUsername() {
		return username;
	}
	public String getImapServer() {
		return imapServer;
	}
	public void setImapServer(String imapServer) {
		this.imapServer = imapServer;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isNeedLogin() {
		return needLogin;
	}
	public void setNeedLogin(boolean needLogin) {
		this.needLogin = needLogin;
	}
	public String getCharset() {
		return charset;
	}
	public void setCharset(String charset) {
		this.charset = charset;
	}
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	public String getPopServer() {
		return popServer;
	}
	public void setPopServer(String popServer) {
		this.popServer = popServer;
	}
	public boolean isDebugMode() {
		return debugMode;
	}
	public void setDebugMode(boolean debugMode) {
		this.debugMode = debugMode;
	}
	public String getStoreDir() {
		return storeDir;
	}
	public void setStoreDir(String storeDir) {
		this.storeDir = storeDir;
	}   
}
