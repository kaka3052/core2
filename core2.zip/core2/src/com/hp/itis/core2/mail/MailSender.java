package com.hp.itis.core2.mail;

import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;

public class MailSender {
	
	private Pattern addrPattern = Pattern.compile("([^<>\\[\\]]+)\\s*([<\\[]([\\w\\-\\.]+@([\\w\\-]+\\.)+[a-zA-Z]+)[>\\]])?");
	private InternetAddress[] buildRecipients(String str, String charset) throws Exception {
		if(null == str || "".equals(str))
			return null;
        String[] recipients = str.split("[,;]");
        InternetAddress[] addresses = new InternetAddress[recipients.length];
        for(int i=0; i<recipients.length; i++) {
        	Matcher matcher = addrPattern.matcher(recipients[i].trim());
        	if(!matcher.find())
        		continue;
        	if(null == matcher.group(3))
        		addresses[i] = new InternetAddress(matcher.group(1));
        	else {
        		addresses[i] = new InternetAddress(matcher.group(3), matcher.group(1), charset);
        	}
        }
        return addresses;
	}

	public void sendMail(final MailParams params) throws Exception {
        Session session=null;   
        Properties props = System.getProperties();   
        props.put("mail.smtp.host", params.getSmtpServer());   
        if(params.isNeedLogin()){ 
            props.put("mail.smtp.auth","true");
            Authenticator smtpAuth = new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {    
                    return new PasswordAuthentication(params.getUsername(), params.getPassword());    
                }    
            };
            session=Session.getDefaultInstance(props, smtpAuth);    
        }else{   
            props.put("mail.smtp.auth","false");   
            session=Session.getDefaultInstance(props, null);   
        }   
        session.setDebug(params.isDebugMode());   
        Transport trans = null;
        Message msg = null; 
        try {   
        	msg = new MimeMessage(session);
            
            //set sender
        	InternetAddress[] addrs = buildRecipients(params.getFrom(), params.getCharset());
        	if(null != addrs) {
	            Address from_address = addrs[0];
	            msg.setFrom(from_address);
        	}
            //set recipients
            msg.setRecipients(Message.RecipientType.TO, buildRecipients(params.getTo(), params.getCharset()));  	
            if(null != params.getCc())
            	msg.setRecipients(Message.RecipientType.CC, buildRecipients(params.getCc(), params.getCharset()));
            if(null != params.getBcc())
            	msg.setRecipients(Message.RecipientType.BCC, buildRecipients(params.getBcc(), params.getCharset()));
            
            //set subject
            msg.setSubject(MimeUtility.encodeText(params.getSubject(), params.getCharset(), "B"));
            
            //set contents
            Multipart mp = new MimeMultipart();   
            MimeBodyPart mbp = new MimeBodyPart();
            mbp.setContent(params.getContent(), params.getMimeType() + ";charset="+params.getCharset());
            mp.addBodyPart(mbp);     
            
            //has attachments
            if(null != params.getAttachments()){
            	String[] attachments = params.getAttachments().split("[;,]");
            	for(int i=0; i<attachments.length; i++) {
            		String attachment = attachments[i];
            		mbp=new MimeBodyPart();
            		FileDataSource fds=new FileDataSource(attachment);
                    mbp.setDataHandler(new DataHandler(fds));
                    mbp.setFileName(MimeUtility.encodeText(fds.getName(), params.getCharset(), "B"));
                    mp.addBodyPart(mbp);  
            	}     
            }    
            msg.setContent(mp);
            msg.setSentDate(params.getSentDate());
            msg.saveChanges();
        }
        catch(Exception e) {
        	params.setTtl(0);
        	throw e;
        }
        try {
            trans = session.getTransport("smtp");   
            trans.connect(params.getSmtpServer(), params.getUsername(), params.getPassword());   
            trans.sendMessage(msg, msg.getAllRecipients());   
            trans.close();
        }
        finally {
        	params.setTtl(params.getTtl()-1);
        	if(null != trans)
        		trans.close();
        }
	}
}
