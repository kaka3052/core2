package com.hp.itis.core2.mail;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MailMessage implements Serializable {

	/**
	 * 
	 */
	private static int seq=0;
	
	private static final long serialVersionUID = 878239053508395235L;
	private long msgId = getNext();
	private int ttl = 10;
	private boolean isNew;
	private String from;
	private String to;
	private String cc;
	private String bcc;
	private String subject;
	private String content;
	private String attachments;
	private Date sentDate = new Date();
	
	private synchronized static long getNext() {
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddhhmmss");
		seq++;
		seq = seq % 1000;
		return Long.valueOf(df.format(new Date()))*1000 + seq;
	}
	
	public long getMsgId() {
		return msgId;
	}
	public void setMsgId(long msgId) {
		this.msgId = msgId;
	}
	
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAttachments() {
		return attachments;
	}
	public void setAttachments(String attachments) {
		this.attachments = attachments;
	}
	public Date getSentDate() {
		return sentDate;
	}
	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}
	public String getCc() {
		return cc;
	}
	public void setCc(String cc) {
		this.cc = cc;
	}
	public String getBcc() {
		return bcc;
	}
	public void setBcc(String bcc) {
		this.bcc = bcc;
	}
	public boolean isNew() {
		return isNew;
	}
	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}  
	 
	public String toString() {
		return "[" + sentDate + "] \"" + subject + "\" from " + from;
	}

	public int getTtl() {
		return ttl;
	}
	public void setTtl(int ttl) {
		this.ttl = ttl;
	}
	
}
