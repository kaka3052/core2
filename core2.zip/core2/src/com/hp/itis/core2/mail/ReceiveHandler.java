package com.hp.itis.core2.mail;

public interface ReceiveHandler {
	boolean accept(MailMessage message);
}
