package com.hp.itis.core2.mail;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.URLName;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;

import com.hp.itis.core2.file.TextFile;

public class MailReceiver {
	
	public List<MailMessage> receive(final MailParams params, ReceiveHandler handler) throws Exception {
		Session session = null;
		Properties props = System.getProperties();
		props.put("mail.smtp.host", params.getSmtpServer());
		if (params.isNeedLogin()) {
			props.put("mail.smtp.auth", "true");
			Authenticator smtpAuth = new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(params.getUsername(),
							params.getPassword());
				}
			};
			session = Session.getDefaultInstance(props, smtpAuth);
		} else {
			props.put("mail.smtp.auth", "false");
			session = Session.getDefaultInstance(props, null);
		}
		URLName urln = null;
		if(null != params.getPopServer()) {
			urln = new URLName("pop3", params.getPopServer(), 110, null,
				params.getUsername(), params.getPassword());
		}
		else if(null != params.getPopServer()) {
			urln = new URLName("imap", params.getPopServer(), 110, null,
					params.getUsername(), params.getPassword());
		}
		Store store = session.getStore(urln);
		store.connect();
		List<MailMessage> msgList = new ArrayList<MailMessage>();
		try {
			Folder folder = store.getFolder("INBOX");
			folder.open(Folder.READ_WRITE);
			Message message[] = folder.getMessages();
			for(int i=0; i< message.length; i++) {
				if(!message[i].getFlags().contains(Flags.Flag.SEEN) && 
						!message[i].getFlags().contains(Flags.Flag.DELETED)) {
					MessageParser parser = new MessageParser(message[i]);
					parser.setStoreDir(params.getStoreDir());
					MailMessage msg = parser.getMessage();
					if(null != handler && handler.accept(msg)) {
						parser.parse(msg);
						msgList.add(msg);
						message[i].setFlag(Flags.Flag.DELETED, true);
					}
//					else
//						message[i].setFlag(Flags.Flag.SEEN, true);
				}
			}
			folder.close(true);
		}
		finally {
			store.close();
		}
		return msgList;
	}

	private static class MessageParser {
		private MimeMessage mimeMessage = null;
		private String storeDir; //附件下载后的存放目录    
		private StringBuffer bodytext = new StringBuffer(); //存放邮件内容
		private String attachments = null;
		private boolean parsed = false;
		private String folderId;
		
		public MessageParser(Message mimeMessage) throws Exception {
			this.mimeMessage = (MimeMessage)mimeMessage;
		}
		
//		public MailMessage parse() throws Exception {
//			return parse(getMessage());
//		}
		
		public MailMessage parse(MailMessage msg) throws Exception {
			if(!parsed) {
				Part part = (Part)mimeMessage;
				parseContent(part);
				folderId = "" + msg.getMsgId();
				saveAttachments(part);
				parsed = true;
			}
			msg.setContent(getBodyText());
			msg.setAttachments(attachments);
			return msg;
		}
		
		public MailMessage getMessage() throws Exception {
			MailMessage msg = new MailMessage();
			msg.setFrom(getFrom());
			msg.setTo(getMailAddress("TO"));
			msg.setCc(getMailAddress("CC"));
			msg.setBcc(getMailAddress("BCC"));
			msg.setSubject(getSubject());
			msg.setSentDate(getSentDate());
			msg.setNew(isNew());
			return msg;
		}
		

		private String getFrom() throws Exception {
			InternetAddress address[] = (InternetAddress[]) mimeMessage
					.getFrom();
			return addressesToStr(address);
		}

		private String addressesToStr(InternetAddress[] addresses) {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < addresses.length; i++) {
				String addr = addresses[0].getAddress();
				String personal = addresses[0].getPersonal();
				if (personal != null)
					addr = personal + "<" + addr + ">";
				if (sb.length() > 0)
					sb.append("; ");
				sb.append(addr);
			}
			return sb.toString();
		}

		private String getMailAddress(String type) throws Exception {
			String mailaddr = null;
			String addtype = type.toUpperCase();
			InternetAddress[] address = null;
			if (addtype.equals("TO") || addtype.equals("CC")
					|| addtype.equals("BCC")) {
				if (addtype.equals("TO")) {
					address = (InternetAddress[]) mimeMessage
							.getRecipients(Message.RecipientType.TO);
				} else if (addtype.equals("CC")) {
					address = (InternetAddress[]) mimeMessage
							.getRecipients(Message.RecipientType.CC);
				} else {
					address = (InternetAddress[]) mimeMessage
							.getRecipients(Message.RecipientType.BCC);
				}
				if (address != null) {
					mailaddr = addressesToStr(address);
				}
			} else {
				throw new Exception("Error emailaddr type!");
			}
			return mailaddr;
		}

		public String getSubject() throws MessagingException {
			String subject = "";
			try {
				subject = MimeUtility.decodeText(mimeMessage.getSubject());
				if (subject == null)
					subject = "";
			} catch (Exception exce) {
			}
			return subject;
		}

		public Date getSentDate() throws Exception {
			return mimeMessage.getSentDate();
		}

		private String getBodyText() {
			return bodytext.toString();
		}

		private void parseContent(Part part) throws Exception {
			String contenttype = part.getContentType();
			int nameindex = contenttype.indexOf("name");
			boolean conname = false;
			if (nameindex != -1)
				conname = true;
			if (part.isMimeType("text/plain") && !conname) {
				bodytext.append((String) part.getContent());
			} else if (part.isMimeType("text/html") && !conname) {
				bodytext.append((String) part.getContent());
			} else if (part.isMimeType("multipart/*")) {
				Multipart multipart = (Multipart) part.getContent();
				int counts = multipart.getCount();
				for (int i = 0; i < counts; i++) {
					parseContent(multipart.getBodyPart(i));
				}
			} else if (part.isMimeType("message/rfc822")) {
				parseContent((Part) part.getContent());
			} else {
			}
		}

//		public boolean getReplySign() throws MessagingException {
//			boolean replysign = false;
//			String needreply[] = mimeMessage
//					.getHeader("Disposition-Notification-To");
//			if (needreply != null) {
//				replysign = true;
//			}
//			return replysign;
//		}
//
//		public String getMessageId() throws MessagingException {
//			return mimeMessage.getMessageID();
//		}


		public boolean isNew() throws MessagingException {
			boolean isnew = true;
			boolean recent = false;
			Flags flags = ((Message) mimeMessage).getFlags();
			Flags.Flag[] flag = flags.getSystemFlags();
			for (int i = 0; i < flag.length; i++) {
				if (flag[i] == Flags.Flag.SEEN || flag[i] == Flags.Flag.DELETED) {
					isnew = false;
					break;
				}
				else if(flag[i] == Flags.Flag.RECENT)
					recent = true;
			}
			return isnew && recent;
		}


		private void saveAttachments(Part part) throws Exception {
			String fileName = "";
			if (part.isMimeType("multipart/*")) {
				Multipart mp = (Multipart) part.getContent();
				for (int i = 0; i < mp.getCount(); i++) {
					BodyPart mpart = mp.getBodyPart(i);
					String disposition = mpart.getDisposition();
					if ((disposition != null)
							&& ((disposition.equals(Part.ATTACHMENT)) || (disposition
									.equals(Part.INLINE)))) {
						fileName = mpart.getFileName();
						if (fileName.toLowerCase().indexOf("gb2312") != -1) {
							fileName = MimeUtility.decodeText(fileName);
						}
						saveFile(fileName, mpart.getInputStream());
					} else if (mpart.isMimeType("multipart/*")) {
						saveAttachments(mpart);
					} else {
						fileName = mpart.getFileName();
						if ((fileName != null)
								&& (fileName.toLowerCase().indexOf("GB2312") != -1)) {
							fileName = MimeUtility.decodeText(fileName);
							saveFile(fileName, mpart.getInputStream());
						}
					}
				}
			} else if (part.isMimeType("message/rfc822")) {
				saveAttachments((Part) part.getContent());
			}
		}

		public void setStoreDir(String dir) {
			this.storeDir = dir;
		}

//		public String getStoreDir() {
//			return storeDir;
//		}

		private void saveFile(String fileName, InputStream in) throws Exception {
			String dir = storeDir;
			if(null == dir)
				dir = System.getProperty("java.io.tmpdir");
			dir = new File(dir).getCanonicalPath() + "/" + folderId;
			File storefile = new File(dir + "/" + fileName);
			if (!storefile.getParentFile().exists())
				storefile.getParentFile().mkdirs();
			TextFile.save(storefile, in);
			if(null == attachments)
				attachments = storefile.getPath();
			else
				attachments = ";" + storefile.getPath();
		}

	}

}
