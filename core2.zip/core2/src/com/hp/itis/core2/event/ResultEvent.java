package com.hp.itis.core2.event;

public class ResultEvent extends Event {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7169544389373052854L;
	
	public static final String EVENT_TYPE = "ResultEvent";

	public ResultEvent(IEvent event, Object result) {
		super(EVENT_TYPE, event.source(), result);
	}
	
	public boolean isResultOf(IEvent sourceEvent) {
		if(source == null || sourceEvent == null || sourceEvent.source() == null)
			return false;
		return (source.equals(sourceEvent.source()));
	}

}
