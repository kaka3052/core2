package com.hp.itis.core2.event;

import java.io.Serializable;


public interface IEvent extends Serializable {
	String ALL_TYPES = "*";
	
	long id();
	long timestamp();
	String type();
	Object source();
	Object target();
	Object data();
	boolean sync();
	boolean depressed();
	void depress();
}
