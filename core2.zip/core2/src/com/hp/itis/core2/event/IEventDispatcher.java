package com.hp.itis.core2.event;

public interface IEventDispatcher {
	void addListener(String type, IEventListener listener);
	void addListener(IEventListener listener);
	void removeListener(String type, IEventListener listener);
	void removeListener(IEventListener listener);
	void clearListeners();
	boolean hasListener(String type);
	void dispatch(IEvent event);
	IEvent dispatch(Object data);
}
