package com.hp.itis.core2.event;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


public class Event implements IEvent {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7169544389373052853L;
	
	protected static volatile long seqid = getBaseSeqId();
	protected long id = ++seqid;
	protected long timestamp = System.currentTimeMillis();
	protected String type;
	protected Object source;
	protected Object target;
	protected Object data;
	protected boolean sync = false;
	protected boolean depressed = false;
	
	private static long getBaseSeqId() {
		long baseId = java.util.UUID.randomUUID().getMostSignificantBits();
		baseId = ((baseId>>>32) ^ (baseId & 0xFFFFFFFFL));
		baseId *=  1000000000L;
		return baseId;
	}
	
	public Event(String type, Object source) {
		this(type, source, null, false);
	}
	
	public Event(String type) {
		this(type, null, null, false);
	}
	
	public Event(String type, Object source, Object data) {
		this(type, source, data, false);
	}

	public Event(String type, Object source, Object data, boolean sync) {
		this.type = type;
		this.source = source;
		this.data = data;
		this.sync = sync;
	}
	
	@Override
	public Object data() {
		return data;
	}
	
	public void data(Object v) {
		data = v;
	}

	@Override
	public void depress() {
		depressed = true;
	}

	@Override
	public boolean depressed() {
		return depressed;
	}

	@Override
	public Object source() {
		return source;
	}

	@Override
	public Object target() {
		return target;
	}

	@Override
	public String type() {
		return type;
	}

	@Override
	public long id() {
		return id;
	}

	@Override
	public long timestamp() {
		return timestamp;
	}
	
	@Override
	public String toString() {
		return type + "#" + String.valueOf(id / 1000000000L) + "." + String.valueOf(id % 1000000000L);
	}

	@Override
	public boolean sync() {
		return sync;
	}
	
	private void writeObject(ObjectOutputStream out) throws IOException {
    	if(!(source instanceof Serializable))
    		source = null;
    	if(!(target instanceof Serializable))
    		target = null;
		out.defaultWriteObject();
    }
 
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
    }

}
