package com.hp.itis.core2.event;

public interface IEventListener {
	int PRI_HIGH = 40;
	int PRI_HIGHER = 30;
	int PRI_DEFAULT = 20;
	int PRI_LOWER = 10;
	int PRI_LOW = 0;
	
	int priority();
	void accept(IEvent event);
}
