package com.hp.itis.core2.event;

public abstract class EventListener implements IEventListener {

	private int priority = PRI_DEFAULT;
	
	@Override
	abstract public void accept(IEvent event);
	
	public EventListener() {
	}
	
	public EventListener(int priority) {
		this.priority = priority;
	}

	@Override
	public int priority() {
		return priority;
	}

}
