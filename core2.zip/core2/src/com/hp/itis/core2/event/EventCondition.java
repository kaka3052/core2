package com.hp.itis.core2.event;

abstract public class EventCondition implements IEventCondition {
	private IEvent event = null;
	private String eventType = IEvent.ALL_TYPES;

	public EventCondition(String eventType) {
		this.eventType = eventType;
	}
	
	public EventCondition() {
	}
	
	@Override
	abstract public boolean filter(IEvent event);

	@Override
	public void accept(IEvent event) {
		if(filter(event)) {
			this.event = event;
			synchronized(this) {
				notifyAll();
			}
		}
	}

	@Override
	public String eventType() {
		return eventType;
	}
	
	@Override
	public int priority() {
		return PRI_HIGHER;
	}

	@Override
	public IEvent waitFor(long timeout) throws InterruptedException {
		synchronized(this) {
			wait(timeout);
		}
		return event;
	}

}
