package com.hp.itis.core2.event;

public interface IEventDemander extends IEventDispatcher {
	IEvent demand(IEvent event, long timeout) throws InterruptedException;
	Object demand(Object data, long timeout) throws InterruptedException;
	void supply(IEvent event, Object result);
	IEvent waitEvent(IEventCondition condition, long timeout) throws InterruptedException;
}
