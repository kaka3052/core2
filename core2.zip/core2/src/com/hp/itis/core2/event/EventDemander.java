package com.hp.itis.core2.event;


public class EventDemander extends EventDispatcher implements IEventDemander {

	@Override
	public IEvent waitEvent(IEventCondition condition, long timeout) throws InterruptedException {
		try {
			addListener(condition.eventType(), condition);
			IEvent event = condition.waitFor(timeout);
			return event;
		}
		finally {
			removeListener(condition);
		}
	}

	@Override
	public IEvent demand(IEvent event, long timeout) throws InterruptedException {
		ResultEventCondition condition = new ResultEventCondition(event);
		try {
			addListener(condition.eventType(), condition);
			dispatch(event);
			if(null != condition.supplied())
				return condition.supplied();
			return condition.waitFor(timeout);
		}
		finally {
			removeListener(condition);
		}
	}
	
	@Override
	public Object demand(Object data, long timeout)
			throws InterruptedException {
		IEvent event = createRequestEvent(data);
		event = demand(event, timeout);
		if(null != event)
			return event.data();
		return null;
	}

	@Override
	public void supply(IEvent event, Object result) {
		if(null != event)
			dispatch(new ResultEvent(event, result));
	}
	
	protected IEvent createRequestEvent(Object data) {
		IEvent event = createEvent(data, null, null, false);
		return createEvent(event, event, null, false);
	}
	
}
