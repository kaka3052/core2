package com.hp.itis.core2.event;

public interface IEventFilter extends IEventListener{
	String eventType();
	boolean filter(IEvent event);
}
