package com.hp.itis.core2.event;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Pattern;

import com.hp.itis.core2.misc.StrUtil;

public class EventDispatcher implements IEventDispatcher {

	private Map<String, List<IEventListener>> listeners = new ConcurrentHashMap<String, List<IEventListener>>();
	
	private static class WildCardsListener implements IEventListener {
		private Pattern pattern;
		private IEventListener listener;
		
		public WildCardsListener(String pattern, IEventListener listener) {
			if(isWildCardsPattern(pattern) && !IEvent.ALL_TYPES.equals(pattern))
				this.pattern = StrUtil.nePattern(pattern);
			this.listener = listener;
		}
		
		@Override
		public void accept(IEvent event) {
			if(isAcceptable(event.type()))
				listener.accept(event);
		}

		@Override
		public int priority() {
			return listener.priority();
		}
		
		public boolean isAcceptable(String type) {
			if(null != pattern) {
				if(!pattern.matcher(type).find())
					return false;
			}
			return true;
		}
		
//		public IEventListener listener() {
//			return listener;
//		}
		
		@Override
		public boolean equals(Object o) {
			return super.equals(o) || listener.equals(o);
		}
		
		public static boolean isWildCardsPattern(String pattern) {
			return null != pattern && (pattern.indexOf('*')>=0 || pattern.indexOf('?')>=0);
		}
		
	}
	
	@Override
	public void addListener(String type, IEventListener listener) {
		if(null == type)
			return;
		String[] types = type.split(",");
		if(types.length>1) {
			for(String t : types)
				addListener(t, listener);
			return;
		}
		if(WildCardsListener.isWildCardsPattern(type)) {
			listener = new WildCardsListener(type, listener);
			type = IEvent.ALL_TYPES;
		}
		List<IEventListener> ll = null;
		synchronized(listeners) {
			ll = listeners.get(type);
			if(null == ll) {
				ll = new CopyOnWriteArrayList<IEventListener>();
				listeners.put(type, ll);
			}
		}
		if(null != ll) {
			ll.add(listener);
		}
	}
	
	private void addWithPriority(List<IEventListener> list, IEventListener element) {
		ListIterator<IEventListener> i = list.listIterator(list.size());
		while(i.hasPrevious()) {
			if(i.previous().priority()>=element.priority())
				break;
		}
		if(i.hasNext()) {
			i.next();
			i.add(element);
		}
		else
			list.add(element);
	}

	@Override
	public void dispatch(IEvent event) {
		List<IEventListener> targets = new LinkedList<IEventListener>();
		if(event instanceof Event)
			((Event)event).target = currentObj();
		List<IEventListener> ll = listeners.get(event.type());
		if(null != ll) {
			for(IEventListener listener : ll)
				addWithPriority(targets, listener);
		}
		ll = listeners.get(IEvent.ALL_TYPES);
		if(null != ll) {
			for(IEventListener listener : ll)
				addWithPriority(targets, listener);
		}
		for(IEventListener listener : targets)
			if(!event.depressed())
				listener.accept(event);
	}
	
	public static IEvent createEvent(Object data, Object source, String target, boolean sync) {
		IEvent event = null;
		if(data instanceof IEvent)
			event = ((IEvent)data);
		else {
			if(data instanceof String) {
				target = data.toString();
				data = null;
			}
			else if(null == target)
				target = data.getClass().getSimpleName();
			event = new Event(target, source, data, sync);
		}
		return event;
	}
	
	protected IEvent createEvent(Object data) {
		return createEvent(data, null, null, false);
	}
	
	@Override
	public IEvent dispatch(Object data) {
		IEvent event = createEvent(data);
		dispatch(event);
		return event;
	}

	@Override
	public void removeListener(String type, IEventListener listener) {
		if(null == type)
			return;
		String[] types = type.split(",");
		if(types.length>1) {
			for(String t : types)
				removeListener(t, listener);
			return;
		}
		List<IEventListener> ll = listeners.get(type);
		if(null != ll)
			ll.remove(listener);
	}
	
	protected Object currentObj() {
		return this;
	}

	@Override
	public boolean hasListener(String type) {
		//for efficiency
		//return listeners.containsKey(type) || listeners.containsKey(IEvent.ALL_TYPES);
		
		//for accuracy
		if(listeners.containsKey(type))
			return true;
		List<IEventListener> ll = listeners.get(IEvent.ALL_TYPES);
		if(null != ll)
			for(IEventListener l : ll) {
				if(l instanceof WildCardsListener) {
					if(((WildCardsListener)l).isAcceptable(type))
						return true;
				}
				else
					return true;
			}
		return false;
	}

	@Override
	public void clearListeners() {
		listeners.clear();
	}

	@Override
	public void addListener(IEventListener listener) {
		addListener(IEvent.ALL_TYPES, listener);
	}

	@Override
	public void removeListener(IEventListener listener) {
		removeListener(IEvent.ALL_TYPES, listener);
	}

}
