package com.hp.itis.core2.event;

public class RequestEvent extends Event {

	private static final long serialVersionUID = -8476156202788260465L;
	
	public RequestEvent(String type, Object source) {
		super(type, source);
	}

}
