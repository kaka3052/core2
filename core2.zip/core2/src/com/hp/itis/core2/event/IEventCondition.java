package com.hp.itis.core2.event;

public interface IEventCondition extends IEventFilter {
	IEvent waitFor(long timeout) throws InterruptedException;
}
