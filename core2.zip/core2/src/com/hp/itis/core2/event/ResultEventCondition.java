package com.hp.itis.core2.event;

public class ResultEventCondition extends EventCondition {

	private IEvent sourceEvent;
	private IEvent supplied = null;
	
	public ResultEventCondition(IEvent sourceEvent) {
		super(ResultEvent.EVENT_TYPE);
		this.sourceEvent = sourceEvent;
	}
	
	@Override
	public boolean filter(IEvent event) {
		if(event instanceof ResultEvent) {
			if(((ResultEvent)event).isResultOf(sourceEvent)) {
				supplied = event;
				return true;
			}
		}
		return false;
	}
	
	public IEvent supplied() {
		return supplied;
	}

}
