package com.hp.itis.core2.pqueue;

import java.io.Serializable;

public interface PersistentFilter {
	boolean accept(Serializable element);
}
