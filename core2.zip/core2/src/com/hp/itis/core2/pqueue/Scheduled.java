package com.hp.itis.core2.pqueue;

import java.io.Serializable;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;


public class Scheduled<E> implements Delayed, Serializable {

	private static final long serialVersionUID = -7995186377972879443L;
	
	public final E element;
	private long schedule;
	
	public Scheduled(E element, long schedule) {
		this.element = element;
		this.schedule = schedule;
	}

	@Override
	public long getDelay(TimeUnit unit) {
		return unit.convert(schedule - System.currentTimeMillis(), TimeUnit.MILLISECONDS);
	}

	@SuppressWarnings("unchecked")
	@Override
	public int compareTo(Delayed o) {
		Scheduled<E> se = (Scheduled<E>)o;
		if(schedule>se.schedule)
			return 1;
		else if(schedule<se.schedule)
			return -1;
		return 0;
	}
}