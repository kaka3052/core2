package com.hp.itis.core2.pqueue;

import java.io.File;
import java.io.Serializable;
import java.util.concurrent.DelayQueue;

public class PersistentDelayQueue<E extends Serializable> extends
		PersistentBlockingQueue<Scheduled<E>> {

	public PersistentDelayQueue(File file) throws Exception {
		this(file, null);
	}

	public PersistentDelayQueue(String fileName) throws Exception {
		this(new File(fileName));
	}

	public PersistentDelayQueue(String fileName, PersistentFilter filter) throws Exception {
		this(new File(fileName), filter);
	}
	
	public PersistentDelayQueue(File file, PersistentFilter filter) throws Exception {
		super(file, new DelayQueue<Scheduled<E>>(), filter);
	}

    
}
