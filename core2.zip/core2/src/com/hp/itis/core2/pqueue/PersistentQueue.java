package com.hp.itis.core2.pqueue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.AbstractQueue;
import java.util.Collection;
import java.util.Iterator;
import java.util.Queue;

import com.hp.itis.core2.pqueue.PersistentBlockingQueue.DeleteMarker;

public class PersistentQueue  <E extends Serializable> extends AbstractQueue<E> {
	private Queue<E> queue;
	private File file;
	private int fragments;
	private int persistents;
	protected PersistentFilter filter;
	
	public PersistentQueue(String fileName, Queue<E> queue) throws Exception {
		this(new File(fileName), queue, null);
	}
	
	public PersistentQueue(String fileName, Queue<E> queue, PersistentFilter filter) throws Exception {
		this(new File(fileName), queue, filter);
	}
	
	public PersistentQueue(File file, Queue<E> queue) throws Exception {
		this(file, queue, null);
	}
	
	public PersistentQueue(File file, Queue<E> queue, PersistentFilter filter) throws Exception {
		this.filter = filter;
		queue.clear();
		this.queue = queue;
		this.file = file;
		if(null != file)
			if(file.exists())
				reload();
			else {
				reset();
			}
	}
	
	public PersistentFilter getFilter() {
		return filter;
	}

	public void setFilter(PersistentFilter filter) {
		this.filter = filter;
	}
	
	protected Queue<E> queue() {
		return queue;
	}
	
	public boolean add(E e) {
		boolean r = queue.add(e);
		if(r && filter(e))
			append(e);
		return r;
	}
	
	public void clear() {
		if(null != file)
			try {
				reset();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		queue.clear();
	}

	public boolean contains(Object o) {
		return queue.contains(o);
	}

	public boolean containsAll(Collection<?> c) {
		return queue.containsAll(c);
	}

	public E element() {
		return queue.element();
	}

	public boolean isEmpty() {
		return queue.isEmpty();
	}

	public Iterator<E> iterator() {
		return queue.iterator();
	}

	public boolean offer(E e) {
		boolean r = queue.offer(e);
		if(r && filter(e))
			append(e);
		return r;
	}

	public E peek() {
		return queue.peek();
	}

	public E poll() {
		E e = queue.poll();
		if(filter(e))
			delete();
		return e;
	}

	public E remove() {
		E e = queue.remove();
		if(filter(e))
			delete();
		return e;
	}

	public boolean remove(Object o) {
		return queue.remove(o);
	}

	public int size() {
		return queue.size();
	}


	public Object[] toArray() {
		return queue.toArray();
	}

	public <T> T[] toArray(T[] a) {
		return queue.toArray(a);
	}
	
	protected boolean filter(E e) {
		if(null == file || null == e)
			return false;
		if(null != filter)
			return filter.accept(e);
		return true;
	}
	
	protected synchronized void delete() {
		if(persistents==1) {
			try {
				reset();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
			persistents = 0;
			return;
		}
		try {
			appendToFile(new DeleteMarker());
			fragments++;
			persistents--;
		} catch (IOException e1) {
			throw new RuntimeException(e1);
		}
	}
	
	protected synchronized void append(E e) {
		try {
	    	if(fragments>100 && fragments>persistents) {
	    		trim();
	    	}
			appendToFile(e);
			persistents++;
		} catch (IOException e1) {
			throw new RuntimeException(e1);
		}
	}
	
	protected synchronized void reset() throws IOException {
		if(file.exists())
			file.delete();
		file.createNewFile();
		fragments = 0;
		persistents = 0;
	}
    
    @SuppressWarnings("unchecked")
	protected synchronized void reload() throws Exception {
        FileInputStream fis = new FileInputStream(file);
        queue.clear();
        while (fis.available() > 0) { 
            Object element;
            ObjectInputStream ois = new ObjectInputStream(fis);
            element = ois.readObject();
            if (element instanceof DeleteMarker) {
            	fragments++;
                _remove();
            } else { 
            	persistents++;
                queue.add((E)element);
            } 
        }

        fis.close();
    }
    
    protected void _remove() {
    	queue.remove();
    }
    
    protected synchronized void appendToFile(Serializable element)
            throws IOException {
        FileOutputStream fos = new FileOutputStream(file, true);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(element);
        fos.flush(); 
        fos.close();
    }
    
    protected synchronized void trim() throws IOException {
        File tFile = new File(file.getPath() + ".t");
        
        FileOutputStream fos = new FileOutputStream(tFile);    
        ObjectOutputStream oos = null;
        for (E element: queue) {
        	if(filter(element)) {
	            oos = new ObjectOutputStream(fos);
	            oos.writeObject(element);
        	}
        }
        fos.flush(); 
        fos.close();
       
        file.delete();
        tFile.renameTo(file);
        fragments = 0;
    }


}
