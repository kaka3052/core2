package com.hp.itis.core2.pqueue;

import java.io.File;
import java.io.Serializable;
import java.util.Collection;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

public class PersistentBlockingQueue <E extends Serializable> extends PersistentQueue<E> implements BlockingQueue<E> {

	private BlockingQueue<E> queue;
	
	protected static class DeleteMarker implements Serializable {

		private static final long serialVersionUID = -1001916643755319249L;
		
	}
	
	public PersistentBlockingQueue(String fileName, int capacity) throws Exception {
		this(fileName, capacity, null);
	}
	
	public PersistentBlockingQueue(File file, int capacity) throws Exception {
		this(file, capacity, null);
	}
	
	public PersistentBlockingQueue(String fileName, int capacity, PersistentFilter filter) throws Exception {
		this(new File(fileName), capacity, filter);
	}
	
	public PersistentBlockingQueue(File file, int capacity, PersistentFilter filter) throws Exception {
		this(file, new ArrayBlockingQueue<E>(capacity), filter);
	}
	
	public PersistentBlockingQueue(String fileName, BlockingQueue<E> queue) throws Exception {
		this(fileName, queue, null);
	}
	
	public PersistentBlockingQueue(File file, BlockingQueue<E> queue) throws Exception {
		this(file, queue, null);
	}
	
	public PersistentBlockingQueue(String fileName, BlockingQueue<E> queue, PersistentFilter filter) throws Exception {
		this(new File(fileName), queue, filter);
	}
	
	public PersistentBlockingQueue(File file, BlockingQueue<E> queue, PersistentFilter filter) throws Exception {
		super(file, queue, filter);
		this.queue = queue;
	}

	public int drainTo(Collection<? super E> c, int maxElements) {
		return queue.drainTo(c, maxElements);
	}

	public int drainTo(Collection<? super E> c) {
		return queue.drainTo(c);
	}

	public boolean offer(E e, long timeout, TimeUnit unit)
			throws InterruptedException {
		boolean r = queue.offer(e, timeout, unit);
		if(r && filter(e))
			append(e);
		return r;
	}

	public E poll(long timeout, TimeUnit unit) throws InterruptedException {
		E e = queue.poll(timeout, unit);
		if(filter(e) && null != e)
			delete();
		return e;
	}

	public void put(E e) throws InterruptedException {
		queue.put(e);
		if(filter(e))
			append(e);
	}

	public int remainingCapacity() {
		return queue.remainingCapacity();
	}

	public E take() throws InterruptedException {
		E e = queue.take();
		if(filter(e) && null != e)
			delete();
		return e;
	}

	public Object[] toArray() {
		return queue.toArray();
	}

	public <T> T[] toArray(T[] a) {
		return queue.toArray(a);
	}
	


}
