package com.hp.itis.core2.db;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;
import com.hp.itis.core2.commdata.TypeCaster;
import com.hp.itis.core2.vars.AutomaticVars;
import com.hp.itis.core2.vars.IVars;

public class DbOperator {
	
	static class ResultSetWrapper implements InvocationHandler {
		private final static String CLOSE_METHOD_NAME = "close";
		public ResultSet rs = null;
		private ResultSet ors = null;
		private Connection conn = null;

		private ResultSetWrapper(ResultSet rs, Connection conn) {
			this.rs = (ResultSet) Proxy.newProxyInstance(rs.getClass()
					.getClassLoader(), rs.getClass().getInterfaces(), this);
			this.conn = conn;
			ors = rs;
		}
		
		public static ResultSet wrap(ResultSet rs, Connection conn) {
			ResultSetWrapper wrapper = new ResultSetWrapper(rs, conn);
			return wrapper.rs;
		}

		private void close() throws SQLException {
			ors.close();
			conn.close();
		}

		public Object invoke(Object proxy, Method m, Object[] args)
				throws Throwable {
			Object obj = null;
			if (CLOSE_METHOD_NAME.equals(m.getName())) {
				close();
			} else {
				obj = m.invoke(ors, args);
			}
			return obj;
		}
	}
	
	protected DataSource dataSource = null;
	
	public DbOperator(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public DbOperator() {
		
	}
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public Connection getConnection() throws SQLException {
		if(null != dataSource)
			return dataSource.getConnection();
		return null;
	}
	
	public boolean execute(SqlPreparation p) throws SQLException {
		return p.getStatement().execute();
	}
	
	public boolean execute(PreparedStatement s ) throws SQLException {
		return s.execute();
	}
	
	public boolean execute(Connection conn, String sql, Object... v) throws SQLException {
		if(v.length==1 && !TypeCaster.isBasicType(v)) {
			SqlPreparation sp = prepareSql(conn, sql, v[0]);
			return sp.execute(v[0])>=0;
		}
		PreparedStatement s = prepareStatement(conn, sql, v);
		return execute(s);
	}
	
	public boolean execute(String sql, Object... v) throws SQLException {
		Connection conn =  getConnection();
		try {
			return execute(conn, sql, v);
		}
		finally {
			if(null != conn)
				conn.close();
		}
	}
	
	public boolean execute(Connection conn, String sql, IVars v) throws SQLException {
		SqlPreparation p = prepareSql(conn, sql, v);
		return execute(p);
	}

	public boolean execute(String sql, IVars v) throws SQLException {
		Connection conn =  getConnection();
		try {
			return execute(conn, sql, v);
		}
		finally {
			conn.close();
		}
	}
	
	public ResultSet getConnectedRs(Connection conn, ResultSet rs) {
		return ResultSetWrapper.wrap(rs, conn);
	}
	
	protected ResultSet query(PreparedStatement s) throws SQLException {
		return s.executeQuery();
	}
	
	public ResultSet query(SqlPreparation p) throws SQLException {
		return p.getStatement().executeQuery();
	}
	
	public ResultSet query(Connection conn, String sql, Object... v) throws SQLException {
		PreparedStatement s = prepareStatement(conn, sql, v);
		return query(s);
	}
	
	public ResultSet query(String sql, Object... v) throws SQLException {
		Connection conn = getConnection();
		ResultSet rs = null;
		try {
			rs = ResultSetWrapper.wrap(query(conn, sql, v), conn);
			return rs;
		}
		finally {
			if(rs == null)
				conn.close();
		}
	}
	
	public ResultSet query(Connection conn, String sql, IVars v) throws SQLException {
		return query(prepareSql(conn, sql, v));
	}
	
	public ResultSet query(String sql, IVars v) throws SQLException {
		Connection conn = getConnection();
		ResultSet rs = null;
		try {
			rs = ResultSetWrapper.wrap(query(conn, sql, v), conn);
			return rs;
		}
		finally {
			if(rs == null)
				conn.close();
		}
	}
	
	public CommData queryCommData(SqlPreparation p, String keyName) throws SQLException {
		return queryCommData(p.getStatement(), keyName);
	}
	
	public CommData queryCommData(PreparedStatement s, String keyName) throws SQLException {
		ResultSet rs = query(s);
		ResultSetMetaData md = rs.getMetaData();
		int colCount = md.getColumnCount();
		CommData ret = new CommDataImpl();
		int i = 1;
		while(rs.next()) {
			String key = "" + i;
			if(null != keyName)
				key = rs.getString(keyName);
			CommData row = ret.add(key);
			for(int j=1; j<=colCount; j++)
				row.put(md.getColumnName(j), rs.getObject(j));
			i++;
		}
		rs.close();
		return ret;
	}
	
	public CommData queryCommData(Connection conn, String sql, Object... v) throws SQLException {
		return queryCommData(prepareStatement(conn, sql, v), null);
	}
	
	public CommData queryCommData(String sql, Object... v) throws SQLException {
		Connection conn =  getConnection();
		try {
			return queryCommData(conn, sql, v);
		}
		finally {
			conn.close();
		}
	}
	
	public CommData queryCommData(Connection conn, String sql, String keyName, IVars v) throws SQLException {
		SqlPreparation p = prepareSql(conn, sql, v);
		return queryCommData(p, keyName);
	}
	
	public CommData queryCommData(Connection conn, String sql, IVars v) throws SQLException {
		return queryCommData(conn, sql, null, v);
	}
	
	public CommData queryCommData(String sql, String keyName, IVars v) throws SQLException {
		Connection conn =  getConnection();
		try {
			return queryCommData(conn, sql, v);
		}
		finally {
			conn.close();
		}
	}
	
	public CommData queryCommData(String sql, IVars v) throws SQLException {
		return queryCommData(sql, null, v);
	}
	
	public PreparedStatement prepareStatement(Connection conn, String sql, Object... v) throws SQLException {
		return prepareStatement(conn, sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY, v);
	}
	
	public PreparedStatement prepareStatement(Connection conn, String sql, int resultSetType, 
		       int resultSetConcurrency,  Object... v) throws SQLException {
		if(v.length==1 && null !=v[0] && AutomaticVars.acceptable(v[0].getClass())) {
			return prepareSql(conn, sql, 
					new AutomaticVars(v[0]), 
					resultSetType, resultSetConcurrency).getStatement();
		}
		else {
			PreparedStatement s = conn.prepareStatement(sql, resultSetType, resultSetConcurrency);
			for(int i=0; i<v.length; i++)
				s.setObject(i+1, v[i]);
			return s;
		}
	}
	
	public SqlPreparation prepareSql(Connection conn, String sql, Object params, int resultSetType, 
		       int resultSetConcurrency) throws SQLException {
		return new SqlPreparation(conn, sql, params, resultSetType, resultSetConcurrency);
	}
	
	public SqlPreparation prepareSql(Connection conn, String sql, Object params) throws SQLException {
		IVars vars = new AutomaticVars(params);
		return new SqlPreparation(conn, sql, vars);
	}
	
	public void close(Connection conn) {
		try {
			if(conn != null)
				conn.close();
		} catch (SQLException e) {
		}
	}
	
	public void close(ResultSet rs) {
		if(rs == null)
			return;
		try {
			if(rs instanceof Proxy) {
				rs.close();
			}
			else {
				Connection conn = rs.getStatement().getConnection();
				rs.close();
				conn.close();
			}
		} catch (SQLException e) {
		}
	}
	
	public void test() throws SQLException {
		execute("select 1");
	}

}
