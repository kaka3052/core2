package com.hp.itis.core2.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.vars.IVars;

public class DbSession {

	private DbOperator dbOperator;
	private Connection conn;
	
	public DbSession(DbOperator dbOperator) {
		this.dbOperator = dbOperator;
	}

	public void close() {
		dbOperator.close(conn);
	}

	public boolean execute(String sql, Object... v)
			throws SQLException {
		return dbOperator.execute(conn, sql, v);
	}

	public Connection connection() throws SQLException {
		return conn;
	}

	public SqlPreparation prepareSql(String sql, Object params, int resultSetType, int resultSetConcurrency)
			throws SQLException {
		return dbOperator.prepareSql(conn, sql, params, resultSetType,
				resultSetConcurrency);
	}

	public SqlPreparation prepareSql(String sql, Object params)
			throws SQLException {
		return dbOperator.prepareSql(conn, sql, params);
	}

	public ResultSet query(String sql, IVars v)
			throws SQLException {
		return dbOperator.query(conn, sql, v);
	}

	public ResultSet query(String sql, Object v)
			throws SQLException {
		return dbOperator.query(conn, sql, v);
	}

	public CommData queryCommData(String sql, Object v)
			throws SQLException {
		return dbOperator.queryCommData(conn, sql, v);
	}

	public CommData queryCommData(String sql, String keyName, IVars v) throws SQLException {
		return dbOperator.queryCommData(conn, sql, keyName, v);
	}

	public CommData queryCommData(SqlPreparation p, String keyName)	throws SQLException {
		return dbOperator.queryCommData(p, keyName);
	}

	public void test() throws SQLException {
		dbOperator.test();
	}
	
}
