package com.hp.itis.core2.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;

import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.PojoVars;
import com.hp.itis.core2.vars.ResultSetVars;

public class RsPojoReader<E> implements Iterable<E> {
	private IVars rsVars;
	private ResultSet rs;
	private E nextElement = null;
	private Class<? extends E> elementType;

	public RsPojoReader(ResultSet rs, Class<E> elementType) {
		this.rs = rs;
		rsVars = new ResultSetVars(rs);
		this.elementType = elementType;
	}
	
	public E read() {
		if(nextElement != null) {
			E r = nextElement;
			nextElement = null;
			return r;
		}
		try {
			if(rs.next()) {
				E pojo = elementType.newInstance();
				if(PojoVars.extractPojo(rsVars, pojo))
					return (E)pojo;
				else
					return null;
			}
		} catch (SQLException e) {
		} catch (InstantiationException e) {
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			throw new RuntimeException(e);
		}
		return null;
	}
	
	private boolean testNext() {
		if(nextElement != null)
			return true;
		nextElement = read();
		return nextElement != null;
	}
	
	@Override
	public Iterator<E> iterator() {
		return new Iterator<E>(){

			@Override
			public boolean hasNext() {
				try {
					return testNext();
				} catch (Exception e) {}
				return false;
			}

			@Override
			public E next() {
				return read();
			}

			@Override
			public void remove() {
				try {
					rs.deleteRow();
				} catch (SQLException e) {
				}
			}
			
		};
	}
	
	public void close() {
		try {
			rs.close();
		} catch (SQLException e) {
		}
	}


}
