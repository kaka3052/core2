package com.hp.itis.core2.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;
import com.hp.itis.core2.vars.AdvanceVarReplacer;
import com.hp.itis.core2.vars.AutomaticVars;
import com.hp.itis.core2.vars.IEnumerableVars;
import com.hp.itis.core2.vars.IVarHolder;
import com.hp.itis.core2.vars.IVarReplacer;
import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.IWritableVars;
import com.hp.itis.core2.vars.ResultSetVars;

public class SqlPreparation {
	private List<String> varNames = new ArrayList<String>();
	private List<String> params = new ArrayList<String>();
	private PreparedStatement statement;
	private Object po;
	Connection conn;
	
	
	private static IVars dbParamVars = new IVars() {

		@Override
		public Object get(String key) {
			if(key.startsWith("^"))
				return "#[" + key.substring(1) +"]";
			return "?";
		}
	};
	
	public SqlPreparation(Connection conn, String sql, Object po, int resultSetType, 
		       int resultSetConcurrency) throws SQLException {
		this.conn = conn;
		IVars vars = buildParams(po);
		IVarReplacer sqlPattern = new AdvanceVarReplacer(sql, '#', '[');
		List<IVarHolder> holders = sqlPattern.getHolders();
		sql = sqlPattern.replace(dbParamVars);
		if(null != vars)
			sql = new AdvanceVarReplacer(sql, '#', '[').replace(vars);
		statement= conn.prepareStatement(sql, resultSetType, resultSetConcurrency);
		for(int i=0; i<holders.size(); i++) {
			String param = holders.get(i).name();
			if(param.startsWith("^")) 
				param = param.substring(1);
			else
				varNames.add(param);
			params.add(param);
		}
		if(null != vars)
			setVars(vars);
	}
	
	public SqlPreparation(Connection conn, String sql, Object po) throws SQLException {
		this(conn, sql, po, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
	}
	
	public SqlPreparation(Connection conn, String sql) throws SQLException {
		this(conn, sql, null, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
	}
	
	public PreparedStatement getStatement(){
		return statement;
	}
	
	private void setVars(IVars vars) throws SQLException {
		for(int i=0; i<varNames.size(); i++) {
			Object o = vars.get(varNames.get(i));
			if(o instanceof Date)
				o = new java.sql.Timestamp(((Date)o).getTime());
			statement.setObject(i+1, o);
		}
	}
	
	private void putVars(IVars vars) throws SQLException {
		if(vars instanceof IEnumerableVars) {
			for(String key : (IEnumerableVars)vars) {
				Object o = conform(vars.get(key));
				int i = 1;
				for(String varName : varNames) {
					if(key.equals(varName))
						statement.setObject(i, o);
					i++;
				}
			}
		}
		else {
			for(int i=0; i<varNames.size(); i++) {
				Object o = conform(vars.get(varNames.get(i)));
				statement.setObject(i+1, o);
			}
		}
	}
	
	private IVars buildParams(Object o) {
		if(null == o)
			return null;
		if(o instanceof IVars)
			return (IVars)o;
		else {
			return new AutomaticVars(o);
		}
	}
	
	private Object conform(Object o) {
		if(o instanceof Date)
			o = new java.sql.Timestamp(((Date)o).getTime());
		return o;
	}
	
	public List<String> getParams() {
		return params;
	}
	
	public boolean execute() throws SQLException {
		return execute(po)>=0;
	}
	
	public int execute(Object po) throws SQLException {
		if(po instanceof Collection<?>) {
			Collection<?> list = (Collection<?>)po;
			int c = 0;
			for(Object o : list) {
				c += execute(o);
			}
			return c;
		}
		else {
			IVars vars = buildParams(po);
			putVars(vars);
			statement.execute();
			int c = statement.getUpdateCount();
			if(c>0 && vars instanceof IWritableVars) {
				IWritableVars wVars = (IWritableVars)vars;
				try {
					ResultSet keys = statement.getGeneratedKeys();
					if(keys.next()) {
						IEnumerableVars keyVars = new ResultSetVars(keys);
						for(String key : keyVars) {
							wVars.put(key, keyVars.get(key));
						}
					}
				}
				catch(Exception e) {			
				}
			}
			return c;
		}
	}
	
	public ResultSet query() throws SQLException {
		return query(null);
	}
	
	public ResultSet query(Object po) throws SQLException {
		if(null == po) { 
			IVars vars = buildParams(po);
			putVars(vars);
		}
		return statement.executeQuery();
	}
	
	public CommData queryData(Object po, String keyField) throws SQLException {
		ResultSet rs = query(po);
		try {
			ResultSetMetaData md = rs.getMetaData();
			int colCount = md.getColumnCount();
			CommData ret = new CommDataImpl();
			int i = 1;
			while(rs.next()) {
				String key = "" + i;
				if(null != keyField)
					key = rs.getString(keyField);
				CommData row = ret.add(key);
				for(int j=1; j<=colCount; j++)
					row.put(md.getColumnName(j), rs.getObject(j));
				i++;
			}
			return ret;
		}
		finally {
			rs.close();
		}
	}
	
	public CommData queryData(Object po) throws SQLException {
		return queryData(po, null);
	}
	
	public CommData queryData() throws SQLException {
		return queryData(null, null);
	}
	
	public <T> RsPojoReader<T> queryReader(Class<T> c, Object po) throws SQLException {
		ResultSet rs = query(po);
		return new RsPojoReader<T>(rs, c);
	}
	
	public <T> RsPojoReader<T> queryReader(Class<T> c) throws SQLException {
		ResultSet rs = query();
		return new RsPojoReader<T>(rs, c);
	}
	
	public <T> List<T> queryList(Class<T> c, Object po) throws SQLException {
		ResultSet rs = query(po);
		try {
			Iterable<T> ri = new RsPojoReader<T>(rs, c);
			List<T> rl = new ArrayList<T>();
			for(T i : ri)
				rl.add(i);
			return rl;
		}
		finally {
			rs.close();
		}
	}
	
	public <T> List<T> queryList(Class<T> c) throws SQLException {
		return queryList(c, null);
	}
	
	public <T> T queryOne(Class<T> c, Object po) throws SQLException {
		ResultSet rs = query(po);
		try {
			Iterator<T> i = new RsPojoReader<T>(rs, c).iterator();
			if(!i.hasNext())
				return null;
			return i.next();
		}
		finally {
			rs.close();
		}
	}
	
	public <T> T queryOne(Class<T> c) throws SQLException {
		return queryOne(c, null);
	}
	
	public Object queryOne(Object po) throws SQLException {
		ResultSet rs = query(po);
		try {
			if(rs.next()) {
				AutomaticVars vars = new AutomaticVars(po);
				vars.put(rs);
			}
		}
		finally {
			rs.close();
		}
		return po;
	}
}
