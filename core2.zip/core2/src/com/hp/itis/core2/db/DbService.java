package com.hp.itis.core2.db;

public interface DbService {
	SqlPreparation newPreparation(String sql);
	DbSession newSession();
}
