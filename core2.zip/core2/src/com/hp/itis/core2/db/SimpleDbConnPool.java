package com.hp.itis.core2.db;

import java.sql.*;
import java.lang.reflect.*;
import java.util.*;
import java.io.*;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;

import com.hp.itis.core2.misc.WrappedLog;

public class SimpleDbConnPool implements DataSource {
	private Log log = new WrappedLog(this.getClass().getSimpleName());
	private LinkedList<ConnectionWrapper> m_notUsedConnection = new LinkedList<ConnectionWrapper>();
	private HashSet<ConnectionWrapper> m_usedUsedConnection = new HashSet<ConnectionWrapper>();
	private PrintWriter logWriter;
	private String m_url = "";
	private String m_user = "";
	private String m_password = "";
	static private long m_lastClearClosedConnection = System
			.currentTimeMillis();
	public static long CHECK_CLOSED_CONNECTION_TIME = 4 * 60 * 60 * 1000; // 4 // hours
	
	public SimpleDbConnPool(String driver, String url, String user, String password) {
		setDriver(driver);
		setUrl(url);
		setUser(user);
		setPassword(password);
	}

	public synchronized Connection getConnection() throws SQLException {
		clearClosedConnection();
		while (m_notUsedConnection.size() > 0) {
			try {
				ConnectionWrapper wrapper = (ConnectionWrapper) m_notUsedConnection
						.removeFirst();
				if (wrapper.connection.isClosed()) {
					continue;
				}
				m_usedUsedConnection.add(wrapper);
				if(log.isDebugEnabled()) {
					wrapper.debugInfo = new Throwable(
							"Connection initial statement");
				}
				return wrapper.connection;
			} catch (Exception e) {
			}
		}
		int newCount = getIncreasingConnectionCount();
		LinkedList<ConnectionWrapper> list = new LinkedList<ConnectionWrapper>();
		ConnectionWrapper wrapper = null;
		for (int i = 0; i < newCount; i++) {
			wrapper = getNewConnection();
			if (wrapper != null) {
				list.add(wrapper);
			}
		}
		if (list.size() == 0) {
			return null;
		}
		wrapper = (ConnectionWrapper) list.removeFirst();
		m_usedUsedConnection.add(wrapper);

		m_notUsedConnection.addAll(list);
		list.clear();

		return wrapper.connection;
	}

	private void setDriver(String driverName) {
		Driver driver = null;
		try {
			driver = (Driver) Class.forName(driverName)
					.newInstance();
			installDriver(driver);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private static void installDriver(Driver driver) throws SQLException {
		DriverManager.registerDriver(driver);
	}

	private ConnectionWrapper getNewConnection() throws SQLException {
		Connection con = DriverManager.getConnection(m_url, m_user,
				m_password);
		ConnectionWrapper wrapper = new ConnectionWrapper(con);
		return wrapper;
	}

	synchronized void pushConnectionBackToPool(ConnectionWrapper con) {
		boolean exist = m_usedUsedConnection.remove(con);
		if (exist) {
			m_notUsedConnection.addLast(con);
		}
	}

	public int close() {
		int count = 0;

		Iterator<ConnectionWrapper> iterator = m_notUsedConnection.iterator();
		while (iterator.hasNext()) {
			try {
				((ConnectionWrapper) iterator.next()).close();
				count++;
			} catch (Exception e) {
			}
		}
		m_notUsedConnection.clear();

		iterator = m_usedUsedConnection.iterator();
		while (iterator.hasNext()) {
			try {
				ConnectionWrapper wrapper = (ConnectionWrapper) iterator.next();
				wrapper.close();
				if(log.isDebugEnabled()) {
					log.debug("", wrapper.debugInfo);
				}
				count++;
			} catch (Exception e) {
			}
		}
		m_usedUsedConnection.clear();

		return count;
	}

	private void clearClosedConnection() {
		long time = System.currentTimeMillis();
		// sometimes user change system time,just return
		if (time < m_lastClearClosedConnection) {
			time = m_lastClearClosedConnection;
			return;
		}
		// no need check very often
		if (time - m_lastClearClosedConnection < CHECK_CLOSED_CONNECTION_TIME) {
			return;
		}
		m_lastClearClosedConnection = time;

		// begin check
		Iterator<ConnectionWrapper> iterator = m_notUsedConnection.iterator();
		while (iterator.hasNext()) {
			ConnectionWrapper wrapper = (ConnectionWrapper) iterator.next();
			try {
				if (wrapper.connection.isClosed()) {
					iterator.remove();
				}
			} catch (Exception e) {
				iterator.remove();
				if(log.isDebugEnabled())
					log.debug("connection is closed, this connection initial StackTrace", wrapper.debugInfo);
			}
		}

		// make connection pool size smaller if too big
		int decrease = getDecreasingConnectionCount();
		if (m_notUsedConnection.size() < decrease) {
			return;
		}

		while (decrease-- > 0) {
			ConnectionWrapper wrapper = (ConnectionWrapper) m_notUsedConnection
					.removeFirst();
			try {
				wrapper.connection.close();
			} catch (Exception e) {
			}
		}
	}

	/**
	 * get increasing connection count, not just add 1 connection
	 * 
	 * @return count
	 */
	private int getIncreasingConnectionCount() {
		int count = 1;
		int current = getConnectionCount();
		count = current / 4;
		if (count < 1) {
			count = 1;
		}
		return count;
	}

	/**
	 * get decreasing connection count, not just remove 1 connection
	 * 
	 * @return count
	 */
	private int getDecreasingConnectionCount() {
		int current = getConnectionCount();
		if (current < 10) {
			return 0;
		}
		return current / 3;
	}

	public synchronized void printDebugMsg() {
		printDebugMsg(System.out);
	}

	public synchronized void printDebugMsg(PrintStream out) {
		if(!log.isDebugEnabled()) {
			return;
		}
		StringBuffer msg = new StringBuffer();
		msg.append("debug message in " + SimpleDbConnPool.class.getName());
		msg.append("\r\n");
		msg.append("total count is connection pool: " + getConnectionCount());
		msg.append("\r\n");
		msg.append("not used connection count: " + getNotUsedConnectionCount());
		msg.append("\r\n");
		msg.append("used connection, count: " + getUsedConnectionCount());
		log.debug(msg);
		Iterator<ConnectionWrapper> iterator = m_usedUsedConnection.iterator();
		while (iterator.hasNext()) {
			ConnectionWrapper wrapper = (ConnectionWrapper) iterator.next();
			log.debug("", wrapper.debugInfo);
		}
	}

	protected synchronized int getNotUsedConnectionCount() {
		return m_notUsedConnection.size();
	}

	protected synchronized int getUsedConnectionCount() {
		return m_usedUsedConnection.size();
	}

	protected synchronized int getConnectionCount() {
		return m_notUsedConnection.size() + m_usedUsedConnection.size();
	}

	protected String getUrl() {
		return m_url;
	}

	protected void setUrl(String url) {
		if (url == null) {
			return;
		}
		m_url = url.trim();
	}

	protected String getUser() {
		return m_user;
	}

	protected void setUser(String user) {
		if (user == null) {
			return;
		}
		m_user = user.trim();
	}

	protected String getPassword() {
		return m_password;
	}

	protected void setPassword(String password) {
		if (password == null) {
			return;
		}
		m_password = password.trim();
	}

	
	class ConnectionWrapper implements InvocationHandler {
		private final static String CLOSE_METHOD_NAME = "close";
		public Connection connection = null;
		private Connection m_originConnection = null;
		public long lastAccessTime = System.currentTimeMillis();
		Throwable debugInfo = new Throwable("Connection initial statement");

		ConnectionWrapper(Connection con) {
			this.connection = (Connection) Proxy.newProxyInstance(con.getClass()
					.getClassLoader(), con.getClass().getInterfaces(), this);
			m_originConnection = con;
		}

		void close() throws SQLException {
			m_originConnection.close();
		}

		public Object invoke(Object proxy, Method m, Object[] args)
				throws Throwable {
			Object obj = null;
			if (CLOSE_METHOD_NAME.equals(m.getName())) {
				pushConnectionBackToPool(this);
			} else {
				obj = m.invoke(m_originConnection, args);
			}
			lastAccessTime = System.currentTimeMillis();
			return obj;
		}
	}

	public void destroy() {
		close();
	}

	@Override
	public Connection getConnection(String username, String password)
			throws SQLException {
		throw new SQLException("Unsupported operation!");
	}

	@Override
	public PrintWriter getLogWriter() throws SQLException {
		return logWriter;
	}

	@Override
	public int getLoginTimeout() throws SQLException {
		throw new SQLException("Unsupported operation!");
	}

	@Override
	public void setLogWriter(PrintWriter out) throws SQLException {
		logWriter = out;
	}

	@Override
	public void setLoginTimeout(int seconds) throws SQLException {
		throw new SQLException("Unsupported operation!");
	}

	@Override
	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		throw new SQLException("Unsupported operation!");
	}

	@Override
	public <T> T unwrap(Class<T> iface) throws SQLException {
		throw new SQLException("Unsupported operation!");
	}
}
