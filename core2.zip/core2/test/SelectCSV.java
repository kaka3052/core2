import java.io.File;
import java.io.IOException;

import com.hp.itis.core2.evf.EvfDocument;
import com.hp.itis.core2.evf.Record;

public class SelectCSV {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		EvfDocument csv = new EvfDocument();
		csv.parse(new File(args[0]));
		EvfDocument csv2 = new EvfDocument();
		int size = csv.getRecord(0).size();
		for(Record rec : csv) {
			if(rec.size() != size)
				continue;
			Record rec2 = csv2.addRecord();
			for(int i=1; i<args.length; i++) {
				rec2.put(i-1, rec.get(Integer.valueOf(args[i])));
			}
		}
		csv2.write(System.out);
	}

}
