package com.hp.itis.core2.procengine.util;

import java.io.InputStream;

import junit.framework.TestCase;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.procengine.util.ConfDigester.DigestPolicy;
import com.hp.itis.core2.procengine.util.ConfDigester.PolicyTarget;

public class TestConfDigester extends TestCase {
	
	public void test() throws DocumentException {
		SAXReader reader = new SAXReader();
		Document document;
		InputStream is = this.getClass().getClassLoader().getResourceAsStream("com/hp/itis/core2/procengine/util/ProcDefine.xml");
		document = reader.read(is);
		Element el = document.getRootElement();
		CommData data = ConfDigester.digest(el, new DigestPolicy() {
			@Override
			public void buildTarget(CommData parent, CommData current, PolicyTarget target) {
				if("Task".equals(parent.getString(ConfDigester.TAG_KEY))) {
					target.key = null;
					target.cat =  "Process";
					if(null == current.getString("class"))
						current.put("class", current.getString(ConfDigester.TAG_KEY) + "Proc");
				}
				if("Trigger".equals(parent.getString(ConfDigester.TAG_KEY)) && 
						"Condition".equals(current.getString(ConfDigester.TAG_KEY))) {
					target.key = null;
					target.cat =  "Condition";
				}
			}

		});
		System.out.println(data);
	}
}
