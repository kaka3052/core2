package com.hp.itis.core2.procengine;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hp.itis.core2.procengine.test.SpringTestService;

public class TestSpring {

	public static void main(String[] args) {
		ApplicationContext springContext = new ClassPathXmlApplicationContext("conf/spring/spring-service-test.xml");
		SpringTestService testService = (SpringTestService)springContext.getBean("testService");
		testService.sayHello("John");
		testService.callTask("John");
	}
	
}
