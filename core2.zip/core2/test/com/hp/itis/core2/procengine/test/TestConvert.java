package com.hp.itis.core2.procengine.test;

import com.hp.itis.core2.procengine.adapter.AppLauncher;
import com.hp.itis.core2.procengine.exception.ModuleException;

public class TestConvert extends AppLauncher {
	
	protected String configName() {
		return "conf/core/test-convert.xml";
	}
	
	public static void main(String[] args) throws ModuleException {
		new TestConvert().start(args);
	}
}
