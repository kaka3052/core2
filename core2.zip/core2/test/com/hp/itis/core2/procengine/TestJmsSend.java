package com.hp.itis.core2.procengine;

import com.hp.itis.core2.procengine.adapter.AppLauncher;
import com.hp.itis.core2.procengine.exception.ModuleException;

public class TestJmsSend extends AppLauncher {
	protected String configName() {
		return "jms/jms-test-send.xml";
	}
	
	public static void main(String[] args) throws ModuleException {
		new TestJmsSend().start(args);
	}
}
