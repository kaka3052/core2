package com.hp.itis.core2.procengine.test;

import com.hp.itis.core2.procengine.IEchoBean;
import com.hp.itis.core2.procengine.processes.DataProcess;

public class TestBeanProc extends DataProcess {
	
	private IEchoBean bean;
	private String message;

	@Override
	public boolean execute() throws Exception {
		session().log().info(bean.echo(message));
		return true;
	}

	@Override
	protected void setup() throws Exception {
	
	}
	
	public void setEchoBean(IEchoBean bean) {
		this.bean = bean;
		System.out.println("Bean Set!");
	}
	
	public void setEchoMessage(String v) {
		message = v;
	}
}
