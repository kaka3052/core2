package com.hp.itis.core2.procengine.test;

import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventListener;

public class EventListenerBean implements IEventListener {

	@Override
	public void accept(IEvent event) {
		System.out.println("###RECEIVING EVENT FROM PROCENGINE");
		System.out.println(event.data());
	}

	@Override
	public int priority() {
		return PRI_DEFAULT;
	}

}
