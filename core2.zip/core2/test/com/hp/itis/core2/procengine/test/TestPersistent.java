package com.hp.itis.core2.procengine.test;

import com.hp.itis.core2.procengine.adapter.AppLauncher;
import com.hp.itis.core2.procengine.exception.ModuleException;

public class TestPersistent extends AppLauncher {
	
	protected String configName() {
		return "conf/core/test-persistent.xml";
	}
	
	public static void main(String[] args) throws ModuleException {
		new TestPersistent().start(args);
	}
}
