package com.hp.itis.core2.procengine.util;

import junit.framework.TestCase;

import com.hp.itis.core2.commdata.User;

public class TestDataConvertor extends TestCase {

	public void test() throws Exception {
		DataConvertor convertor = new DataConvertor("data/data_mapping.xml");
		User user = new User();
		user.setName("john");
		user.setSex(true);
		user.setMoney(0);
		user.setId(123);
		Object o = convertor.convert(user);
		System.out.println(o);
	}
}
