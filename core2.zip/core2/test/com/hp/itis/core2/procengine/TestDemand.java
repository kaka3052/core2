package com.hp.itis.core2.procengine;

import com.hp.itis.core2.procengine.exception.ModuleException;

import junit.framework.TestCase;

public class TestDemand extends TestCase {
	public void test() throws ModuleException {
		ProcEngine.instance().loadDefination("conf/core/test-demand.xml");
		ProcEngine.instance().start();
		try {
			ProcEngine.instance().awaitStop();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
