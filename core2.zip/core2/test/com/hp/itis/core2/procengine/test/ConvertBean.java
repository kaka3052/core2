package com.hp.itis.core2.procengine.test;

public class ConvertBean {
	public int convertId(int id) {
		return id*2;
	}
}
