package com.hp.itis.core2.procengine.module;

import junit.framework.TestCase;

import com.hp.itis.core2.event.Event;
import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventListener;

public class TestEventScheduler extends TestCase implements IEventListener {

	public void test() throws Exception {
		System.out.println(Thread.currentThread().getContextClassLoader().getResource(""));
		EventScheduler scheduler = new EventScheduler();
		scheduler.setActive(true);
		scheduler.setEventTarget(scheduler);
		scheduler.start();
		scheduler.addListener(this);
		long time = System.currentTimeMillis();
		IEvent event = new Event("time", null, time + 100);
		scheduler.schedule(event, 100);
		time = System.currentTimeMillis();
		event = new Event("time", null, time + 200);
		scheduler.schedule(event, 200);
		event = new Event("time", null, time + 650);
		scheduler.schedule(event, 650);
		event = new Event("time", null, time + 10000);
		scheduler.schedule(event, 10000);
		event = new Event("time", null, time + 600);
		scheduler.schedule(event, 600);
		event = new Event("time", null, time + 5000);
		scheduler.schedule(event, 5000);
		Thread.sleep(3000);
		scheduler.setActive(false);
		scheduler = new EventScheduler();
		scheduler.setActive(true);
		scheduler.setEventTarget(scheduler);
		scheduler.start();
		scheduler.addListener(this);
		time = System.currentTimeMillis();
		event = new Event("time", null, time + 600);
		scheduler.schedule(event, 600);
		event = new Event("time", null, time + 600);
		scheduler.schedule(event, 600);
		event = new Event("time", null, time + 5000);
		scheduler.schedule(event, 5000);
		time += 150000;
		while(time>System.currentTimeMillis()) {
			try {
				Thread.sleep(1000);
			}
			catch(Exception e){}
		}
	}

	@Override
	public void accept(IEvent event) {
		long time = System.currentTimeMillis();
		long d = time - (Long)event.data();
		System.out.println("##" + d);
	}

	@Override
	public int priority() {
		return PRI_DEFAULT;
	}
}
