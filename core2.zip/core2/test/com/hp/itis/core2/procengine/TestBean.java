package com.hp.itis.core2.procengine;

public class TestBean implements IEchoBean {
	
	public String echo(String message) {
		return "Hello: " + message;
	}
}
