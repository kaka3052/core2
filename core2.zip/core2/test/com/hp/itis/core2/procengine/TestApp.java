package com.hp.itis.core2.procengine;

import com.hp.itis.core2.procengine.adapter.AppLauncher;
import com.hp.itis.core2.procengine.exception.ModuleException;

public class TestApp extends AppLauncher {
	
	protected static String conf;
	protected String configName() {
		return conf;
	}
	
	public static void main(String[] args) throws ModuleException {
		if(args.length>0)
			conf = args[0];
		//System.setProperty("log4j.configuration", "log4j-socket.properties");
		new TestApp().start(args);
	}
	
}
