package com.hp.itis.core2.procengine;

import com.hp.itis.core2.procengine.exception.ModuleException;

import junit.framework.TestCase;

public class TestProcEngine extends TestCase {
	public void testLoad() throws ModuleException {
		ProcEngine.instance().loadDefination();
		ProcEngine.instance().start();
		try {
			ProcEngine.instance().awaitStop();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
