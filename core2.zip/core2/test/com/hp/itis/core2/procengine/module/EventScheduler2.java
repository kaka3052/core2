package com.hp.itis.core2.procengine.module;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.event.IEventDispatcher;
import com.hp.itis.core2.procengine.IEventProducer;


public class EventScheduler2 extends ActiveModule implements IEventProducer {

	private Queue<ScheduledEvent> scheduleList;
	private IEventDispatcher target;
	private boolean enable = false;
	private boolean activated = false;
	
	protected static class ScheduledEvent {
		public final IEvent event;
		public final long schedule;
		
		public ScheduledEvent(IEvent event, long schedule) {
			this.event = event;
			this.schedule = schedule;
		}


	}
	
	public EventScheduler2() {
		interval = 1000;
		scheduleList = new PriorityQueue<ScheduledEvent>(100, new Comparator<ScheduledEvent>(){

			@Override
			public int compare(ScheduledEvent o1, ScheduledEvent o2) {
				if(o1.schedule>o2.schedule)
					return 1;
				else if(o1.schedule<o2.schedule)
					return -1;
				return 0;
			}

		});
		
	}
	
	@Override
	public synchronized void run() {
		while(true) {
			if(scheduleList.isEmpty())
				break;
			ScheduledEvent se = scheduleList.peek();
			long d = se.schedule - System.currentTimeMillis();
			if(d<=0) {
				target.dispatch(se.event);
				scheduleList.remove();
			}
			else {
				if(d<=1000)
					interval = d;
				else 
					interval = 1000;
				break;
			}
		}
	}

	public synchronized void schedule(IEvent event, long delay) {
		if(!enable || null == event)
			return;
		if(!activated) {
			start();
		}
		ScheduledEvent se = new ScheduledEvent(event, System.currentTimeMillis() + delay);
		scheduleList.add(se);
		if(delay<interval) {
			task.act();
		}
	}
	
	public void start() {
		super.activate();
		activated = true;
	}

	@Override
	public void setEventTarget(IEventDispatcher target) {
		this.target = target;
	}
	
	@Override
	protected synchronized void activate() {
		enable = true;
	}

	@Override
	protected synchronized void deactivate() {
		enable = false;
	}

}
