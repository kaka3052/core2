package com.hp.itis.core2.procengine;

import com.hp.itis.core2.procengine.adapter.AppLauncher;
import com.hp.itis.core2.procengine.exception.ModuleException;

public class TestMailSend extends AppLauncher {
	protected String configName() {
		return "conf/core/test-mail.xml";
	}
	
	public static void main(String[] args) throws ModuleException {
		new TestMailSend().start(args);
	}
}
