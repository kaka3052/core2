package com.hp.itis.core2.procengine;

import com.hp.itis.core2.procengine.adapter.AppLauncher;
import com.hp.itis.core2.procengine.exception.ModuleException;

public class TestSocketTrigger extends AppLauncher {
	protected String configName() {
		return "conf/core/test-socket.xml";
	}
	
	public static void main(String[] args) throws ModuleException {
		new TestSocketTrigger().start(args);
	}
}
