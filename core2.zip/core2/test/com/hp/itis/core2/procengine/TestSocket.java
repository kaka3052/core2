package com.hp.itis.core2.procengine;

import com.hp.itis.core2.procengine.adapter.AppLauncher;
import com.hp.itis.core2.procengine.exception.ModuleException;

public class TestSocket extends AppLauncher {
	protected String configName() {
		return "conf/core/test-socket-conn.xml";
	}
	
	public static void main(String[] args) throws ModuleException {
		new TestSocket().start(args);
	}
}
