package com.hp.itis.core2.procengine;

public interface IEchoBean {
	String echo(String message);
}
