package com.hp.itis.core2.procengine.test;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;
import com.hp.itis.core2.procengine.adapter.ProcEngineService;

public class SpringTestService {
	private ProcEngineService service;

	public void setProcEngineService(ProcEngineService service) {
		this.service = service;
	}
	
	public void sayHello(String who) {
		CommData data = new CommDataImpl();
		data.put("who", who);
		System.out.println("BEFORE SAY HELLO!");
		service.dispatch("hello", data);
		System.out.println("AFTER SAY HELLO!");
	}
	
	public void callTask(String who) {
		CommData data = new CommDataImpl();
		data.put("who", who);
		System.out.println("BEFORE CALL TASK!");
		service.callTask("task2", data);
		System.out.println("AFTER CALL TASK!");
	}
}
