package com.hp.itis.core2.evf;

import java.io.IOException;

import com.hp.itis.core2.evf.EvfDocument;

import junit.framework.TestCase;

public class TestEvf extends TestCase{

	public void testParse() {
//		InputStream is = this.getClass().getClassLoader().getResourceAsStream("com/hp/itis/evf/parse_data.csv");
//		BufferedReader reader = null;
//		try {
//			reader = new BufferedReader(new InputStreamReader(is, "GBK"));
//		} catch (UnsupportedEncodingException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		String line;
//		while(true) {
//			try {
//				line = EvfParseUtil.readLine(reader, '\"');
//				if(line == null)
//					break;
//				List<String> fields = EvfParseUtil.parseLine(line, '\"', ',');
//				for(String f : fields) {
//					System.out.print("[" + f + "] ");
//				}
//				System.out.println();
//			} catch (IOException e) {
//				e.printStackTrace();
//				break;
//			}
//		}
	}
	
	public void testEvfDoc() throws IOException {
		String[] parts = EvfParseUtil.parseLine("aaa,bbb,ccc", EvfParseUtil.DEF_QUOTE_CHAR, EvfParseUtil.DEF_SEPERATER);
		assertEquals("aaa", parts[0]);
		assertEquals("bbb", parts[1]);
		assertEquals("ccc", parts[2]);
		
		parts = EvfParseUtil.parseLine("aaa,\"bbb\",ccc", EvfParseUtil.DEF_QUOTE_CHAR, EvfParseUtil.DEF_SEPERATER);
		assertEquals("bbb", parts[1]);
		
		parts = EvfParseUtil.parseLine("\"aaa\",\"b\"bb\",c\"c\"c\"", EvfParseUtil.DEF_QUOTE_CHAR, EvfParseUtil.DEF_SEPERATER);
		assertEquals("aaa", parts[0]);
		assertEquals("bbb", parts[1]);
		assertEquals("c\"c\"c\"", parts[2]);
		
		parts = EvfParseUtil.parseLine("aaa,\"b\"\"bb\",ccc", EvfParseUtil.DEF_QUOTE_CHAR, EvfParseUtil.DEF_SEPERATER);
		assertEquals("b\"bb", parts[1]);
		
		parts = EvfParseUtil.parseLine("aaa,\"b\"\"b,b\",ccc", EvfParseUtil.DEF_QUOTE_CHAR, EvfParseUtil.DEF_SEPERATER);
		assertEquals("b\"b,b", parts[1]);
		
		parts = EvfParseUtil.parseLine("aaa,b\"\"bb,ccc", EvfParseUtil.DEF_QUOTE_CHAR, EvfParseUtil.DEF_SEPERATER);
		assertEquals("b\"\"bb", parts[1]);
		
		parts = EvfParseUtil.parseLine("aaa,\"\",ccc", EvfParseUtil.DEF_QUOTE_CHAR, EvfParseUtil.DEF_SEPERATER);
		assertEquals("", parts[1]);
		
		parts = EvfParseUtil.parseLine("aaa,\",\",ccc", EvfParseUtil.DEF_QUOTE_CHAR, EvfParseUtil.DEF_SEPERATER);
		assertEquals(",", parts[1]);
		
		parts = EvfParseUtil.parseLine("aaa,\"aa,\nbb\",ccc", EvfParseUtil.DEF_QUOTE_CHAR, EvfParseUtil.DEF_SEPERATER);
		assertEquals("aa,\nbb", parts[1]);
		
		EvfDocument mlib = new EvfDocument();
		mlib.parse(this.getClass().getClassLoader().getResourceAsStream("com/hp/itis/core2/evf/meta_lib.txt"));
		mlib.write(System.out);
		System.out.println("----------");
		
		EvfDocument schema = new EvfDocument();
		schema.parse(this.getClass().getClassLoader().getResourceAsStream("com/hp/itis/core2/evf/def_1.txt"), mlib);
		assertEquals(schema.charset(), "gbk");
		assertEquals(schema.meta().get("m1"), "xxx\r\nxxx");
		assertEquals(schema.meta().get("m2"), "xxx\"xxx");
		assertEquals(schema.meta().getFieldMeta(0).get("fm1"), "aaa");
		assertEquals(schema.meta().getFieldMeta(1).get("fm1"), "b\"bb");
		assertEquals(schema.meta().getFieldMeta(0).get("fm2"), "aaa");
		assertEquals(schema.meta().getFieldMeta(1).get("fm2"), "b\"bb");
		System.out.println("----------");
		
		EvfDocument doc = new EvfDocument(schema);
		doc.parse(this.getClass().getClassLoader().getResourceAsStream("com/hp/itis/core2/evf/data_1.txt"));
		doc.write(System.out);
		System.out.println("----------");
		System.out.println(doc.getSection("def1").getRecord(0).getString("f3"));
		
		EvfDocument schema2 = new EvfDocument();
		schema2.parse(this.getClass().getClassLoader().getResourceAsStream("com/hp/itis/core2/evf/def_2.txt"));
		
		System.out.println("----------");
		EvfDocument doc2 = new EvfDocument(schema2);
		doc2.parse(this.getClass().getClassLoader().getResourceAsStream("com/hp/itis/core2/evf/data_2.txt"));
		doc2.write(System.out);
		System.out.println(doc2.getRecord(0));
		System.out.println(doc2.count());
		System.out.println(doc2.getRecord(2).getString("time_stamp"));
		System.out.println("----------");
	}
}
