package com.hp.itis.core2.misc;

import com.hp.itis.core2.misc.CodeMapper;
import com.hp.itis.core2.misc.CodeMapper.CodeResource;

import junit.framework.TestCase;

public class TestCodeMapper extends TestCase {

	public void test() {
		CodeMapper.instance().addResource("data/code_res.xml");
		CodeMapper cm = CodeMapper.instance();
		assertEquals("s4", cm.map("4"));
		assertEquals("s2", cm.map("res1", "3"));
		assertEquals("s1", cm.map("res1", "101"));
		cm.setLang("cn");
		assertEquals("字符串1", cm.map("res1", "101"));
		assertEquals("t1", cm.map("res2", "201"));
		CodeResource res = cm.getResource(this.getClass());
		assertEquals("a1", res.get("r1"));
		assertEquals("a2", res.get("r2"));
		assertEquals("a3", res.get("r3"));
		assertEquals("a4", res.get("r4"));
	}
}
