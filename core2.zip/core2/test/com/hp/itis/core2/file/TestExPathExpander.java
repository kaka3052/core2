package com.hp.itis.core2.file;

import java.util.List;

import com.hp.itis.core2.file.ExPathExpander;

import junit.framework.TestCase;

public class TestExPathExpander extends TestCase {
	public void test() {
		List<String> list = ExPathExpander.expand("c:/AIP//*.*");
		for(String s:list) {
			System.out.println(s);
		}
	}
}
