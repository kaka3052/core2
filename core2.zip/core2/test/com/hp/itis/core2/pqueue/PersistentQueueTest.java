package com.hp.itis.core2.pqueue;

import java.io.File;
import java.io.Serializable;
import java.util.concurrent.ArrayBlockingQueue;

import junit.framework.TestCase;

import com.hp.itis.core2.event.IEvent;
import com.hp.itis.core2.procengine.module.CommEvent;

/**
 * Unit test for {@link com.gaborcselle.persistent.PersistentQueue}.
 * 
 * @author Gabor Cselle
 * @version 1.0
 */
public class PersistentQueueTest extends TestCase {
	
	static class PersistentQueueTestEntry implements Serializable {
	    public final static long serialVersionUID = 1;
	    public String content;
	    
	    public PersistentQueueTestEntry(String content) {
	        this.content = content;
	    }
	}
	
    /** Filename of queue file that should be used for testing. */
    private static final String TEST_FILENAME = "c:\\persQueueTest.queue";
    private PersistentBlockingQueue<PersistentQueueTestEntry> pqueue;

    /** 
     * Set up unit test - delete the test file if it already exists,
     * instantiate PersistentQueue.
     */
    protected void setUp() throws Exception {
        super.setUp();
        
        // delete file, if any exists
        File deleteFile = new File(TEST_FILENAME);
        deleteFile.delete();
        
        pqueue = new PersistentBlockingQueue<PersistentQueueTestEntry>(TEST_FILENAME, new ArrayBlockingQueue<PersistentQueueTestEntry>(3000));
    }
    
    /** Test adding and removing a single element. */
    public void testOneElement() throws Exception {        
        pqueue.clear();
        pqueue.add(new PersistentQueueTestEntry ("one"));
        PersistentQueueTestEntry entry = pqueue.remove();
        if (!entry.content.equals("one")) {
            fail("Added string != string removed");
        }        
    }
    
    /** Test adding and removing a lot of elements. */
    public void testALotOfElements() throws Exception {
        pqueue.clear();
        
        // add a hundred elements
        for (int i = 0; i < 100; i++) {
            pqueue.add(new PersistentQueueTestEntry(String.valueOf(i)));
        }
        
        // and remove a hundred elements
        for (int i = 0; i < 100; i++) {
            PersistentQueueTestEntry entry = pqueue.remove();
            assertEquals(entry.content, String.valueOf(i)); 
        }
    }
    
    /** Test the method {@link PersistentQueue#size()} */
    public void testSize() throws Exception {
        pqueue.clear();
        
        // queue is now empty - isEmpty should return true
        assertTrue(pqueue.isEmpty());

        // add three elements
        for (int i = 0; i < 3; i++) {
            pqueue.add(new PersistentQueueTestEntry(String.valueOf(i)));
        }
        
        // check that element number is correct
        assertEquals(pqueue.size(),3);
        
        // queue is now filled - isEmpty should return false
        assertFalse(pqueue.isEmpty());
    }
    
    /** Simulate a crash and reload of the PersistentQueue. */
    public void testRecoverFromLost() throws Exception {
        pqueue.clear();
        pqueue.add(new PersistentQueueTestEntry ("one"));
        pqueue.add(new PersistentQueueTestEntry ("two"));
        
        // lose pqueue now (e.g. because of system crash) and create a new one
        pqueue = new PersistentBlockingQueue<PersistentQueueTestEntry>(TEST_FILENAME, new ArrayBlockingQueue<PersistentQueueTestEntry>(3000));
        PersistentQueueTestEntry entry = pqueue.remove();
        if (!entry.content.equals("one")) {
            fail("Added string != string removed");
        }    
        entry = pqueue.remove();
        if (!entry.content.equals("two")) {
            fail("Added string != string removed");
        }   
    }
    
    /** 
     * Write 20 elements, remove 10, then lose PersistentQueue.
     * Also forces a defragment because it sets deframentInterval to 9. 
     * */
    public void testWriteList() throws Exception {
        //pqueue.clear();
        
        PersistentBlockingQueue<IEvent> pqueue = new PersistentBlockingQueue<IEvent>(TEST_FILENAME, 3000);
        // add 300, remove 300
        long t = System.currentTimeMillis();
        for (int i = 0; i < 1000; i++) {
            CommEvent event = CommEvent.createEvent(null, "event1", false);
//            for(int k =0; k<30; k++)
//            	event.commData().put("property"+k, "value"+k);
        	event.put("index", i);
            pqueue.add(event);
            pqueue.add(event);
            pqueue.remove();
            pqueue.add(event);
            pqueue.remove();
        }
        System.out.println(System.currentTimeMillis() - t);
        t = System.currentTimeMillis();
        // lose pqueue now (e.g. because of system crash) and create a new one
        pqueue = new PersistentBlockingQueue<IEvent>(TEST_FILENAME, 3000);
        
        // and check 100 elements
        for (int i = 0; i < 1000; i++) {
            CommEvent e = (CommEvent)pqueue.remove();
            assert(e.get("index") != null); 
        }
        System.out.println(System.currentTimeMillis() - t);
        assert(pqueue.isEmpty());
    }
    
    /** Tear down unit test: delete the file created by PersistentQueue. */
    protected void tearDown() throws Exception {
        super.tearDown();
        
        // delete the file created by pqueue
        File deleteFile = new File(TEST_FILENAME);
        deleteFile.delete();
    }
}
