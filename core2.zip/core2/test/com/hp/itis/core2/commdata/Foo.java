package com.hp.itis.core2.commdata;

import java.util.ArrayList;
import java.util.List;

@Digestible
public class Foo {
	private List<Poo> list = new ArrayList<Poo>();
	private Poo poo = new Poo();
	private String name;
	
	public Foo() {
		list.add(new Poo());
	}
	
	public List<Poo> getList() {
		return list;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Poo getPoo() {
		return poo;
	}
}
