package com.hp.itis.core2.commdata;

import junit.framework.TestCase;

public class TypeCasterTest extends TestCase {

	public void testToNumber() {
		Number n = TypeCaster.toNumber("1.23456e5");
		assertEquals(n.intValue(), 123456);
	}
	
}
