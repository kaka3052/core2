package com.hp.itis.core2.commdata;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;

import junit.framework.TestCase;


public class CommDataTest extends TestCase{
	
	private void fillPoo(CommData poo) {
		poo.put("id", 0);
		poo.put("name", "aaa");
		poo.put("date", "2008-08-08 00:00:00");
		poo.put("ok", new Boolean(false));
	}
	
	private void fillFoo(CommData foo) {
		foo.put("name", "Foo");
		CommData poo = foo.add("poo");
		fillPoo(poo);
		CommData list = foo.add("list");
		List<Object> l = new ArrayList<Object>();
		for(int i=0; i<10; i++) {
			l.add(poo);
		}
		list.put(l);
	}
	
	public static void testPojo() {
		CommData data = new CommDataImpl();
		data.put("id", 3);
		data.put("name", "haha");
		data.put("money", 1.11);
		data.put("birthday", new Date());
		data.put("sex", true);
		data.put("MyAnno", "xxx");
		User user = new User();
		data.extract(user);
		System.out.println();
		System.out.println(">>>Extract Pojo");
		System.out.println("id:" + user.getId());
		System.out.println("name:" + user.getName());
		System.out.println("sex:" + user.getSex());
		System.out.println("money:" + user.getMoney());
		System.out.println("birthday:" + user.getBirthday());
		System.out.println();
		assertEquals(user.getAnno(), "xxx");
		System.out.println(">>>Put Pojo");
		CommData data2 = new CommDataImpl();
		data2.put(user);
		assertTrue(data.equals(data2));
		System.out.println(data2);
		System.out.println(">>>Extract Map");
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		data2.extract(map);
		for(Entry<String, Object> entry : map.entrySet()){
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		System.out.println();
		System.out.println(">>>Extract Collection");
		List<Object> list = new ArrayList<Object>();
		data2.extract(list);
		for(Object item : list){
			System.out.println(item);
		}	
	}
	
	public void testDate() {
		CommData data1 = new CommDataImpl();
		data1.put("date", "2008-08-08 00:00:00");
		Poo poo = new Poo();
		data1.extract(poo);
		Poo poo1 = new Poo();
		data1.put("date", "2008-08-08");
		data1.extract(poo1);
		assertTrue(poo.getDate().equals(poo1.getDate()));
		data1.put("date", "2008/08/08 00:00:00");
		data1.extract(poo1);
		assertTrue(poo.getDate().equals(poo1.getDate()));
		data1.put("date", "2008/08/08");
		data1.extract(poo1);
		assertTrue(poo.getDate().equals(poo1.getDate()));
	}
	
	public void testEfficiany() {
		CommData data = new CommDataImpl();
		Poo poo = new Poo();
		fillPoo(data);
		long t = System.currentTimeMillis();
		for(int i=0; i<10000; i++) {
			data.extract(poo);
		}
		t = System.currentTimeMillis() - t;
		System.out.println("Tesing to extract a simple Pojo 10,000 times in: " + t + "ms");
		
		t = System.currentTimeMillis();
		for(int i=0; i<10000; i++) {
			data.put(poo);
		}
		t = System.currentTimeMillis() - t;
		System.out.println("Tesing to put a simple Pojo 10,000 times in: " + t + "ms");
		
		CommData data2 = new CommDataImpl();
		Foo foo = new Foo();
		fillFoo(data2);
		t = System.currentTimeMillis();
		for(int i=0; i<10000; i++) {
			data2.extract(foo);
		}
		t = System.currentTimeMillis() - t;
		System.out.println("Tesing to extract a complex Object 10,000 times in: " + t + "ms");
		
		t = System.currentTimeMillis();
		for(int i=0; i<10000; i++) {
			data2.put(foo);
		}
		t = System.currentTimeMillis() - t;
		System.out.println("Tesing to put a complex Object 10,000 times in: " + t + "ms");
	}
	
	public void testEqual() throws ParseException {
		CommData poo1 = new CommDataImpl();
		fillPoo(poo1);
		assertTrue(poo1.equals(poo1));
		assertFalse(poo1.equals(null));
		CommData poo2 = new CommDataImpl();
		assertFalse(poo1.equals(poo2));
		fillPoo(poo2);
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		poo2.put("date", format.parse("2008-08-08 00:00:00"));
		assertTrue(poo1.equals(poo2));
		CommData foo1 = new CommDataImpl();
		fillFoo(foo1);
		CommData foo2 = new CommDataImpl();
		fillFoo(foo2);
		assertTrue(foo1.equals(foo2));
		((CommData)foo1.get("poo")).put("test", "test");
		assertFalse(foo1.equals(foo2));
	}
}
