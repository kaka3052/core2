package com.hp.itis.core2.commdata;

import java.util.Date;

@Digestible
public class User {
	private int id;
	private String name;
	private double money;
	private Date birthday;
	private boolean sex;
	private String anno;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public boolean getSex() {
		return sex;
	}
	public void setSex(boolean sex) {
		this.sex = sex;
	}
	
	@FieldMap("MyAnno")
	public String getAnno() {
		return anno;
	}
	
	@FieldMap("MyAnno")
	public void setAnno(String anno) {
		this.anno = anno;
	}
}
