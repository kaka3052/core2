package com.hp.itis.core2.vars;

import com.hp.itis.core2.vars.CombinedVars;
import com.hp.itis.core2.vars.IVars;
import com.hp.itis.core2.vars.MethodVars;
import com.hp.itis.core2.vars.ValuesVars;
import com.hp.itis.core2.vars.VarReplacer;

import junit.framework.TestCase;

public class EvaluatorTest extends TestCase {

	public void test() {
		Double d = 1d;
		Integer i = 1;
		assertTrue(d.equals(i.doubleValue()));
		IVars vars = new CombinedVars(
				new ValuesVars("1", 50, "2", 30, "3", this, "e^%*&^)*0", "23"),
				new MethodVars(com.hp.itis.core2.procengine.VarFunLib.class));
		String r = VarReplacer.replace("###${=#(min(#1+#2,100)))}^^^^", vars);
		IEvaluator ev;
		ev = ExprEvaluator.build("eval('\\'aaa\\'+ucase(\\'bbb\\')')");
		assertEquals(ev.eval(vars), "aaaBBB");
		ev = ExprEvaluator.build("#1=50");
		assertEquals(ev.eval(vars), true);
		ev = ExprEvaluator.build("$(50.0)='50.0'");
		assertEquals(ev.eval(vars), true);
		ev = ExprEvaluator.build("$1");
		assertEquals(ev.eval(vars), "50");
		ev = ExprEvaluator.build("[3]");
		assertEquals(ev.eval(vars), this);
		ev = ExprEvaluator.build("#1+#2");
		assertEquals(ev.eval(vars), 80);
		ev = ExprEvaluator.build("#($1+$2)");
		assertEquals(ev.eval(vars), 5030);
		ev = ExprEvaluator.build("[e^%*&^)*0]");
		assertEquals(ev.eval(vars), "23");
		ev = ExprEvaluator.build("#['e^%*&^)*0']");
		assertEquals(ev.eval(vars), 23);
		ev = ExprEvaluator.build("#[e^%*&^)*0]+1");
		assertEquals(ev.eval(vars), 24);
		ev = ExprEvaluator.build("isNull(aaa)");
		assertEquals(ev.eval(vars), true);
		ev = ExprEvaluator.build("aaa");
		assertEquals(ev.eval(vars), null);
		ev = ExprEvaluator.build("aaa+bbb");
		assertEquals(ev.eval(vars), null);
		ev = ExprEvaluator.build("ccc(aaa+bbb)>1");
		assertEquals(ev.eval(vars), null);
		ev = ExprEvaluator.build("map(3,1,'a',2,'b',3,'c')");
		assertNotNull(ev);
		assertEquals("c", ev.eval(vars));
		ev = ExprEvaluator.build("#avg(1,2,3)");
		assertNotNull(ev);
		assertEquals(2, ev.eval(vars));
		ev = ExprEvaluator.build("mins(array(1.0,2,3))");
		assertNotNull(ev);
		assertEquals(1.0, ev.eval(vars));
		ev = ExprEvaluator.build("maxs('a','b','c',1)");
		assertNotNull(ev);
		assertEquals("c", ev.eval(vars));
		ev = ExprEvaluator.build("range(3,1,2,3)");
		assertNotNull(ev);
		assertEquals(3, ev.eval(vars));
//		ev = ExprEvaluator.build("hashcode('数据库表空间使用查过90%') + '_' + range(replaceAll(body, '主机名称:cmszatsa; 模块名称:monDbTbsp.sh; 告警内容:数据库dps1上的表空间UNDOTBS1的使用率是(\\\\d*)，超过SERIOUS范围90','$1'), 50, 60, 70, 80, 90)");
//		vars = new CombinedVars(
//				new ValuesVars("body", "主机名称:cmszatsa; 模块名称:monDbTbsp.sh; 告警内容:数据库dps1上的表空间UNDOTBS1的使用率是70，超过SERIOUS范围90"),
//				new MethodVars(com.hp.itis.core2.procengine.VarFunLib.class));
//		assertNotNull(ev);
		assertEquals(3, ev.eval(vars));
		//System.out.println(ev.eval(vars));
		System.out.println(r);
		ev = ExprEvaluator.build("random()");
		assertNotNull(ev);
		System.out.println(ev.eval());
		//assertEquals("###true^^^^", r);
		
	}
}
