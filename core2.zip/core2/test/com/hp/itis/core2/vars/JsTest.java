package com.hp.itis.core2.vars;

import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Enumeration;

import javax.script.Bindings;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import junit.framework.TestCase;

import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import com.hp.itis.core2.commdata.CommData;
import com.hp.itis.core2.commdata.CommDataImpl;

public class JsTest extends TestCase {
	public void test() throws ScriptException, IOException {
		ScriptEngineManager sem = new ScriptEngineManager();
		CommData cd = new CommDataImpl();
		cd.put("a", 1);
		cd.put("b", 2);
		cd.put("c", 3);
		cd.put("cd", cd);

		IVars vars = new AutomaticVars(cd);
		Bindings bindings = new VarsBindings(vars);
		ScriptEngine engine = sem.getEngineByName("JavaScript");
		engine.setBindings(bindings, ScriptContext.ENGINE_SCOPE);
		System.out.println(engine.eval("var e=1; function add(a){return a*=2;}; for(var i=0;i<10;i++){a+=b}; println(cd.get('c')+1); var d=add(a); println('aa'+d); true;"));
		System.out.println(cd.get("a"));
		System.out.println(cd.get("d"));
		if(null != Thread.currentThread().getContextClassLoader().getResource("jms/jms-inc-send.xml"))
			System.out.println("***********");
		Enumeration<URL> urls = Thread.currentThread().getContextClassLoader().getResources("*");
		PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		Resource[] res = resolver.getResources("jms/*.xml");
		for(Resource r : res)
			System.out.println(r.getFilename());
		while(urls.hasMoreElements()) {
			System.out.println(urls.nextElement());
		}
		ClassLoader t = Thread.currentThread().getContextClassLoader();
		if(t instanceof URLClassLoader) {
			URLClassLoader ut = (URLClassLoader)t;
			for(URL url : ut.getURLs())
				System.out.println(url);
			t = t.getParent();
			ut = (URLClassLoader)t;
			for(URL url : ut.getURLs())
				System.out.println(url);
		}
		//sun.misc.Launcher
	}
}
